"""Append replacement resources and retain unmodified archive resources exactly."""
import struct
from textures import resources,texture

def rgba_resource(original,o,im):
 w,h=im.size;pixels=im.load();payload=bytearray()
 for y in range(0,h,4):
  for x in range(0,w,4):
   tile=[pixels[x+xx,y+yy] if x+xx<w and y+yy<h else (0,0,0,0) for yy in range(4) for xx in range(4)]
   for r,g,b,a in tile:payload.extend((a,r))
   for r,g,b,a in tile:payload.extend((g,b))
 b=bytearray(original[o:o+64]);struct.pack_into('>I',b,0,32+len(payload));struct.pack_into('>HHHHI',b,32,6,w,h,0,32)
 b[44:64]=bytes(20);b.extend(payload)
 assert texture(b,0)[0].tobytes()==im.tobytes()
 return bytes(b)

def rebuild_archive(original,replacements):
 olddir=int.from_bytes(original[4:8],'big')+32
 tail=bytearray(original[olddir:]);body=bytearray(original[:olddir]);res=dict(resources(original))
 for i,(name,o) in enumerate(resources(original)):
  if name not in replacements:continue
  body.extend(bytes((-len(body))%32));new_o=len(body);body.extend(replacements[name]);struct.pack_into('>I',tail,i*8,new_o-32)
 body.extend(bytes((-len(body))%32));newdir=len(body);body.extend(tail);struct.pack_into('>II',body,0,len(body),newdir-32)
 newres=dict(resources(body))
 for name,o in res.items():
  size=int.from_bytes(original[o:o+4],'big')+32
  if name not in replacements:assert body[newres[name]:newres[name]+size]==original[o:o+size]
 return bytes(body)
