"""Preserve the unpublished pre-bubble candidate before the final combined build."""
from pathlib import Path
R=Path(__file__).resolve().parent
source=(R/'English_QA_v52').resolve()
target=(R/'translation_work/qa_v52/pre_bubble_review').resolve()
assert source.is_relative_to(R) and target.is_relative_to(R)
assert source.name=='English_QA_v52' and not target.exists()
assert (source/'build_report.json').exists()
source.rename(target)
(target/'UNPUBLISHED_CANDIDATE.md').write_text('Unpublished outline/punctuation-only candidate, preserved before the user requested the complete mid-game bubble pass. Use the final English_QA_v52 folder at the project root. All files retained.\n',encoding='utf8')
print('Preserved unpublished candidate at',target)
