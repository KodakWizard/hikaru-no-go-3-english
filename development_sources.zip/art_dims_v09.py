﻿from pathlib import Path
from textures import resources,texture
for src in ['2D/brs','2D/rec','2D/fai','2D/scs']:
 b=Path('translation_work/decoded/'+src+'.bin').read_bytes()
 print(src,[(n,texture(b,o)[0].size) for n,o in resources(b) if n.startswith(('brs02','rec02','rec03','rec04','fai2','scs07'))])
