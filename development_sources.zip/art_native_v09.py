﻿from pathlib import Path
from textures import resources,texture
for src,names in [('2D/fai',['fai20.D4','fai21.D4','fai22.D4','fai23.D4','fai28.D4','fai29.D4']),('2D/rec',['rec02_0.D4','rec02_1.D4','rec04.D4']),('2D/brs',['brs02_0.D4','brs02_1.D4','brs02_5.D4'])]:
 b=Path('translation_work/decoded/'+src+'.bin').read_bytes();lookup=dict(resources(b))
 for n in names:
  im,_=texture(b,lookup[n]);im.save('translation_work/menu_v09/'+n+'.png');print(n,'corners',im.getpixel((0,0)),im.getpixel((im.width-1,im.height-1)))
