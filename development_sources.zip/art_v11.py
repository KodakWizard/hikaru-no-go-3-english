from PIL import Image,ImageDraw,ImageFont
from textures import resources,texture
from qa_art_v10 import label
from smooth_art import render_label
def problem_tabs(b):
 out={}
 for i in range(5):
  n=f'fai11_{i}.D4';im,_=texture(b,dict(resources(b))[n]);art=Image.new('RGBA',im.size)
  art.alpha_composite(label((96,im.height),f'Set {i+1}',17),(2,0));out[n]=art
 return out
def result_labels(b):
 names={'moe06.D4':'Rank\nTest','moe07_0.D4':'Play','moe07_1.D4':'Game\nOver','moe07_2.D4':'Victory','moe07_3.D4':'Great\nWin','moe07_4.D4':'Huge\nWin','moe07_5.D4':'Perfect\nWin','moe07_6.D4':'Jigo','moe07_7.D4':'Defeat','moe07_8.D4':'Heavy\nLoss','moe07_9.D4':'Resume','moe03_0.D4':'Black','moe03_1.D4':'White','moe05_0.D4':'Victory','moe05_1.D4':'Great\nWin','moe05_2.D4':'Huge\nWin','moe05_3.D4':'Perfect\nWin'};out={}
 for n,o in resources(b):
  if n not in names:continue
  im,_=texture(b,o);w,h=im.size;scale=4;lines=names[n].split('\n');ink=(255,255,255,255) if n=='moe03_1.D4' else (0,0,0,255);stroke=(0,0,0,255) if n=='moe03_1.D4' else (255,255,255,255)
  for size in range(min(90,w),9,-1):
   font=ImageFont.truetype('C:/Windows/Fonts/georgiaz.ttf',size*scale);boxes=[font.getbbox(t,stroke_width=2*scale) for t in lines];widths=[x[2]-x[0] for x in boxes];heights=[x[3]-x[1] for x in boxes];total=sum(heights)+8*scale*(len(lines)-1)
   if max(widths)<(w-8)*scale and total<(h-8)*scale:break
  art=Image.new('RGBA',(w*scale,h*scale));d=ImageDraw.Draw(art);y=(h*scale-total)//2
  for t,box,tw,th in zip(lines,boxes,widths,heights):d.text(((w*scale-tw)//2-box[0],y-box[1]),t,font=font,fill=ink,stroke_width=2*scale,stroke_fill=stroke);y+=th+8*scale
  out[n]=art.resize((w,h),Image.Resampling.LANCZOS)
 return out
def lesson_buttons(b):
 out={};look=dict(resources(b))
 for state in (31,32,33):
  for i,text in [(6,'Play'),(7,'Review'),(8,'Exit')]:
   n=f'mjw{state}_{i}.D4';im,_=texture(b,look[n]);art=im.copy();ImageDraw.Draw(art).rectangle((2,2,im.width-3,im.height-3),fill=im.getpixel((3,3)))
   ink=(70,70,70,255) if state==31 else (0,0,0,255)
   art.alpha_composite(render_label(Image.new('RGBA',im.size),text,max_size=17,margin=2,title=True,text_colour=ink,outline_width=0)[0]);out[n]=art
 return out
def compact_archive(b,replacements):
 """One active resource per entry; remove abandoned Japanese pixel payloads."""
 import struct
 entries=list(resources(b));d=int.from_bytes(b[4:8],'big')+32;tail=bytearray(b[d:]);out=bytearray(b[:32])
 for i,(n,o) in enumerate(entries):
  out.extend(bytes((-len(out))%32));struct.pack_into('>I',tail,i*8,len(out)-32);length=int.from_bytes(b[o:o+4],'big')+32;out.extend(replacements.get(n,b[o:o+length]))
 out.extend(bytes((-len(out))%32));struct.pack_into('>I',out,4,len(out)-32);out.extend(tail);struct.pack_into('>I',out,0,len(out));new=dict(resources(out))
 for n,o in entries:
  if n not in replacements:
   length=int.from_bytes(b[o:o+4],'big')+32;assert out[new[n]:new[n]+length]==b[o:o+length]
 return bytes(out)
