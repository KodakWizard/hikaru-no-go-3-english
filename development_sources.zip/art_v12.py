"""Counter reconstruction and additional interface artwork localization."""
from PIL import Image,ImageDraw,ImageFilter
from textures import resources,texture
from smooth_art import render_label
def lettering(size,text,colour=(0,0,0,255),maxsize=14,outline=0):
 return render_label(Image.new('RGBA',size),text,max_size=maxsize,margin=1,title=True,text_colour=colour,outline_width=outline)[0]
def counters(original):
 out={};look=dict(resources(original))
 for side in (0,1):
  centre=100 if side==0 else 22;bx=0 if side==0 else 44
  def fix(im,top=12,show=True):
   art=im.copy();xrange=range(0,81) if side==0 else range(41,122)
   for y in range(28):
    for x in xrange:
     # Preserve the original counter's round silhouette, including antialias.
     if (x-centre)**2+(y-24)**2<=23**2:continue
     c=(238,238,238,255) if show and top<=y<=26 and bx<=x<bx+78 else ((0,0,0,255) if y==27 and bx<=x<bx+78 else (0,0,0,0))
     art.putpixel((x,y),c)
   if show:
    text=lettering((70,15),'Captures',maxsize=11);mask=text.getchannel('A')
    # All letter pixels lie within the pale strip, including entrance frames.
    clipped=Image.new('RGBA',(78,28));clipped.alpha_composite(text,(4,12));clipped.paste((0,0,0,0),(0,0,78,top));art.alpha_composite(clipped,(bx,0))
   return art
  n=f'bbg01_{side}_1.D4';im,_=texture(original,look[n]);out[n]=fix(im)
  n=f'bbg11_{side}.D4';im,_=texture(original,look[n]);art=im.copy()
  for frame,top in [(5,25),(6,20),(7,12)]:art.paste(fix(im.crop((0,frame*56,122,(frame+1)*56)),top),(0,frame*56))
  assert art.crop((0,0,122,280)).tobytes()==im.crop((0,0,122,280)).tobytes()
  out[n]=art
 return out
def badges(b):
 out={};look=dict(resources(b))
 for i in range(5):
  n=f'mba02_{35+i}.D4'
  if n not in look:continue
  im,_=texture(b,look[n]);art=Image.new('RGBA',im.size)
  # Keep the existing runtime number's empty slot and anchor on the lower row.
  art.alpha_composite(lettering((im.width,23),f'Set {i+1}',(255,255,255,255),15,1),(0,0))
  art.alpha_composite(lettering((17,23),'#',(255,255,255,255),14,1),(0,im.height-23));out[n]=art
 for n,en in [('mba02_11.D4','Kifu\nReplay'),('mba02_34.D4','Skill\nTest')]:
  if n in look:
   im,_=texture(b,look[n]);out[n]=lettering(im.size,en,(255,255,255,255),16,1)
 return out
def extra_graphics(path,b):
 out={};look=dict(resources(b))
 if path in ('2D/mjw.bpe','2D/mba.bpe'):out.update(badges(b))
 if path=='2D/mjw.bpe':
  for i in range(1,7):
   n=f'mjw10_{i}.D4';im,_=texture(b,look[n]);art=im.copy();ImageDraw.Draw(art).rectangle((2,2,im.width-3,im.height-3),fill=(180,180,180,255));en='Download GBA Link Software' if i==1 else f'Download GBA Problem Set {i-1}';art.alpha_composite(lettering((im.width-6,im.height-4),en,maxsize=11),(3,2));out[n]=art
  n='mjw34_0.D4';im,_=texture(b,look[n]);art=im.copy();interior=im.getchannel('A').filter(ImageFilter.MinFilter(9));art.paste(Image.new('RGBA',im.size,'white'),(0,0),interior);art.alpha_composite(lettering((im.width-24,40),'CPU\nRank',maxsize=12),(12,10));out[n]=art
 if path=='2D/end.bpe':
  for i,en in enumerate(['Retry Match','Return to Room','Quit Game']):
   n=f'end06_{i}.D4';im,_=texture(b,look[n]);out[n]=lettering(im.size,en,maxsize=22)
 if path=='2D/agbctrdl.bpe':
  for n,en in [('mjw41_0.D4','Saving'),('mjw42_0.D4','Loading')]:
   im,_=texture(b,look[n]);art=im.copy();cx=im.width/2;cy=im.height/2
   # This is the flat center of the original disk, not its antialiased rim.
   fill=im.getpixel((int(cx),int(cy+im.height*0.3)));d=ImageDraw.Draw(art);d.rectangle((cx-im.width*.40,cy-12,cx+im.width*.40,cy+12),fill=fill);art.alpha_composite(lettering((im.width-12,24),en,maxsize=12),(6,int(cy-12)));out[n]=art
  for i in range(4):
   n=f'gba00_{i}.D4';im,_=texture(b,look[n]);art=im.copy();ImageDraw.Draw(art).rectangle((20,2,im.width-2,17),fill='black');art.alpha_composite(lettering((im.width-24,16),f'GBA Pad {i+1}',(255,255,255,255),10,1),(21,1));out[n]=art
  for n,en in [('gba01_0.D4','Downloading'),('gba01_1.D4','Preparing')]:
   im,_=texture(b,look[n]);art=im.copy();ImageDraw.Draw(art).rectangle((22,3,im.width-3,21),fill=(185,185,185,255));art.alpha_composite(lettering((im.width-27,19),en,maxsize=10),(24,2));out[n]=art
 return out
