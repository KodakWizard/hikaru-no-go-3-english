from PIL import Image,ImageDraw
from textures import resources,texture
from smooth_art import render_label

def graphics(path,b):
 out={};look=dict(resources(b))
 if path=='2D/win.bpe':
  # The result widget crops these exact cells; whole-image labels would
  # produce clipped/mixed words. Keep every original cell boundary.
  grids={
   'win43_1.D4':(32,38,['moves',''],11),
   'win43_2.D4':(38,42,['W','B','pt','.5'],27),
   'win43_4.D4':(68,42,['Win','Loss'],25),
   'win43_5.D4':(138,42,['Time','Jigo','Resign','Draw'],28),
  }
  for n,(cw,ch,labels,fs) in grids.items():
   im,_=texture(b,look[n]);art=Image.new('RGBA',im.size)
   for i,en in enumerate(labels):
    if en:
     label=render_label(Image.new('RGBA',(cw,ch)),en,max_size=fs,margin=0 if cw==32 else 2,title=True,text_colour=(225,225,225,255),outline_width=0 if cw==32 else 2)[0];art.alpha_composite(label,(i*cw,0))
   out[n]=art
  n='win30_0.D4';im,_=texture(b,look[n]);art=Image.new('RGBA',im.size)
  for i,en in enumerate(['Connect','Capture','Fight','Best']):
   label=render_label(Image.new('RGBA',(im.width,49)),en,max_size=27,margin=2,title=True,text_colour=(255,255,255,255),outline_width=2)[0];art.alpha_composite(label,(0,i*50))
  out[n]=art
 if path=='2D/agbctrdl.bpe':
  n='cau12.D4';im,_=texture(b,look[n]);art=Image.new('RGBA',im.size)
  # Retain the original separator; only one status caption on the right.
  art.paste(im.crop((0,im.height-3,im.width,im.height)),(0,im.height-3))
  label=render_label(Image.new('RGBA',(100,im.height-3)),'Now Loading...',max_size=13,margin=1,title=True,text_colour=(255,195,0,255),outline_width=0)[0]
  art.alpha_composite(label,(im.width-125,0));out[n]=art
 return out

def font_edges(b):
 """Native-size alpha cleanup, retaining every opaque/core font pixel."""
 n='hggc24_a.D4';im,_=texture(b,dict(resources(b))[n]);art=im.copy();count=0
 # Original CI4 alpha levels leave broad, faint white fringes. Only the outer
 # white coverage changes. Opaque white/gray/black core and Japanese atlases
 # are unchanged. No glyph resizing or UV-grid change.
 for y in range(im.height):
  for x in range(im.width):
   r,g,bl,a=im.getpixel((x,y))
   if 0<a<255:
    assert r==g==bl==255
    aa=0 if a<=109 else round((a-109)*255/146)
    art.putpixel((x,y),(r,g,bl,aa));count+=1
 assert all(p==q for p,q in zip(im.getdata(),art.getdata()) if p[3] in (0,255))
 return {n:art},dict(partial_white_pixels_adjusted=count,opaque_and_transparent_pixels_exact=True,native_dimensions=im.size,scope='ASCII white outer fringe only; other font images unchanged; Dolphin comparison needed')
