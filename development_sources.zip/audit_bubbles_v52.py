from pathlib import Path
import json,re,textwrap
from qa_research_v10 import current_files
R=Path(__file__).resolve().parent;W=R/'translation_work/qa_v52'
orig=(R/'translation_work/main.dol').read_bytes();meta=json.loads((R/'translation_work/disc_metadata.json').read_text())
BASE=R/'English_QA_v52/Hikaru no Go 3 - English QA v52.iso'
with BASE.open('rb') as f:f.seek(meta['dol_offset']);dol=f.read(len(orig))
corpus=json.loads((W/'current_corpus.json').read_text(encoding='utf8'))
rows=[]
for r in corpus:
    if r['area']!='dol':continue
    p=int(r['location'],16)
    if not 0x259214<=p<=0x260178:continue
    old=dol[p:dol.index(0,p)].decode('cp932');plain=old.replace('\u2193',' ')
    lines=textwrap.wrap(plain,18,break_long_words=False,break_on_hyphens=False)
    assert not re.search(r'\$[0-9]|%',plain),(hex(p),plain)
    rows.append(dict(offset=hex(p),japanese=r['japanese'],current=old,wrapped='\u2193'.join(lines),
                     lines=len(lines),capacity=r['capacity'],requires_rephrase=len(lines)>3))
(W/'battle_bubble_audit.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
overflow=[r for r in rows if r['requires_rephrase']]
(W/'battle_bubble_overflow.txt').write_text('\n'.join(f"{i} {r['offset']} [{r['capacity']}] {r['japanese']!r} | {r['current']!r}" for i,r in enumerate(overflow)),encoding='utf8')
print(len(rows),'battle entries;',sum(r['wrapped']!=r['current'] for r in rows),'need wrapping changes;',len(overflow),'need wording shortened')
print('Sai screenshot:',next(r for r in rows if r['offset']=='0x25d254'))
