﻿from pathlib import Path
from menu_translation_v04 import TEXT as A
from menu_translation_v05 import TEXT as B
from menu_translation_v09 import TEXT,CARD_FIXES
b=Path('translation_work/main.dol').read_bytes()
for at,en in (A|B|TEXT|CARD_FIXES).items():
 if at>0x230ef0:continue
 old=b[at:b.index(0,at)].decode('cp932')
 if old.startswith('%s') and not en.startswith('%s'):print(hex(at),repr(en),repr(old))
