"""Read-only corpus extraction from the finished v49 disc and original Japanese."""
from pathlib import Path
import json,re
R=Path(__file__).parent
W=R/'translation_work/dialogue_v50';W.mkdir(exist_ok=True)
original=(R/'translation_work/main.dol').read_bytes()
meta=json.loads((R/'translation_work/disc_metadata.json').read_text())
with (R/'English_QA_v49/Hikaru no Go 3 - English QA v49.iso').open('rb') as f:
 f.seek(meta['dol_offset']);current=f.read(len(original))
offsets=set()
def walk(obj):
 if isinstance(obj,dict):
  if 'offset' in obj and ('english' in obj or 'japanese' in obj):
   try: offsets.add(int(str(obj['offset']),16) if isinstance(obj['offset'],str) else obj['offset'])
   except (ValueError,TypeError): pass
  for v in obj.values():walk(v)
 elif isinstance(obj,list):
  for v in obj:walk(v)
for p in R.glob('English_*/build_report.json'):
 walk(json.loads(p.read_text(encoding='utf8')))
rows=[]
for at in sorted(offsets):
 if not 0x258000<=at<0x277000:continue
 try:
  jp=original[at:original.index(0,at)].decode('cp932')
  en=current[at:current.index(0,at)].decode('cp932')
 except (ValueError,UnicodeDecodeError):continue
 if en==jp or not any('\u3040'<=c<='\u9fff' for c in jp):continue
 rows.append(dict(offset=hex(at),japanese=jp,english=en,capacity=len(jp.encode('cp932'))))
(W/'dol_corpus.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
groups={}
for r in rows:groups.setdefault((r['japanese'],r['english']),[]).append(r['offset'])
unique=[dict(id=i,offsets=ats,japanese=jp,english=en,capacity=len(jp.encode('cp932'))) for i,((jp,en),ats) in enumerate(groups.items())]
(W/'dol_unique.json').write_text(json.dumps(unique,ensure_ascii=False,indent=2),encoding='utf8')
for start in range(0,len(unique),200):
 (W/f'dol_{start:04d}.txt').write_text('\n'.join(f"{r['id']} {r['offsets'][0]} [{r['capacity']}] {r['japanese'].replace(chr(10),' / ')} | {r['english'].replace(chr(10),' / ')}" for r in unique[start:start+200]),encoding='utf8')
print(len(rows),'DOL occurrences;',len(unique),'unique Japanese/English pairs')
from qa_research_v10 import current_files
from gcs_text import text_tail
f,fst,files=current_files(R/'English_QA_v49/Hikaru no Go 3 - English QA v49.iso')
scripts=[]
for path,(off,size,_) in sorted(files.items()):
 if not path.endswith('.gcs'):continue
 orig=(R/'translation_work/extracted'/path).read_bytes()
 try:base,start,rr=text_tail(orig)
 except ValueError:continue
 f.seek(off);data=f.read(size)
 for i,r in enumerate(rr):
  refs=[p for p in r['references'] if int.from_bytes(orig[p-4:p],'big') in (0x87,0xa6,0x103)]
  if not refs:continue
  p=base+int.from_bytes(data[refs[0]:refs[0]+4],'big')
  en=data[p:data.index(0,p)].decode('cp932')
  scripts.append(dict(path=path,index=i,japanese=r['japanese'],english=en,references=refs))
f.close()
(W/'script_corpus.json').write_text(json.dumps(scripts,ensure_ascii=False,indent=2),encoding='utf8')
sg={}
for r in scripts:sg.setdefault((r['japanese'],r['english']),[]).append([r['path'],r['index']])
su=[dict(id=i,locations=loc,japanese=jp,english=en) for i,((jp,en),loc) in enumerate(sg.items())]
(W/'script_unique.json').write_text(json.dumps(su,ensure_ascii=False,indent=2),encoding='utf8')
for start in range(0,len(su),250):
 (W/f'script_{start:04d}.txt').write_text('\n'.join(f"{r['id']} {r['english'].replace(chr(10),' / ')}" for r in su[start:start+250]),encoding='utf8')
print(len(scripts),'script entries;',len(su),'unique JP/English pairs')
