import json,pathlib
r=pathlib.Path('translation_work/dialogue_v50')
rows=json.loads((r/'dol_corpus.json').read_text(encoding='utf8'))
known={int(x['offset'],16) for x in rows}
o=pathlib.Path('translation_work/main.dol').read_bytes()
with open('English_QA_v49/Hikaru no Go 3 - English QA v49.iso','rb') as f:
 f.seek(125952);b=f.read(len(o))
found=[]
for p in range(0x258ec0,0x275990,4):
 if p in known or o[p-1]!=0:continue
 try:j=o[p:o.index(0,p)].decode('cp932');e=b[p:b.index(0,p)].decode('cp932')
 except (ValueError,UnicodeDecodeError):continue
 if j!=e and any('\u3040'<=c<='\u9fff' for c in j) and e and all(32<=ord(c)<127 or c in '\u2193\n' for c in e):
  found.append(dict(offset=hex(p),japanese=j,english=e))
print(len(found));print(json.dumps(found,ensure_ascii=False,indent=2))
(r/'additional_dol.json').write_text(json.dumps(found,ensure_ascii=False,indent=2),encoding='utf8')
