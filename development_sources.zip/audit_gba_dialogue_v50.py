from pathlib import Path
import json,re
R=Path(__file__).parent;W=R/'translation_work/dialogue_v50'
script=json.loads((W/'script_unique.json').read_text(encoding='utf8'))
norm=lambda s:re.sub(r'\s+',' ',s.replace('\u2193',' ')).strip()
known={norm(r['english']) for r in script}
manifest=json.loads((R/'gba_books_manifest_v35.json').read_text(encoding='utf8'))
unmatched={};matched=0;total=0
for book,rows in manifest.items():
 data=(R/f'translation_work/closure_v48/current_{book}.gba').read_bytes()
 for r in rows:
  # Pool relocation means references, not original offsets, identify live text.
  p=int.from_bytes(data[r['references'][0]:r['references'][0]+4],'little')-0x09f00000
  en=data[p:data.index(0,p)].decode('cp932');total+=1
  if norm(en) in known:matched+=1
  else:unmatched.setdefault((r['japanese'],en),[]).append((book,p))
rows=[dict(id=i,japanese=jp,english=en,locations=loc) for i,((jp,en),loc) in enumerate(unmatched.items())]
(W/'gba_book_unmatched.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
(W/'gba_book_unmatched.txt').write_text('\n'.join(f"{r['id']} {r['english'].replace(chr(0x2193),' / ')}" for r in rows),encoding='utf8')
print(total,'book occurrences;',matched,'same wording as reviewed GameCube entries;',len(rows),'other unique JP/English pairs')
