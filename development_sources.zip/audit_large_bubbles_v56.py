from pathlib import Path
import json,re
from check_dialogue_v50 import wrap
R=Path(__file__).resolve().parent;W=R/'translation_work/large_bubbles_v56';W.mkdir(exist_ok=True)
BASE=R/'English_NameEntry_Test_v55/Hikaru no Go 3 - English Name Entry Test v55.iso'
with BASE.open('rb') as f:
 f.seek(0x420);at=int.from_bytes(f.read(4),'big');f.seek(at);dol=f.read(2996244)
corpus=json.loads((R/'translation_work/dialogue_v50/dol_corpus.json').read_text(encoding='utf8'))
rows=[];checked=0
for r in corpus:
 at=int(r['offset'],16)
 if 0x259000<=at<=0x260178 or at<0x258ec0:continue
 checked+=1
 old=dol[at:dol.index(0,at)].decode('cp932')
 plain=old.replace('↓',' ')
 if '↓' not in old:continue
 new=wrap(plain,26)
 # Avoid a stranded final word: move one word from the previous line when it fits.
 lines=new.split('↓')
 if len(lines)>1 and len(lines[-1].split())==1 and len(lines[-2].split())>2:
  head,last=lines[-2].rsplit(' ',1)
  tail=last+' '+lines[-1]
  if len(re.sub(r'\$[0-9]','X'*12,tail))<=26:
   lines[-2:]=[head,tail];new='↓'.join(lines)
 # Keep sensible existing phrasing unless reflow removes a line, fills an early
 # first break substantially, or repairs an existing one-word final line.
 oldlines=old.split('↓');newlines=new.split('↓')
 cell=lambda s:len(re.sub(r'\$[0-9]','X'*12,s))
 names=bool(re.search(r'\$[0-9]',old))
 useful=(len(newlines)<len(oldlines) or
         (not names and len(newlines)==len(oldlines) and cell(oldlines[0])<=18 and
          cell(newlines[0])>=cell(oldlines[0])+4 and cell(newlines[-1])>=10) or
         (not names and len(newlines)==len(oldlines) and len(oldlines[-1].split())==1 and
          len(newlines[-1].split())>=2 and not re.search(r'[.!?][\"\)]?$',oldlines[-2])))
 if not useful:new=old
 rows.append(dict(r,current=old,proposed=new,changed=old!=new,old_lines=len(old.split('↓')),new_lines=len(new.split('↓'))))
# Matching dialogue in repeated Story branches should use the same line layout.
groups={}
for row in rows:groups.setdefault(row['current'].replace('↓',' '),[]).append(row)
for group in groups.values():
 chosen=next((r['proposed'] for r in group if r['changed']),None)
 if chosen is None:continue
 for row in group:
  if len(chosen.split('↓'))<=row['old_lines']:
   row.update(proposed=chosen,changed=chosen!=row['current'],new_lines=len(chosen.split('↓')))
(W/'survey.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
for i in range(0,len(rows),180):
 (W/f'review_{i:04d}.txt').write_text('\n'.join(f"{j+i} {r['offset']} {r['current']} => {r['proposed']}" for j,r in enumerate(rows[i:i+180])),encoding='utf8')
print(len(rows),'multiline entries surveyed;',sum(r['changed'] for r in rows),'reflow candidates')
print(checked,'total room/Story entries checked')
print('ranges',[(hex(k),sum(int(r['offset'],16)//0x1000==k for r in rows)) for k in sorted({int(r['offset'],16)//0x1000 for r in rows})])
