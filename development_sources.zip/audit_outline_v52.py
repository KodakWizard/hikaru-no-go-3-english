"""Native texture boundary survey, not a claim that all boundary ink is clipping."""
from pathlib import Path
from collections import Counter
import json
from PIL import Image,ImageDraw
from qa_research_v10 import current_files
from decode_bpe import decode
from textures import texture,resources
R=Path(__file__).resolve().parent;W=R/'translation_work/qa_v52';W.mkdir(exist_ok=True)
f,_,files=current_files(R/'English_QA_v51/Hikaru no Go 3 - English QA v51.iso')
rows=[];tiles=[]
for path in ['2D/rec.bpe','2D/win.bpe','2D/mba.bpe','2D/nam.bpe','2D/scs.bpe','2D/fai.bpe']:
    off,size,_=files[path];f.seek(off);data=decode(f.read(size))
    for name,o in resources(data):
        if not name.endswith('.D4'):continue
        im,desc=texture(data,o);w,h=im.size
        if not(w>=30 and h>=15 and w<=600 and h<=220):continue
        alpha=im.getchannel('A')
        if sum(alpha.getpixel(p)==0 for p in [(0,0),(w-1,0),(0,h-1),(w-1,h-1)])<3:continue
        edges=sum(alpha.getpixel((x,y))>0 for x in range(w) for y in range(h) if x in (0,w-1) or y in (0,h-1))
        if edges:
            rows.append({'path':path,'name':name,'dimensions':[w,h],'edge_pixels':edges})
            tile=Image.new('RGB',(300,130),'#607080');ImageDraw.Draw(tile).text((3,3),path+' '+name,fill='white')
            im.thumbnail((290,105));tile.paste(im,(3,23),im);tiles.append(tile)
for pg in range((len(tiles)+23)//24):
    batch=tiles[pg*24:(pg+1)*24];sheet=Image.new('RGB',(1200,130*((len(batch)+3)//4)),'#405060')
    for i,tile in enumerate(batch):sheet.paste(tile,(i%4*300,i//4*130))
    sheet.save(W/f'boundary_candidates_{pg}.png')
(W/'boundary_candidates.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
f.close();print(len(rows),'transparent UI resources have boundary ink; inspect before deciding whether clipped')
