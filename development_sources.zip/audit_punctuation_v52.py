"""Read current live strings and list punctuation candidates for human review."""
from pathlib import Path
import json,re
from qa_research_v10 import current_files
from gcs_text import text_tail
from gba_lz_v34 import decode as lzdecode
from gba_translation_v34 import TEXT as GBA_MATCH
R=Path(__file__).resolve().parent;W=R/'translation_work/qa_v52';W.mkdir(exist_ok=True)
BASE=R/'English_QA_v51/Hikaru no Go 3 - English QA v51.iso'
f,_,files=current_files(BASE);meta=json.loads((R/'translation_work/disc_metadata.json').read_text())
orig=(R/'translation_work/main.dol').read_bytes();f.seek(meta['dol_offset']);dol=f.read(len(orig))
rows=[];dol_seen=set()
for r in json.loads((R/'translation_work/dialogue_v50/dol_corpus.json').read_text(encoding='utf8')):
    p=int(r['offset'],16);en=dol[p:dol.index(0,p)].decode('cp932')
    rows.append(dict(area='dol',location=r['offset'],japanese=r['japanese'],current=en,capacity=r['capacity']))
    dol_seen.add(p)
# Extend beyond the Story audit using the existing build records, not a blind
# interpretation of binary words as strings.
offsets=set()
def walk(obj):
    if isinstance(obj,dict):
        if 'offset' in obj and 'japanese' in obj:
            try:offsets.add(int(obj['offset'],16) if isinstance(obj['offset'],str) else obj['offset'])
            except (ValueError,TypeError):pass
        for value in obj.values():walk(value)
    elif isinstance(obj,list):
        for value in obj:walk(value)
for p in R.glob('English_*/build_report.json'):walk(json.loads(p.read_text(encoding='utf8')))
for p in sorted(offsets-dol_seen):
    if not 0x220000<=p<len(orig):continue
    try:
        jp=orig[p:orig.index(0,p)].decode('cp932');en=dol[p:dol.index(0,p)].decode('cp932')
    except (ValueError,UnicodeDecodeError):continue
    if jp==en or not re.search('[\u3040-\u30ff\u4e00-\u9fff]',jp):continue
    rows.append(dict(area='dol',location=hex(p),japanese=jp,current=en,capacity=len(jp.encode('cp932'))))
for path in sorted(files):
    if not path.endswith('.gcs'):continue
    o,n,_=files[path];f.seek(o);data=f.read(n);original=(R/'translation_work/extracted'/path).read_bytes()
    try:base,start,rr=text_tail(original)
    except ValueError:continue
    for i,r in enumerate(rr):
        refs=[a for a in r['references'] if int.from_bytes(original[a-4:a],'big') in (0x87,0xa6,0x103)]
        if not refs:continue
        p=base+int.from_bytes(data[refs[0]:refs[0]+4],'big');en=data[p:data.index(0,p)].decode('cp932')
        rows.append(dict(area='script',location=[path,i],references=refs,japanese=r['japanese'],current=en))
def read(path):
    o,n,_=files[path];f.seek(o);return f.read(n)
match=b''.join(lzdecode(read(f'gba/dacs/magnet/btlmenu_dacs_{i}_LZ.bin')) if i<40 else read(f'gba/dacs/magnet/btlmenu_dacs_{i}.bin') for i in range(45))
match_orig=(R/'translation_work/gba_audit/btlmenu.gba').read_bytes()
for at in sorted(set(GBA_MATCH)|{0xd46ac,0xd609c}):
    en=match[at:match.index(0,at)].decode('cp932');jp=match_orig[at:match_orig.index(0,at)].decode('cp932')
    rows.append(dict(area='gba_match',location=hex(at),japanese=jp,current=en))
manifest=json.loads((R/'gba_books_manifest_v35.json').read_text(encoding='utf8'))
common=b''.join(lzdecode(read(f'gba/dacs/tutocmn/tutorial1_dacs_0_{i}_LZ.bin')) for i in range(40))
for book,rr in manifest.items():
    paths=sorted([p for p in files if p.startswith(f'gba/dacs/tutorial{book}_dacs/')],key=lambda p:int(p.split('_')[-2]))
    rom=common+b''.join(lzdecode(read(p)) for p in paths)
    for r in rr:
        p=int.from_bytes(rom[r['references'][0]:r['references'][0]+4],'little')-0x09f00000
        en=rom[p:rom.index(0,p)].decode('cp932')
        rows.append(dict(area='gba_book',location=[book,hex(p)],japanese=r['japanese'],current=en))
f.close()
groups={}
for row in rows:
    en=row['current'].strip()
    if not en or en[-1] in '.!?":;)>]':continue
    if not re.search('[A-Za-z]',en):continue
    if len(en.split())<2 and not re.search('[。！？!?…]$',row['japanese']):continue
    groups.setdefault((row['area'],row['japanese'],row['current']),[]).append(row)
result=[]
for i,((area,jp,en),locs) in enumerate(groups.items()):
    result.append(dict(id=i,area=area,japanese=jp,current=en,locations=locs))
(W/'punctuation_candidates.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
(W/'punctuation_candidates.txt').write_text('\n'.join(f"{r['id']} {r['area']} {r['locations'][0]['location']} {r['japanese']!r} | {r['current']!r}" for r in result),encoding='utf8')
(W/'current_corpus.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
print(len(rows),'known live entries;',len(result),'unique punctuation candidates')
