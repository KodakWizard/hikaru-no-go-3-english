"""Standard BPS1 SourceRead/TargetRead writer plus independent streaming verifier."""
from pathlib import Path
import zlib,struct,hashlib,json

def number(value):
 out=bytearray()
 while True:
  b=value&127;value>>=7
  if value==0:out.append(b|128);return out
  out.append(b);value-=1

def make(source,target,path,metadata):
 patch=bytearray(b'BPS1');patch.extend(number(source.stat().st_size));patch.extend(number(target.stat().st_size))
 tag=json.dumps(metadata,separators=(',',':')).encode();patch.extend(number(len(tag)));patch.extend(tag)
 source_crc=0;target_crc=0;run_type=None;run_length=0;literals=bytearray();commands=0
 def flush():
  nonlocal run_length,commands
  if not run_length:return
  patch.extend(number(((run_length-1)<<2)|run_type))
  if run_type==1:patch.extend(literals);literals.clear()
  run_length=0;commands+=1
 with source.open('rb') as f,target.open('rb') as g:
  while True:
   a=f.read(1024*1024);b=g.read(1024*1024)
   if not a:assert not b;break
   assert len(a)==len(b);source_crc=zlib.crc32(a,source_crc);target_crc=zlib.crc32(b,target_crc)
   if a==b:
    if run_type!=0:flush();run_type=0
    run_length+=len(a);continue
   i=0
   while i<len(a):
    kind=0 if a[i]==b[i] else 1;s=i;i+=1
    while i<len(a) and (a[i]==b[i])==(kind==0):i+=1
    if kind!=run_type:flush();run_type=kind
    run_length+=i-s
    if kind==1:literals.extend(b[s:i])
 flush();patch.extend(struct.pack('<II',source_crc,target_crc));patch.extend(struct.pack('<I',zlib.crc32(patch)))
 path.write_bytes(patch)
 return verify(source,target,path)|dict(bytes=len(patch),commands=commands)

def verify(source,target,path):
 b=path.read_bytes();assert b[:4]==b'BPS1'
 assert zlib.crc32(b[:-4])==int.from_bytes(b[-4:],'little')
 pos=4
 def readnum():
  nonlocal pos
  value=0;shift=1
  while True:
   x=b[pos];pos+=1;value+=(x&127)*shift
   if x&128:return value
   shift<<=7;value+=shift
 ss=readnum();ts=readnum();ms=readnum();pos+=ms
 assert ss==source.stat().st_size and ts==target.stat().st_size
 produced=0;crc=0;sha=hashlib.sha256();source_crc=0
 with source.open('rb') as f:
  for chunk in iter(lambda:f.read(8*1024*1024),b''):source_crc=zlib.crc32(chunk,source_crc)
  while produced<ts:
   command=readnum();length=(command>>2)+1;action=command&3
   if action==0:f.seek(produced)
   elif action!=1:raise ValueError('Unexpected copy command in own patch')
   while length:
    n=min(length,1024*1024)
    if action==0:chunk=f.read(n)
    else:chunk=b[pos:pos+n];pos+=n
    assert len(chunk)==n;crc=zlib.crc32(chunk,crc);sha.update(chunk);produced+=n;length-=n
 assert pos==len(b)-12
 assert source_crc==int.from_bytes(b[-12:-8],'little') and crc==int.from_bytes(b[-8:-4],'little')
 actual=hashlib.sha256()
 with target.open('rb') as f:
  for chunk in iter(lambda:f.read(8*1024*1024),b''):actual.update(chunk)
 assert actual.hexdigest()==sha.hexdigest()
 return dict(bps_verified=True,reconstructed_sha256=sha.hexdigest(),source_crc32=f'{source_crc:08x}',target_crc32=f'{crc:08x}')
