﻿from pathlib import Path
from ui_translation_v08 import TEXT,MATCH_CUES
b=Path('translation_work/main.dol').read_bytes()
for at,en in TEXT.items():
 n=len(b[at:b.index(0,at)]);need=len(en.encode('cp932'))
 if need>n:print(hex(at),repr(en),need,n)
for jp,en in MATCH_CUES.items():
 if len(en.encode('cp932'))>len(jp.encode('cp932')):print(repr(jp),repr(en))
