﻿from pathlib import Path
from menu_translation_v09 import TEXT,CARD_FIXES
b=Path('translation_work/main.dol').read_bytes()
for at,en in (TEXT|CARD_FIXES).items():
 old=b[at:b.index(0,at)]
 if len(en.encode('cp932'))>len(old):print(hex(at),repr(en),'need',len(en.encode('cp932')),'capacity',len(old))
