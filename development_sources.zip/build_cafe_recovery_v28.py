"""Reduce UI archive storage/decoded size; retain every active resource byte."""
from pathlib import Path
import json,struct,shutil,hashlib
from qa_research_v10 import current_files
from decode_bpe import decode
from encode_bpe import encode
from art_v11 import compact_archive
from textures import resources
from patch_utils import sha
from bps_patch import make
R=Path(__file__).parent;W=R/'translation_work';OUT=R/'English_CafeRecovery_v28';OUT.mkdir(exist_ok=True)
BASE=R/'English_Interface_v27/Hikaru no Go 3 - English Interface v27.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso'
TARGET=OUT/'Hikaru no Go 3 - English Cafe Recovery v28.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((W/'disc_metadata.json').read_text())
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
f,fst,files=current_files(BASE);blobs={};reports=[]
for path in ['2D/win.bpe','2D/fai.bpe','2D/rec.bpe','2D/scs.bpe','2D/brs.bpe','2D/moe1.bpe','2D/moe2.bpe']:
 off,size,index=files[path];f.seek(off);old=decode(f.read(size));new=compact_archive(old,{})
 a=list(resources(old));b=list(resources(new));assert [n for n,o in a]==[n for n,o in b]
 hashes={}
 for (name,x),(_,y) in zip(a,b):
  n=int.from_bytes(old[x:x+4],'big')+32
  assert old[x:x+n]==new[y:y+n],(path,name)
  hashes[name]=hashlib.sha256(old[x:x+n]).hexdigest()
 packed=encode(new);assert len(packed)<=size and len(new)<=len(old)
 blobs[path]=(off,packed,new);struct.pack_into('>I',fst,index*12+8,len(packed))
 reports.append(dict(path=path,offset=off,previous_stored=size,stored=len(packed),previous_decoded=len(old),decoded=len(new),active_resources=len(a),active_resource_sha256=hashes,all_active_resource_bytes_exact=True))
 print(path,size,'->',len(packed),'stored;',len(old),'->',len(new),'decoded; resources exact',flush=True)
f.close();shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 f.seek(meta['fst_offset']);f.write(fst)
 for off,packed,_ in blobs.values():f.seek(off);f.write(packed)
f,got,fs=current_files(TARGET);assert got==fst
for path,(off,packed,new) in blobs.items():
 assert fs[path][:2]==(off,len(packed));f.seek(off);assert f.read(len(packed))==packed and decode(packed)==new
f.close()
allowed=sorted([(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(off,off+len(packed)) for off,packed,_ in blobs.values()])
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   checked=0
   for lo,hi in allowed:
    if hi<=pos or lo>=pos+len(x):continue
    aa=max(0,lo-pos);bb=min(len(x),hi-pos)
    assert x[checked:aa]==y[checked:aa];checked=max(checked,bb)
   assert x[checked:]==y[checked:]
  pos+=len(x)
print('Whole disc verified: DOL and all scripts exact v27. Creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_CafeRecovery_v28.bps',dict(game='Hikaru no Go 3',version='0.28',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.28',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,archives=reports,all_active_resource_bytes_exact=True,dol_scripts_font_exact_v27=True,whole_disc_differences_verified=True,patch=patch,root_cause_confirmed=False,status='Internet cafe after Yes black-screen recovery candidate; user says last working version v08; archive memory hypothesis unconfirmed; Dolphin test required')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('Built',TARGET,report['output_sha256'],flush=True)
