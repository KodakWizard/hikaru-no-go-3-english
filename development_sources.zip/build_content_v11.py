"""Cumulative content expansion and screenshot repair from v0.10."""
from pathlib import Path
import json,struct,shutil,re,sys
from PIL import Image,ImageDraw
from qa_research_v10 import current_files
from qa_translation_v10 import wrap,cells
from tutorial_translation_v11 import LESSONS
from drill_translation_v11 import GOALS,FEEDBACK
from ui_translation_v11 import build_text
from hud_names_v11 import patch as patch_names
from art_v11 import problem_tabs,result_labels,lesson_buttons,compact_archive
from textures import resources,texture
from archive_edit import rgba_resource,rebuild_archive
from decode_bpe import decode
from gcs_text import text_tail
from gcs_rebuild import rebuild,verify_original_roundtrip
from patch_utils import sha
from bps_patch import make
R=Path(__file__).parent;W=R/'translation_work';OUT=R/'English_Content_v11';OUT.mkdir(exist_ok=True);(OUT/'assets').mkdir(exist_ok=True)
BASE=R/'English_QA_v10/Hikaru no Go 3 - English QA v10.iso';SOURCE=R/'Hikaru no Go 3 (Japan).iso';TARGET=OUT/'Hikaru no Go 3 - English Content v11.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((W/'disc_metadata.json').read_text());original=(W/'main.dol').read_bytes();f,fst,files=current_files(BASE);f.seek(meta['dol_offset']);before=f.read(len(original));dol=bytearray(before);ranges=[];edits=[];freed=[]
protected={int(p,16) for p in json.loads((R/'English_Interface_v08/build_report.json').read_text())['name_display']['reclaimed_words']}
for at,en in build_text(original).items():
 raw=original[at:original.index(0,at)];now=before[at:before.index(0,at)];new=en.encode('cp932');assert len(new)<=len(raw),(hex(at),en,len(new),len(raw))
 assert re.findall(rb'%[-0-9]*[sd]',raw)==re.findall(rb'%[-0-9]*[sd]',new),(hex(at),'format mismatch')
 used=max(len(now),len(new))+1;assert not any(at<p+4 and p<at+used for p in protected)
 dol[at:at+used]=new+bytes(used-len(new));ranges.append((at,at+used));edits.append(dict(offset=hex(at),japanese=raw.decode('cp932'),previous=now.decode('cp932'),english=en))
 if 0x2792a0<=at<0x279de0:freed.append((at+len(new)+1,at+len(raw)+1))
name_report=patch_names(dol,original,freed)
ranges.extend((int(p,16),int(p,16)+4) for p in name_report['reclaimed_words']);ranges.extend((int(p,16)-0x80018ba0+0x2620,int(p,16)-0x80018ba0+0x2620+4) for p in name_report['hooks'])
assert all(before[p:p+4]==dol[p:p+4] for p in protected)
assert all(a==b or any(lo<=i<hi for lo,hi in ranges) for i,(a,b) in enumerate(zip(before,dol)))
def archive(path):
 o,s,_=files[path];f.seek(o);return decode(f.read(s))
blobs={};checks=[];previews=[]
for path,renderer in [('2D/fai.bpe',problem_tabs),('2D/moe1.bpe',result_labels),('2D/moe2.bpe',result_labels),('2D/mjw.bpe',lesson_buttons)]:
 b=archive(path);mapping=renderer(b);look=dict(resources(b));replace={}
 for n,im in mapping.items():
  old,_=texture(b,look[n]);assert old.size==im.size;replace[n]=rgba_resource(b,look[n],im);assert texture(replace[n],0)[0].tobytes()==im.tobytes();im.save(OUT/'assets'/(path.split('/')[-1]+'.'+n+'.png'));checks.append(dict(path=path,asset=n,dimensions=im.size,rgba8_exact=True));previews.append((n,im))
 new=rebuild_archive(b,replace);blob=len(new).to_bytes(4,'big')+bytes([254,127,254,255])+len(new).to_bytes(4,'big')+new;assert decode(blob)==new;blobs[path]=(blob,new)
# Repack active battle resources, dropping obsolete Japanese versions retained
# by earlier append-only archive builds. All active payloads remain exact.
path='2D/bbg.bpe';b=archive(path);new=compact_archive(b,{});blobs[path]=(len(new).to_bytes(4,'big')+bytes([254,127,254,255])+len(new).to_bytes(4,'big')+new,new)
# Restore the whole font file byte-for-byte, eliminating v10's resized atlas.
path='font24/hggc24.bpe';font_original=(W/'extracted'/path).read_bytes();blobs[path]=(font_original,decode(font_original))
scripts=[]
def add_script(path,translations,coordinates=False,goal=False):
 orig=(W/'extracted'/path).read_bytes();verify_original_roundtrip(orig,coordinates);_,_,rows=text_tail(orig);assert len(rows)==len(translations)
 for i,(src,en) in enumerate(zip(rows,translations)):
  assert '\r' not in en
  assert len(en.split('\n'))<=(6 if goal and i==0 else 3),(path,i,en)
  assert all(cells(s)<=(12 if goal and i==0 else 22) for s in en.split('\n')),(path,i,en)
  assert re.findall(r'\$\d|%[sd]',src['japanese'])==re.findall(r'\$\d|%[sd]',en)
  for symbol in '△□⑪':assert src['japanese'].count(symbol)==en.count(symbol),(path,i,symbol)
 new,report=rebuild(orig,translations,False,coordinates);blobs[path]=(new,new);scripts.append(dict(path=path,entries=len(rows),original_exact_roundtrip=True,non_pointer_code_identical=True,translations=report))
for name,rows in LESSONS.items():add_script('script/tutorial/'+name+'.gcs',[wrap(s) for s in rows])
def goal_wrap(s):
 out=[];line=''
 for word in s.replace('\n',' ').split():
  cand=(line+' '+word).strip()
  if line and cells(cand)>12:out.append(line);line=word
  else:line=cand
 out.append(line);assert len(out)<=5,(s,out);return '\n'.join(out)
for k,rows in FEEDBACK.items():add_script(f'script/drill/dri_{k:03d}.gcs',[f'1-{k:02d}\n'+goal_wrap(GOALS[k])]+[wrap(s) for s in rows],True,True)
# Dispatcher has no supported tutorial heading. Use strictly in-place edits;
# every non-string byte and all original pointers remain unchanged.
path='script/drill/drill.gcs';orig=(W/'extracted'/path).read_bytes();new=bytearray(orig);common=[]
for jp,en in [('正解です。','Correct!'),('ほぼ正解です。','Almost right.'),('失敗です。','Failed.'),('この手でよいで\nすか？','This move\nOK?'),('はい','Yes'),('いいえ','No')]:
 raw=jp.encode('cp932');at=orig.index(raw+b'\0');encoded=en.encode();assert len(encoded)<=len(raw);new[at:at+len(raw)+1]=encoded+bytes(len(raw)+1-len(encoded));common.append(dict(offset=at,japanese=jp,english=en))
assert all(a==b or any(r['offset']<=i<=r['offset']+len(r['japanese'].encode('cp932')) for r in common) for i,(a,b) in enumerate(zip(orig,new)));blobs[path]=(bytes(new),bytes(new))
sheet=Image.new('RGB',(1000,200*((len(previews)+4)//5)),'#77716c');d=ImageDraw.Draw(sheet)
for i,(n,im) in enumerate(previews):
 im=im.copy();im.thumbnail((190,174));x=i%5*200;y=i//5*200;d.text((x,y),n,fill='white');sheet.paste(im,(x,y+22),im)
sheet.save(OUT/'asset_preview.png')
if '--preview' in sys.argv:print('Preview and all text/layout/code checks passed.',len(edits),'DOL strings;',sum(s['entries'] for s in scripts),'new script entries.');sys.exit()
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
inv=json.loads((W/'inventory.json').read_text(encoding='utf8'));placement=(max(o+s for o,s,_ in files.values() if o<1085734912)+0x7fff)&~0x7fff;relocated={}
for path,(blob,_) in blobs.items():
 assert placement+len(blob)<1085734912
 assert all(placement+len(blob)<=e['offset'] or placement>=e['offset']+e['size'] for e in inv)
 assert all(placement+len(blob)<=o or placement>=o+s for o,s,_ in files.values())
 relocated[path]=dict(offset=placement,size=len(blob));struct.pack_into('>II',fst,files[path][2]*12+4,placement,len(blob));placement=(placement+len(blob)+0x7fff)&~0x7fff
f.close();shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as g:
 g.seek(meta['dol_offset']);g.write(dol);g.seek(meta['fst_offset']);g.write(fst)
 for path,(blob,_) in blobs.items():g.seek(relocated[path]['offset']);g.write(blob)
with TARGET.open('rb') as g:
 g.seek(meta['dol_offset']);assert g.read(len(dol))==dol;g.seek(meta['fst_offset']);assert g.read(len(fst))==fst
 for path,(blob,new) in blobs.items():g.seek(relocated[path]['offset']);got=g.read(len(blob));assert (decode(got) if path.endswith('.bpe') else got)==new
allowed=[(meta['dol_offset']+a,meta['dol_offset']+b) for a,b in ranges]+[(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(v['offset'],v['offset']+v['size']) for v in relocated.values()]
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   checked=0
   for lo,hi in sorted(allowed):
    if hi<=pos or lo>=pos+len(x):continue
    a=max(0,lo-pos);b=min(len(x),hi-pos)
    if a>checked:assert x[checked:a]==y[checked:a],hex(pos+checked)
    checked=max(checked,b)
   assert x[checked:]==y[checked:],hex(pos+checked)
  pos+=len(x)
print('Disc and resource checks passed; generating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Content_v11.bps',dict(game='Hikaru no Go 3',version='0.11',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.11',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,dol_strings=edits,graphic_checks=checks,script_checks=scripts,dispatcher_strings=common,hud_names=name_report,font_restored_exactly_to_original=True,battle_active_resources_compacted_without_pixel_changes=True,relocated_files=relocated,whole_disc_differences_verified=True,patch=patch,status='Content expansion; full game incomplete; runtime confirmation required')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('Built',TARGET,'SHA256',report['output_sha256'],flush=True)
