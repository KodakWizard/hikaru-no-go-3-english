"""First complete beginner-course batch plus consistent RGBA8 navigation."""
from pathlib import Path
import json,struct,shutil,math,collections
from PIL import Image,ImageDraw
from textures import resources,texture
from decode_bpe import decode
from smooth_art import render_label
from archive_edit import rgba_resource,rebuild_archive
from gcs_text import text_tail
from gcs_rebuild import rebuild,verify_original_roundtrip
from tutorial_translation_v07 import LESSONS
from story_translation import ROOM_LABELS
from menu_translation_v04 import LABELS as OLD_LABELS
from lesson_menu_translation_v07 import LABELS as COURSE_LABELS
from patch_utils import sha
from bps_patch import make

ROOT=Path(__file__).resolve().parent;WORK=ROOT/'translation_work'
OUT=ROOT/'English_Course_v07';OUT.mkdir(exist_ok=True)
SOURCE=ROOT/'Hikaru no Go 3 (Japan).iso'
BASE=ROOT/'English_Menu_v06/Hikaru no Go 3 - English Menu v06.iso'
TARGET=OUT/'Hikaru no Go 3 - English Course v07.iso'
previous=json.loads((BASE.parent/'build_report.json').read_text())
meta=json.loads((WORK/'disc_metadata.json').read_text())
assert sha(SOURCE)==previous['source_sha256'];assert sha(BASE)==previous['output_sha256']
with BASE.open('rb') as f:
 f.seek(meta['fst_offset']);fst=bytearray(f.read(meta['fst_size']))
 count=int.from_bytes(fst[8:12],'big');names=fst[count*12:];stack=[('',count)];files={}
 for i in range(1,count):
  while i>=stack[-1][1]:stack.pop()
  word,off,size=struct.unpack_from('>III',fst,i*12);name=names[word&0xffffff:].split(b'\0')[0].decode('cp932');path=stack[-1][0]+name
  if word>>24:stack.append((path+'/',size))
  else:files[path]=(off,size,i)
original_entries=json.loads((WORK/'inventory.json').read_text(encoding='utf8'))
origmap={e['path']:e for e in original_entries}
placement=(max(off+size for off,size,i in files.values() if off<1085734912)+0x7fff)&~0x7fff
blobs={};archive_checks=[];previews=[];script_checks=[]
maps={k:dict(v) for k,v in OLD_LABELS.items()};maps['2D/roo']={n:t[1] for n,t in ROOM_LABELS.items()};maps['2D/fai']=COURSE_LABELS
for src,mapping in maps.items():
 b=(WORK/'decoded'/Path(src+'.bin')).read_bytes();lookup=dict(resources(b));replacements={}
 for name,en in mapping.items():
  o=lookup[name];im,_=texture(b,o);room=src=='2D/roo'
  art,budget=render_label(im,en,max_size=18 if src=='2D/mba' else min(22,im.height-6),margin=5 if room else (2 if im.width<=32 else 3),text_colour=(0,0,0,255) if room else None,outline_width=0 if room else None)
  replacements[name]=rgba_resource(b,o,art)
  after,desc=texture(replacements[name],0);assert after.tobytes()==art.tobytes()
  archive_checks.append(dict(archive=src,asset=name,text=en,rgba_exact=True,**budget))
  if src=='2D/fai' or len(previews)<8:previews.append((name,im,after))
 new=rebuild_archive(b,replacements)
 blob=len(new).to_bytes(4,'big')+bytes([254,127,254,255])+len(new).to_bytes(4,'big')+new
 assert decode(blob)==new;blobs[src+'.bpe']=(blob,new,'archive')
for name,en in LESSONS.items():
 path='script/tutorial/'+name+'.gcs';original=(WORK/'extracted'/path).read_bytes()
 verify_original_roundtrip(original);new,rows=rebuild(original,en)
 blobs[path]=(new,new,'script');script_checks.append(dict(path=path,entries=len(rows),original_bytes=len(original),new_bytes=len(new),original_roundtrip_exact=True,all_string_operands_verified=True,code_unchanged_except_string_operands=True,translations=rows))
relocated={}
for path,(blob,new,kind) in blobs.items():
 assert all(placement+len(blob)<=e['offset'] or placement>=e['offset']+e['size'] for e in original_entries)
 assert all(placement+len(blob)<=off or placement>=off+size for off,size,i in files.values())
 relocated[path]=dict(offset=placement,size=len(blob),kind=kind)
 i=files[path][2];struct.pack_into('>II',fst,i*12+4,placement,len(blob));placement=(placement+len(blob)+0x7fff)&~0x7fff
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 f.seek(meta['fst_offset']);f.write(fst)
 for path,(blob,new,kind) in blobs.items():f.seek(relocated[path]['offset']);f.write(blob)
with TARGET.open('rb') as f,BASE.open('rb') as g:
 f.seek(meta['fst_offset']);assert f.read(len(fst))==fst
 f.seek(meta['dol_offset']);g.seek(meta['dol_offset']);n=(WORK/'main.dol').stat().st_size;assert f.read(n)==g.read(n)
 for path,(blob,new,kind) in blobs.items():
  f.seek(relocated[path]['offset']);got=f.read(len(blob))
  assert (decode(got) if kind=='archive' else got)==new

# Whole-disc differences may only be inherited patches or this batch's file table/resources.
allowed=[(meta['dol_offset'],meta['dol_offset']+(WORK/'main.dol').stat().st_size),(meta['fst_offset'],meta['fst_offset']+len(fst))]
for dirname in ['English_Menu_POC','English_Story_v02','English_Menu_v04','English_Menu_v05','English_Menu_v06']:
 r=json.loads((ROOT/dirname/'build_report.json').read_text(encoding='utf8'))
 if 'title_archive_offset'in r:allowed.append((r['title_archive_offset'],r['title_archive_offset']+r['title_archive_size']))
 if 'room_archive_offset'in r:allowed.append((r['room_archive_offset'],r['room_archive_offset']+r['room_archive_bytes']))
 for key in ('relocated_archives','archives'):
  for e in r.get(key,{}).values():allowed.append((e['offset'],e['offset']+e['size']))
allowed.extend((e['offset'],e['offset']+e['size']) for e in relocated.values())
with SOURCE.open('rb') as f,TARGET.open('rb') as g:
 pos=0
 while True:
  a=f.read(1024*1024);b=g.read(1024*1024)
  if not a:assert not b;break
  assert len(a)==len(b)
  if a!=b:
   for i,(x,y) in enumerate(zip(a,b)):
    if x!=y:assert any(lo<=pos+i<hi for lo,hi in allowed),hex(pos+i)
  pos+=len(a)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Course_v07.bps',dict(game='Hikaru no Go 3',version='0.7',base='original Japanese GHTJA4'))
assert sha(SOURCE)==previous['source_sha256'];assert sha(BASE)==previous['output_sha256']

coverage=[];families=collections.defaultdict(lambda:dict(files=0,parsed_files=0,source_entries=0,translated_entries=0))
for p in sorted((WORK/'extracted/script').rglob('*.gcs')):
 path=str(p.relative_to(WORK/'extracted')).replace('\\','/');fam=families[p.parent.name];fam['files']+=1
 try:
  base,start,rows=text_tail(p.read_bytes());fam['parsed_files']+=1;fam['source_entries']+=len(rows)
  translated=len(LESSONS[p.stem]) if p.parent.name=='tutorial' and p.stem in LESSONS else 0;fam['translated_entries']+=translated
  coverage.append(dict(path=path,source_entries=len(rows),translated_entries=translated,status='translated; Dolphin test required' if translated else 'Japanese; not translated'))
 except Exception as e:coverage.append(dict(path=path,status='dispatcher/header unsupported by text-tail parser',reason=str(e)))
ledger=dict(objective='Complete English translation',status='IN PROGRESS; not a complete game translation',verified_script_families=dict(families),script_files=coverage,dol=dict(translated_occurrences=392,denominator='Not yet fully audited; candidate extraction is not a completeness measure'),graphics=dict(translated_resources=135,rgba8_translated_resources=135,remaining='Untranslated graphic assets still require a complete visual audit'),runtime=dict(v06='User confirmed title/main menu quality works',v07='New GCS text-pool rewrite requires Dolphin validation before bulk adoption'),remaining_work=['Translate remaining 12 lesson scripts (974 entries).','Translate drill/problem scripts (1535 verified entries).','Translate mission scripts (267 verified entries).','Translate remaining Story/executable dialogue; recover pointer-aware space allocation where needed.','Audit and translate remaining UI/composite images, prompts, GBA text and movie text if present.','Exercise branches, save/load and all modes; layout and terminology review.'])
(WORK/'COVERAGE.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf8')
report=dict(version='0.7',source_sha256=previous['source_sha256'],output_sha256=sha(TARGET),original_unchanged=True,previous_build_preserved=True,beginner_lessons=len(LESSONS),new_script_entries=sum(map(len,LESSONS.values())),new_menu_labels=len(COURSE_LABELS),rgba8_labels_rebuilt=len(archive_checks),dol_unchanged_from_v06=True,whole_disc_differences_verified=True,relocated_files=relocated,script_checks=script_checks,graphic_checks=archive_checks,patch=patch,status='Beginner-course batch complete in files; full-game translation remains in progress; Dolphin testing required')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'translated_lessons.txt').write_text('\n\n'.join(c['path']+'\n'+'\n\n'.join(str(r['index'])+' '+r['english'] for r in c['translations']) for c in script_checks),encoding='utf8')
for pg in range(math.ceil(len(previews)/12)):
 items=previews[pg*12:(pg+1)*12];sheet=Image.new('RGB',(900,len(items)*85),'#304050');dr=ImageDraw.Draw(sheet)
 for i,(name,before,after) in enumerate(items):
  dr.text((5,i*85+2),name,fill='white');sheet.paste(before,(5,i*85+25),before);sheet.paste(after,(460,i*85+25),after)
 sheet.save(OUT/f'navigation_preview_{pg+1}.png')
print('Built',TARGET,'lesson entries',sum(map(len,LESSONS.values())),'RGBA8 labels',len(archive_checks),'new labels',len(COURSE_LABELS),'BPS bytes',patch['bytes'])
