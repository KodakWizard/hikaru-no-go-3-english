"""Remaining courses and screenshot repairs, cumulative from v12."""
from pathlib import Path
import json,struct,shutil,re,sys
from PIL import Image,ImageDraw
from qa_research_v10 import current_files
from qa_translation_v10 import LESSONS as BEGINNER,wrap,cells
from tutorial_translation_v11 import LESSONS as ATARI
from tutorial_translation_v13 import LESSONS as NEW
from ui_translation_v13 import TEXT
from art_v13 import graphics as render_graphics,font_edges
from result_names_v13 import patch as patch_names
from textures import resources,texture
from archive_edit import rgba_resource,rebuild_archive
from decode_bpe import decode
from gcs_text import text_tail
from gcs_rebuild import rebuild,verify_original_roundtrip
from patch_utils import sha
from bps_patch import make
R=Path(__file__).parent;W=R/'translation_work';OUT=R/'English_Courses_v13';OUT.mkdir(exist_ok=True);(OUT/'assets').mkdir(exist_ok=True)
BASE=R/'English_Polish_v12/Hikaru no Go 3 - English Polish v12.iso';SOURCE=R/'Hikaru no Go 3 (Japan).iso';TARGET=OUT/'Hikaru no Go 3 - English Courses v13.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((W/'disc_metadata.json').read_text());original=(W/'main.dol').read_bytes();f,fst,files=current_files(BASE);f.seek(meta['dol_offset']);before=f.read(len(original));dol=bytearray(before);edits=[];ranges=[]
protected=set()
for p,key in [('English_Interface_v08/build_report.json','name_display'),('English_Content_v11/build_report.json','hud_names'),('English_Polish_v12/build_report.json','font_uv')]:
 j=json.loads(Path(p).read_text(encoding='utf8'))[key];protected.update(int(x,16) for x in j['reclaimed_words'])
for at,en in TEXT.items():
 raw=original[at:original.index(0,at)];now=before[at:before.index(0,at)];enc=en.encode('cp932');assert len(enc)<=len(raw),(hex(at),len(raw),en)
 assert re.findall(rb'%[-0-9]*([sd])',raw)==re.findall(rb'%[-0-9]*([sd])',enc)
 used=max(len(now),len(enc))+1;assert not any(at<p+4 and p<at+used for p in protected)
 dol[at:at+used]=enc+bytes(used-len(enc));ranges.append((at,at+used));edits.append(dict(offset=hex(at),japanese=raw.decode('cp932'),previous=now.decode('cp932'),english=en))
# The category's original small-data slot cannot fit Life/Death. Redirect its
# nine verified table pointers to an existing translated Life/Death constant.
target=0x802533ec;assert dol[0x2503ec:0x2503ec+11]==b'Life/Death\0'
for at in range(0x2bbaf4,0x2bbb18,4):
 assert int.from_bytes(original[at:at+4],'big')==0x80417db8 and before[at:at+4]==original[at:at+4]
 struct.pack_into('>I',dol,at,target);ranges.append((at,at+4))
caves=json.loads((W/'ui_v08/name_caves.json').read_text());names=patch_names(dol,original,caves,protected)
ranges.extend((int(p,16),int(p,16)+4) for p in names['reclaimed_words']);ranges.extend((int(p,16)-0x80016580,int(p,16)-0x80016580+4) for p in names['hooks'])
assert all(before[p:p+4]==dol[p:p+4] for p in protected)
assert all(a==b or any(lo<=i<hi for lo,hi in ranges) for i,(a,b) in enumerate(zip(before,dol)))
# Check the actual result routine's direct string addresses, including the
# resignation constants and completion format that were Japanese in the shot.
result_addresses=[0x250a54,0x250a80,0x2d993c]
assert all(all(c<128 for c in dol[a:dol.index(0,a)]) for a in result_addresses)
def archive(path):
 o,s,_=files[path];f.seek(o);return decode(f.read(s))
blobs={};graphics=[];previews=[];font_report={}
for path in ['2D/agbctrdl.bpe','2D/win.bpe','font24/hggc24.bpe']:
 b=archive(path)
 if path.startswith('font'):mapping,font_report=font_edges(b)
 else:mapping=render_graphics(path,b)
 look=dict(resources(b));replace={}
 for n,im in mapping.items():
  old,_=texture(b,look[n]);assert old.size==im.size;replace[n]=rgba_resource(b,look[n],im);assert texture(replace[n],0)[0].tobytes()==im.tobytes();im.save(OUT/'assets'/(path.split('/')[-1]+'.'+n+'.png'));graphics.append(dict(path=path,asset=n,dimensions=list(im.size),rgba8_exact=True));previews.append((n,im))
 new=rebuild_archive(b,replace);blob=len(new).to_bytes(4,'big')+bytes([254,127,254,255])+len(new).to_bytes(4,'big')+new;assert decode(blob)==new;blobs[path]=(blob,new)
lessons={**BEGINNER,**ATARI,**NEW};scripts=[]
for n,entries in sorted(lessons.items()):
 path='script/tutorial/'+n+'.gcs';orig=(W/'extracted'/path).read_bytes();verify_original_roundtrip(orig,True);_,_,rows=text_tail(orig);assert len(entries)==len(rows),(n,len(entries),len(rows));en=[]
 for i,(s,row) in enumerate(zip(entries,rows)):
  # A6 headers are one-line banners. LF is ignored by that renderer.
  is_header=any(int.from_bytes(orig[p-4:p],'big')==0xa6 for p in row['references'])
  if is_header:
   s=' '.join(s.split());s=re.sub(r'^(\d-\d) (?=[A-Za-z])',r'\1: ',s);assert cells(s)<=44,(n,i,s)
  else:s=wrap(s)
  assert '\r' not in s
  assert re.findall(r'\$\d|%[sd]',row['japanese'])==re.findall(r'\$\d|%[sd]',s)
  for symbol in '△□⑪⑫':assert row['japanese'].count(symbol)==s.count(symbol),(n,i,symbol)
  en.append(s)
 new,report=rebuild(orig,en,False,True);blobs[path]=(new,new);scripts.append(dict(path=path,entries=len(rows),new_translation=n in NEW,original_roundtrip_exact=True,non_pointer_code_unchanged=True,translations=report))
assert sum(s['entries'] for s in scripts)==1347 and sum(s['entries'] for s in scripts if s['new_translation'])==907
sheet=Image.new('RGB',(1000,1200),'#405060');d=ImageDraw.Draw(sheet);yy=10
for n,im in previews:
 im=im.copy();im.thumbnail((980,450));d.text((10,yy),n,fill='white');sheet.paste(im,(10,yy+20),im);yy+=im.height+45
sheet=sheet.crop((0,0,1000,yy))
sheet.save(OUT/'asset_preview.png')
(OUT/'script_preview.txt').write_text('\n\n'.join(s['path']+'\n'+'\n'.join(str(r['index'])+': '+r['english'].replace('\n',' / ') for r in s['translations']) for s in scripts),encoding='utf8')
if '--preview' in sys.argv:
 print('Preview passed:',len(edits),'DOL strings;',len(scripts),'courses;',sum(s['entries'] for s in scripts),'entries;',names['wrapper_ppc_tests'],'PPC name tests.');sys.exit()

assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
inv=json.loads((W/'inventory.json').read_text(encoding='utf8'));placement=(max(o+s for o,s,_ in files.values() if o<1085734912)+0x7fff)&~0x7fff;relocated={}
for path,(blob,_) in blobs.items():
 assert placement+len(blob)<1085734912
 assert all(placement+len(blob)<=e['offset'] or placement>=e['offset']+e['size'] for e in inv)
 assert all(placement+len(blob)<=o or placement>=o+s for o,s,_ in files.values())
 relocated[path]=dict(offset=placement,size=len(blob));struct.pack_into('>II',fst,files[path][2]*12+4,placement,len(blob));placement=(placement+len(blob)+0x7fff)&~0x7fff
f.close();shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as g:
 g.seek(meta['dol_offset']);g.write(dol);g.seek(meta['fst_offset']);g.write(fst)
 for path,(blob,_) in blobs.items():g.seek(relocated[path]['offset']);g.write(blob)
with TARGET.open('rb') as g:
 g.seek(meta['dol_offset']);assert g.read(len(dol))==dol;g.seek(meta['fst_offset']);assert g.read(len(fst))==fst
 for path,(blob,new) in blobs.items():g.seek(relocated[path]['offset']);got=g.read(len(blob));assert (decode(got) if path.endswith('.bpe') else got)==new
allowed=[(meta['dol_offset']+a,meta['dol_offset']+b) for a,b in ranges]+[(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(v['offset'],v['offset']+v['size']) for v in relocated.values()]
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   checked=0
   for lo,hi in sorted(allowed):
    if hi<=pos or lo>=pos+len(x):continue
    aa=max(0,lo-pos);bb=min(len(x),hi-pos)
    if aa>checked:assert x[checked:aa]==y[checked:aa]
    checked=max(checked,bb)
   assert x[checked:]==y[checked:]
  pos+=len(x)
print('Disc verification passed; generating cumulative patch.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Courses_v13.bps',dict(game='Hikaru no Go 3',version='0.13',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.13',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,dol_strings=edits,result_names=names,font_edges=font_report,prior_code_preserved=True,graphic_checks=graphics,script_checks=scripts,relocated_files=relocated,whole_disc_differences_verified=True,patch=patch,status='Courses 1-3 translated; screenshot repairs; Dolphin verification required; full game incomplete')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('Built',TARGET,report['output_sha256'],flush=True)
