"""Verified staff credit names only; preserve all code, artwork, scripts and GBA content from v42."""
from pathlib import Path
import json, re, shutil, sys
from credits_translation_v43 import TEXT as MATCH, VERIFICATION
import textwrap
TEXT={}
for at,en in MATCH.items():
 TEXT[at]=en
from patch_utils import sha
from bps_patch import make

R=Path(__file__).parent; W=R/'translation_work'
OUT=R/'English_Credits_v43'; OUT.mkdir(exist_ok=True)
BASE=R/'English_GraphicsSmooth_v42/Hikaru no Go 3 - English Graphics Smooth v42.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso'
TARGET=OUT/'Hikaru no Go 3 - English Credits v43.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
meta=json.loads((W/'disc_metadata.json').read_text())
original=(W/'main.dol').read_bytes()
with BASE.open('rb') as f:
 f.seek(meta['dol_offset']); before=f.read(len(original))
dol=bytearray(before)
protected=set()
for folder,key in [('English_Interface_v08','name_display'),('English_Content_v11','hud_names'),('English_Polish_v12','font_uv')]:
 report=json.loads((R/folder/'build_report.json').read_text(encoding='utf8'))
 protected.update(int(p,16) for p in report[key]['reclaimed_words'])
edits={}; skipped=[]
for canonical,en in TEXT.items():
 assert original[canonical-1]==0 and canonical%4==0
 old=original[canonical:original.index(0,canonical)]; new=en.encode('cp932')
 assert len(new)<=len(old),(hex(canonical),len(new),len(old),en)
 assert re.findall(rb'\$[0-9]|%[-0-9]*[sd]',old)==re.findall(rb'\$[0-9]|%[-0-9]*[sd]',new)
 lines=en.split('\u2193');expanded=[re.sub(r'\$[0-9]','X'*12,line) for line in lines]
 assert len(lines)<=3 and max(map(len,expanded))<=26,(hex(canonical),expanded)
 assert not any('\u3040'<=c<='\u9fff' for c in en)
 positions={canonical}
 if False: # no broad duplicate matching for small-data/interface constants
  positions.update(m.start() for m in re.finditer(re.escape(old)+b'\0',original) if 0x22d420<=m.start()<0x27ab00 and original[m.start()-1]==0 and m.start()%4==0)
 for at in sorted(positions):
  if at in edits:
   assert edits[at]['english']==en
   continue
  if before[at:at+len(old)+1]!=old+b'\0':
   skipped.append(dict(offset=hex(at),reason='Already modified; preserved'))
   continue
  # Write only new visible bytes and terminator, preserving all remaining bytes.
  end=at+len(new)+1
  assert not any(at<p+4 and p<end for p in protected)
  assert not any(at<e['end'] and start<end for start,e in edits.items())
  dol[at:end]=new+b'\0'
  edits[at]=dict(offset=hex(at),end=end,canonical=hex(canonical),japanese=old.decode('cp932'),english=en,capacity_bytes=len(old),used_bytes=len(new),lines=len(lines),expanded_line_cells=max(map(len,expanded)))
 assert canonical in edits,(hex(canonical),'Canonical not applied')
assert all(before[p:p+4]==dol[p:p+4] for p in protected)
for i in range(7):
 off,n=[int.from_bytes(original[p+4*i:p+4*i+4],'big') for p in [0,0x90]]
 if n:assert before[off:off+n]==dol[off:off+n]==original[off:off+n]

allowed_dol=sorted((at,e['end']) for at,e in edits.items())
cursor=0
for lo,hi in allowed_dol:
 assert before[cursor:lo]==dol[cursor:lo];cursor=hi
assert before[cursor:]==dol[cursor:]
for at,e in edits.items():
 assert dol[at:dol.index(0,at)].decode('cp932')==e['english']
(OUT/'translated_scenes.txt').write_text('\n\n'.join(e['offset']+' '+e['japanese']+'\n'+e['english'].replace('\u2193','\n') for e in edits.values()),encoding='utf8')
print('Checks passed:',len(TEXT),'canonical strings;',len(edits),'occurrences; protected code exact.',flush=True)
if '--check' in sys.argv:sys.exit()
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 for at,e in edits.items():
  f.seek(meta['dol_offset']+at);f.write(dol[at:e['end']])
with TARGET.open('rb') as f:
 f.seek(meta['dol_offset']);assert f.read(len(dol))==dol
allowed=sorted((meta['dol_offset']+lo,meta['dol_offset']+hi) for lo,hi in allowed_dol)
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   checked=0
   for lo,hi in allowed:
    if hi<=pos or lo>=pos+len(x):continue
    aa=max(0,lo-pos);bb=min(len(x),hi-pos)
    assert x[checked:aa]==y[checked:aa];checked=max(checked,bb)
   assert x[checked:]==y[checked:]
  pos+=len(x)
print('Whole disc verified: only recorded match string bytes differ. Creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Credits_v43.bps',dict(game='Hikaru no Go 3',version='0.43',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.43',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,canonical_strings=len(TEXT),match_entries=len(MATCH),all_executable_text_sections_exact_original=True,new_string_occurrences=len(edits),edits=list(edits.values()),skipped=skipped,all_other_disc_bytes_exact_v42=True,protected_code_words_unchanged=len(protected),artwork_font_scripts_fst_unchanged=True,whole_disc_differences_verified=True,patch=patch,verified_staff_names=VERIFICATION,collectible_packaging='Japanese retained with user approval',status='Verified staff credit romanization; uncertain names retained; Dolphin credits layout pending; full game incomplete')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('Built',TARGET,report['output_sha256'],flush=True)
