"""Reviewed wording only: DOL constants, proven GCS operands and GBA text pools."""
from pathlib import Path
import json,re,struct,shutil,sys,csv,unicodedata,html,hashlib
from dialogue_polish_v50 import REVISIONS,SCRIPT_REVISIONS
from check_dialogue_v50 import wrap
from qa_research_v10 import current_files
from gcs_rebuild import verify_original_roundtrip
from gcs_text import text_tail
from patch_utils import sha
from bps_patch import make
from gba_lz_v34 import decode

R=Path(__file__).parent;W=R/'translation_work';AUD=W/'dialogue_v50'
BASE=R/'English_QA_v49/Hikaru no Go 3 - English QA v49.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso'
OUT=R/'English_Dialogue_v50';OUT.mkdir(exist_ok=True)
TARGET=OUT/'Hikaru no Go 3 - English Dialogue v50.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
meta=json.loads((W/'disc_metadata.json').read_text())
orig=(W/'main.dol').read_bytes()
with BASE.open('rb') as f:f.seek(meta['dol_offset']);before=f.read(len(orig))
dol=bytearray(before);changes=[];writes=[];dol_rows=[]
protected=set()
for folder,key in [('English_Interface_v08','name_display'),('English_Content_v11','hud_names'),('English_Polish_v12','font_uv')]:
 rr=json.loads((R/folder/'build_report.json').read_text(encoding='utf8'))
 protected.update(int(p,16) for p in rr[key]['reclaimed_words'])
tokens=lambda s:re.findall(r'\$[0-9]|%[-0-9]*[sd]',s)
cells=lambda s:sum(2 if unicodedata.east_asian_width(c) in ('W','F','A') else 1 for c in s)
def fit(s,width,lines):
 assert '\r' not in s
 expanded=[re.sub(r'\$[0-9]','X'*12,l) for l in re.split('[\n\u2193]',s)]
 assert len(expanded)<=lines and max(map(cells,expanded))<=width,(s,expanded)
def reason(i,area):
 if area=='DOL dialogue':
  if i in (23,31,39,60,71,97,106,112,268,375,492,495,505,547,955,1067,1107,1389,1491):return 'Replaces a literal expression with natural English while retaining the intended meaning.'
  if i in (143,178,213,282,313,345,376,409,443):return 'Uses the natural future form for announcing nigiri.'
  return 'More natural spoken English; fits the original byte slot and provisional bubble limits.'
 if i in (312,326,742):return 'Clarifies which player is harmed by the move.'
 if i in (118,121,124,127):return 'Uses the precise nakade term rather than the misleading idea of killing an eye.'
 if i in (1037,1062):return 'White defends against Black; the old wording suggested White was defending Black.'
 if i in (1345,1355):return 'Clarifies the life-and-death explanation and the location of the eye.'
 return 'Clearer instructional English; diagram labels, move numbers and Go meaning retained.'

unique=json.loads((AUD/'dol_unique.json').read_text(encoding='utf8'))
for i,s in sorted(REVISIONS.items()):
 row=unique[i];en=wrap(s);fit(en,26,3)
 assert tokens(en)==tokens(row['japanese'])
 if en==row['english']:continue
 for off in row['offsets']:
  at=int(off,16);old=orig[at:orig.index(0,at)]
  assert old.decode('cp932')==row['japanese']
  assert before[at:before.index(0,at)].decode('cp932')==row['english']
  raw=en.encode('cp932')+b'\0';assert len(raw)<=len(old)+1,(i,off)
  assert not any(at<p+4 and p<at+len(raw) for p in protected)
  dol[at:at+len(raw)]=raw
  writes.append((meta['dol_offset']+at,raw,'DOL '+off))
  entry=dict(area='DOL dialogue',id=i,offset=off,japanese=row['japanese'],before=row['english'],after=en,reason=reason(i,'DOL dialogue'),capacity_bytes=len(old),used_bytes=len(raw)-1)
  dol_rows.append(entry);changes.append(entry)
for p in protected:assert before[p:p+4]==dol[p:p+4]
for i in range(7):
 off,n=[int.from_bytes(orig[p+4*i:p+4*i+4],'big') for p in (0,0x90)]
 assert not n or orig[off:off+n]==before[off:off+n]==dol[off:off+n]

sr=json.loads((AUD/'script_unique.json').read_text(encoding='utf8'))
corpus=json.loads((AUD/'script_corpus.json').read_text(encoding='utf8'))
locations={(r['path'],r['index']):r for r in corpus}
byfile={}
for i,s in sorted(SCRIPT_REVISIONS.items()):
 row=sr[i];header=bool(re.match(r'\d-\d\d:',row['english']))
 en=s if header else wrap(s,22).replace('\u2193','\n')
 fit(en,44 if header else 22,1 if header else 3)
 assert tokens(en)==tokens(row['japanese'])
 assert {c:en.count(c) for c in '△□×⑪⑫Д'}=={c:row['english'].count(c) for c in '△□×⑪⑫Д'}
 if en==row['english']:continue
 for path,index in row['locations']:
  old=locations[(path,index)]
  byfile.setdefault(path,[]).append((i,index,en,old))

f,fst,files=current_files(BASE);fst_before=bytes(fst);resource_blobs=[];script_reports=[]
# Reuse the project's proven free extent below the native streaming region.
# Protect both the original resource inventory and every current active file.
inventory=json.loads((W/'inventory.json').read_text(encoding='utf8'))
streaming_boundary=1085734912
cursor=(max(off+n for off,n,_ in files.values() if off<streaming_boundary)+0x7fff)&~0x7fff
for path,edits in sorted(byfile.items()):
 off,size,entry=files[path];f.seek(off);old=f.read(size);new=bytearray(old)
 original=(W/'extracted'/path).read_bytes()
 verify_original_roundtrip(original,coordinate_operands=True)
 base,start,rr=text_tail(original);ranges=[];pointers=[]
 for i,index,en,row in edits:
  refs=row['references'];p=base+int.from_bytes(old[refs[0]:refs[0]+4],'big')
  assert old[p:old.index(0,p)].decode('cp932')==row['english']
  raw=en.encode('cp932')+b'\0';oldlen=len(row['english'].encode('cp932'))+1
  if len(raw)<=oldlen:
   dest=p;new[p:p+len(raw)]=raw;ranges.append((p,p+len(raw)))
  else:
   new.extend(b'\xcd'*((-len(new))%4));dest=len(new);new.extend(raw)
   for ref in refs:
    assert int.from_bytes(original[ref-4:ref],'big') in (0x87,0xa6,0x103)
    assert base+int.from_bytes(old[ref:ref+4],'big')==p
    struct.pack_into('>I',new,ref,dest-base);ranges.append((ref,ref+4));pointers.append(ref)
  for ref in refs:
   q=base+int.from_bytes(new[ref:ref+4],'big')
   assert new[q:new.index(0,q)].decode('cp932')==en
  changes.append(dict(area='GameCube script',id=i,path=path,index=index,japanese=row['japanese'],before=row['english'],after=en,reason=reason(i,'GameCube script')))
 # All existing script bytes outside exact text writes/proven pointer words stay.
 new.extend(b'\xcd'*((-len(new))%4))
 check=0
 for lo,hi in sorted(ranges):assert old[check:lo]==new[check:lo];check=max(check,hi)
 assert old[check:]==new[check:len(old)]
 expected={index:en for _,index,en,_ in edits}
 for (record_path,index),record in locations.items():
  if record_path!=path:continue
  for ref in record['references']:
   q=base+int.from_bytes(new[ref:ref+4],'big')
   assert new[q:new.index(0,q)].decode('cp932')==expected.get(index,record['english']),(path,index,'Unrelated text must remain intact')
 if len(new)<=size:destoff=off
 else:
  destoff=cursor;cursor=(cursor+len(new)+0x7fff)&~0x7fff
  assert cursor<streaming_boundary
  assert all(destoff+len(new)<=e['offset'] or destoff>=e['offset']+e['size'] for e in inventory)
  assert all(destoff+len(new)<=o or destoff>=o+n for o,n,_ in files.values())
  struct.pack_into('>II',fst,entry*12+4,destoff,len(new))
 resource_blobs.append((destoff,bytes(new),path,None))
 script_reports.append(dict(path=path,previous_size=size,new_size=len(new),pointer_words=pointers,existing_nontext_bytes_exact=True,original_roundtrip_verified=True))
f.close()
print('Prepared',len(dol_rows),'DOL occurrences and',sum(len(v) for v in byfile.values()),'script occurrences in',len(byfile),'files.',flush=True)

gp=AUD/'gba_prepared';gm=json.loads((gp/'manifest.json').read_text(encoding='utf8'))
assert gm['revision_hash']==hashlib.sha256(json.dumps(SCRIPT_REVISIONS,sort_keys=True,ensure_ascii=True).encode()).hexdigest()
gba_blobs=[]
for row in gm['blobs']:
 blob=(gp/row['file']).read_bytes();part=(gp/row['decoded']).read_bytes()
 assert decode(blob)==part
 assert files[row['path']][:2]==(row['offset'],len(blob))
 gba_blobs.append((row['offset'],blob,row['path'],part))
changes.extend(gm['changes'])

# The user's requested before/after record is generated before making an ISO.
def clean(s):return s.replace('\u2193',' / ').replace('\n',' / ')
with (OUT/'Dialogue_changes.csv').open('w',encoding='utf-8-sig',newline='') as g:
 writer=csv.DictWriter(g,fieldnames=['area','location','japanese','before','after','reason']);writer.writeheader()
 for c in changes:writer.writerow({k:clean(str(v)) for k,v in dict(area=c['area'],location=c.get('path',('Book '+c['book']) if 'book' in c else 'DOL')+' '+str(c.get('offset',c.get('index',''))),japanese=c['japanese'],before=c['before'],after=c['after'],reason=c.get('reason','Same reviewed feedback as the corresponding GameCube exercise.')).items()})
md=['# Dialogue revisions: v49 → v50','',f'{len(changes)} text occurrences changed. Line breaks are shown as `/` below.','',
 'This is an editorial pass over the inventoried English text, with Japanese source checks for revisions. It is not proof that every optional runtime branch has been found or tested.',
 '', '| Location | Japanese | Before (v49) | After (v50) |','|---|---|---|---|']
for c in changes:
 loc=(c.get('path') or ('GBA book '+c['book'] if 'book' in c else 'DOL'))+' '+str(c.get('offset',c.get('index','')))
 esc=lambda s:clean(s).replace('|','\\|')
 md.append('| '+' | '.join(esc(s) for s in (loc,c['japanese'],c['before'],c['after']))+' |')
(OUT/'Dialogue_changes.md').write_text('\n'.join(md)+'\n',encoding='utf8')
(OUT/'changes.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),encoding='utf8')
if '--check' in sys.argv:print('All text checks passed.',flush=True);sys.exit()

assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
assert not TARGET.exists(),'Never overwrite an existing finished candidate'
shutil.copyfile(BASE,TARGET)
allblobs=resource_blobs+gba_blobs
with TARGET.open('r+b') as g:
 for off,raw,_ in writes:g.seek(off);g.write(raw)
 g.seek(meta['fst_offset']);g.write(fst)
 for off,blob,_,_ in allblobs:g.seek(off);g.write(blob)
with TARGET.open('rb') as g:
 g.seek(meta['dol_offset']);assert g.read(len(dol))==dol
for off,raw,_ in writes:
 assert dol[off-meta['dol_offset']:off-meta['dol_offset']+len(raw)]==raw
g,finished_fst,finished_files=current_files(TARGET);assert finished_fst==fst
for off,blob,path,part in allblobs:
 assert finished_files[path][:2]==(off,len(blob));g.seek(off);assert g.read(len(blob))==blob
 if part is not None:assert decode(blob)==part
g.close()
# Verify all 719 active resources, not just files expected to change.
a,_,af=current_files(BASE);b,_,bf=current_files(TARGET)
changed_paths={p for _,_,p,_ in allblobs}
assert af.keys()==bf.keys()
for path in af:
 if path in changed_paths:continue
 ao,an,_=af[path];bo,bn,_=bf[path];assert an==bn
 a.seek(ao);b.seek(bo);assert a.read(an)==b.read(bn),path
a.close();b.close()
allowed=sorted([(off,off+len(raw)) for off,raw,_ in writes]+[(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(off,off+len(blob)) for off,blob,_,_ in allblobs])
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   check=0
   for lo,hi in allowed:
    if hi<=pos or lo>=pos+len(x):continue
    ll=max(0,lo-pos);hh=min(len(x),hi-pos)
    assert x[check:ll]==y[check:ll];check=max(check,hh)
   assert x[check:]==y[check:]
  pos+=len(x)
print('Whole disc/readback/all active resource checks passed. Creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Dialogue_v50.bps',dict(game='Hikaru no Go 3',version='0.50',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.50',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,
 reviewed_dol_occurrences=2040,reviewed_dol_unique_pairs=1740,reviewed_script_entries=3079,reviewed_script_unique_pairs=2814,reviewed_gba_book_occurrences=2009,
 revised_dol_occurrences=len(dol_rows),revised_script_occurrences=sum(len(v) for v in byfile.values()),revised_gba_feedback_occurrences=len(gm['changes']),total_changed_occurrences=len(changes),
 all_executable_text_sections_exact_original=True,protected_words_unchanged=True,all_artwork_and_fonts_exact_v49=True,all_other_active_resources_exact_v49=True,all_active_files_compared=len(af),
 scripts=script_reports,gba_books=gm['reports'],gba_segments=len(gba_blobs),whole_disc_differences_verified=True,patch=patch,
 status='Editorial dialogue pass; static storage, layout, tokens and reconstruction checks passed. Dolphin layout, Story branch progression and GBA transfer still require runtime testing. Full-game coverage is not certified.')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'README.md').write_text(f'''# English Dialogue v50

Built from v49. {len(changes)} revised text occurrences across Story, match reactions, tactical commentary, lessons, exercises and matching GBA feedback.

Read `Dialogue_changes.md` for Japanese / before / after, or open `Dialogue_changes.csv` in a spreadsheet. All v49 artwork and font fixes are retained. Original and prior ISOs are preserved. Player-name spacing remains unresolved; saves and runtime hooks are unchanged.

Validation: original executable instructions; exact placeholder order; DOL original CP932 capacities and provisional 26-cell/3-line bubbles with 12-cell name reserves; script 22-cell/3-line speech and 44-cell headings; GCS original roundtrips and proven pointer words; GBA native sizes and independent LZ decoding; all active resource/readback/whole-disc checks; cumulative BPS reconstruction.

Cold boot the ISO with a normal memory-card save. Test Story/match result progression, room/Management/cafe transitions, lessons and exercises. New wording/layout and GBA transfer have not been certified in Dolphin. This review covers inventoried text; optional runtime completeness remains unproven.

ISO SHA256: `{report['output_sha256']}`
''',encoding='utf8')
print('Built',TARGET,report['output_sha256'],flush=True)
