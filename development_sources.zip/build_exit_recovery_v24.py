"""Result-exit diagnostic: original executable instructions, retained translations."""
from pathlib import Path
import json,struct,shutil,sys
from patch_utils import sha
from bps_patch import make
R=Path(__file__).parent;W=R/'translation_work';OUT=R/'English_ExitRecovery_v24';OUT.mkdir(exist_ok=True)
BASE=R/'English_Story_v23/Hikaru no Go 3 - English Story v23.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso'
TARGET=OUT/'Hikaru no Go 3 - English Exit Recovery v24.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
meta=json.loads((W/'disc_metadata.json').read_text());original=(W/'main.dol').read_bytes()
with BASE.open('rb') as f:f.seek(meta['dol_offset']);before=f.read(len(original))
dol=bytearray(before);edits={};sections=[]
for i in range(7):
 off,addr,n=[int.from_bytes(original[p+4*i:p+4*i+4],'big') for p in [0,0x48,0x90]]
 if not n:continue
 assert n%4==0
 sections.append(dict(offset=off,address=hex(addr),size=n))
 for at in range(off,off+n,4):
  if dol[at:at+4]!=original[at:at+4]:
   edits[at]=dict(offset=hex(at),address=hex(addr+at-off),before=dol[at:at+4].hex(),restored=original[at:at+4].hex(),kind='original instruction')
   dol[at:at+4]=original[at:at+4]
helpers=set()
for folder,key in [('English_Interface_v08','name_display'),('English_Content_v11','hud_names'),('English_Polish_v12','font_uv')]:
 r=json.loads((R/folder/'build_report.json').read_text(encoding='utf8'))
 helpers.update(int(p,16) for p in r[key]['reclaimed_words'])
for at in sorted(helpers):
 if dol[at:at+4]!=original[at:at+4]:
  edits[at]=dict(offset=hex(at),address=hex(at+0x80003000),before=dol[at:at+4].hex(),restored=original[at:at+4].hex(),kind='removed helper/code constant')
  dol[at:at+4]=original[at:at+4]
for sec in sections:
 at=sec['offset'];n=sec['size'];assert dol[at:at+n]==original[at:at+n]
# Verify every currently visible English replacement recoverable from historical
# reports. Skip superseded strings and non-DOL script/artwork report entries.
checked=set()
def inspect(v):
 if isinstance(v,list):
  for item in v:inspect(item)
 elif isinstance(v,dict):
  if 'english' in v and isinstance(v['english'],str) and 'offset' in v:
   at=v['offset']
   try:at=int(at,16) if isinstance(at,str) else int(at);raw=v['english'].encode('cp932')+b'\0'
   except (ValueError,UnicodeEncodeError,TypeError):at=-1;raw=b''
   if at>=0 and raw and before[at:at+len(raw)]==raw:
    assert dol[at:at+len(raw)]==raw,('visible translation changed',hex(at));checked.add((at,raw))
  for item in v.values():inspect(item)
for p in R.glob('English_*/build_report.json'):
 inspect(json.loads(p.read_text(encoding='utf8')))
assert len(checked)>1000,len(checked)
assert sum(e['kind']=='original instruction' for e in edits.values())==14
ranges=sorted((at,at+4) for at in edits);cursor=0
for lo,hi in ranges:assert before[cursor:lo]==dol[cursor:lo];cursor=hi
assert before[cursor:]==dol[cursor:]
print('Checks:',14,'instruction sites restored;',len(helpers),'helper words;',len(checked),'visible translations preserved.',flush=True)
if '--check' in sys.argv:sys.exit()
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 for lo,hi in ranges:f.seek(meta['dol_offset']+lo);f.write(dol[lo:hi])
with TARGET.open('rb') as f:f.seek(meta['dol_offset']);assert f.read(len(dol))==dol
allowed=[(meta['dol_offset']+lo,meta['dol_offset']+hi) for lo,hi in ranges]
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   checked_to=0
   for lo,hi in allowed:
    if hi<=pos or lo>=pos+len(x):continue
    aa=max(0,lo-pos);bb=min(len(x),hi-pos)
    assert x[checked_to:aa]==y[checked_to:aa];checked_to=max(checked_to,bb)
   assert x[checked_to:]==y[checked_to:]
  pos+=len(x)
print('Whole disc verified: scripts, artwork, font and FST exact v23. Creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_ExitRecovery_v24.bps',dict(game='Hikaru no Go 3',version='0.24',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.24',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,all_executable_text_sections_exact_original=True,restored_instruction_sites=14,removed_helper_words=len(helpers),visible_translations_preserved=len(checked),text_sections=sections,edits=list(edits.values()),all_other_disc_bytes_exact_v23=True,artwork_font_scripts_fst_unchanged=True,whole_disc_differences_verified=True,patch=patch,root_cause_confirmed=False,status='Akari Story result exit freezes after X; original-instruction diagnostic candidate; actual Dolphin test required')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('Built',TARGET,report['output_sha256'],flush=True)
