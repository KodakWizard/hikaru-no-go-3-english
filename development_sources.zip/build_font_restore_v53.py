"""Restore exact v51 stored font; retain all v52 text, wrapping and artwork."""
from pathlib import Path
import json,struct,shutil
from qa_research_v10 import current_files
from patch_utils import sha
from bps_patch import make

R=Path(__file__).resolve().parent
BASE=R/'English_QA_v52/Hikaru no Go 3 - English QA v52.iso'
FONT=R/'English_QA_v51/Hikaru no Go 3 - English QA v51.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso'
OUT=R/'English_FontRestore_v53';OUT.mkdir(exist_ok=True)
TARGET=OUT/'Hikaru no Go 3 - English Font Restore v53.iso'
assert not TARGET.exists(),'Preserve any existing candidate.'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
reference=json.loads((FONT.parent/'build_report.json').read_text(encoding='utf8'))
meta=json.loads((R/'translation_work/disc_metadata.json').read_text())
assert sha(BASE)==prior['output_sha256'] and sha(FONT)==reference['output_sha256'] and sha(SOURCE)==prior['source_sha256']
f,fst,files=current_files(BASE);g,_,fonts=current_files(FONT)
path='font24/hggc24.bpe';off,size,index=fonts[path];g.seek(off);stored=g.read(size)
# v52 appended its new font, preserving the previous font's stored bytes.
f.seek(off);assert f.read(size)==stored
assert all(off+size<=o or off>=o+n for p,(o,n,_) in files.items() if p!=path)
oldfst=bytes(fst);assert files[path][2]==index
struct.pack_into('>II',fst,index*12+4,off,size)
lo=index*12+4;hi=lo+8
assert oldfst[:lo]==fst[:lo] and oldfst[hi:]==fst[hi:]
f.close();g.close()
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:f.seek(meta['fst_offset']+lo);f.write(fst[lo:hi])
f,got,active=current_files(TARGET);g,_,oldactive=current_files(BASE)
assert got==fst and active.keys()==oldactive.keys() and len(active)==719
for p,(o,n,_) in active.items():
    f.seek(o);data=f.read(n)
    if p==path:assert (o,n)==(off,size) and data==stored
    else:
        a,b,_=oldactive[p];g.seek(a);assert data==g.read(b),p
f.close();g.close()
original=(R/'translation_work/main.dol').read_bytes()
with TARGET.open('rb') as f,BASE.open('rb') as g:
    f.seek(meta['dol_offset']);dol=f.read(len(original));g.seek(meta['dol_offset']);assert dol==g.read(len(original))
for i in range(7):
    o=int.from_bytes(original[i*4:i*4+4],'big');n=int.from_bytes(original[0x90+i*4:0x94+i*4],'big')
    if n:assert dol[o:o+n]==original[o:o+n]
allowed_lo=meta['fst_offset']+lo;allowed_hi=meta['fst_offset']+hi
with BASE.open('rb') as a,TARGET.open('rb') as b:
    pos=0
    while True:
        x=a.read(1048576);y=b.read(1048576)
        if not x:assert not y;break
        assert len(x)==len(y)
        if x!=y:
            assert pos<=allowed_lo<allowed_hi<=pos+len(x)
            assert x[:allowed_lo-pos]==y[:allowed_lo-pos] and x[allowed_hi-pos:]==y[allowed_hi-pos:]
        pos+=len(x)
print('Only font FST pointer/size differ from v52; exact v51 stored font verified. Creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_FontRestore_v53.bps',dict(game='Hikaru no Go 3',version='0.53',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(FONT)==reference['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.53',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],
            font_reference_sha256=reference['output_sha256'],output_sha256=sha(TARGET),
            original_and_previous_unchanged=True,all_active_files_compared=719,
            exact_v51_stored_font=True,font_path=path,font_offset=off,font_size=size,
            only_font_fst_pointer_and_size_differ_v52=True,dol_and_all_text_exact_v52=True,
            v52_punctuation_and_all_796_battle_bubble_entries_retained=True,
            scripts_gba_all_other_art_exact_v52=True,all_executable_text_sections_exact_original=True,
            removed_hooks_disabled=True,saves_settings_untouched=True,
            whole_disc_differences_verified=True,patch=patch,
            status='User preferred previous conversation font. Exact v51 font restored; no new font experiment. Appearance pending user comparison. Earlier v51 outline clipping is not claimed resolved.')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'README.md').write_text('''# English Font Restore v53

Restores the exact v51 font archive after the user reported uneven letter weights in the v52 inset version. No resampling, re-rendering, palette change, font enlargement or runtime font hook is applied.

All v52 punctuation corrections and the 796-entry battle-bubble audit (552 reflows, 31 shortened lines) are retained exactly. All other v52 artwork, scripts and GBA content are retained.

Only the active font archive's FST offset/size entry changes from v52. The original v51 stored font is reused byte-for-byte. All 719 active resources, finished readback, complete DOL, original executable sections, whole-disc permitted difference, original/base/reference hashes and cumulative BPS reconstruction are checked.

Use this ISO as the latest candidate. Cold boot with a normal save. Live appearance has not been tested here; v51's earlier outline clipping is not claimed fixed by this restoration. Player-name spacing and broader translation coverage gaps remain unresolved. Saves and normal emulator settings are untouched. All previous builds are preserved.

The before/after text records remain in English_QA_v52/punctuation_changes.md and battle_bubble_wording_changes.md.
''',encoding='utf8')
p=R/'AGENTS.md';old=p.read_text(encoding='utf8')
intro=f'''Latest candidate English_FontRestore_v53 from v52. User dislikes v52 resized conversation glyphs/uneven apparent weights and prefers previous font. Restores ENTIRE active font24/hggc24.bpe to EXACT v51 stored bytes, reusing still-preserved v51 extent after checking no active-file overlap. ONLY8-byte fontFSTpointer/size field changes in wholeISO vs v52; no recompression/redrawing/resampling/palette/UV/codehook changes. All719activefiles compared, all other resources/DOL/text/scripts/GBA/title/art EXACTv52;35punctuation corrections and796battleentries/552reflows/31shortenings retained. Executable sections original, removedhooks disabled, saves/settings untouched. Whole-disc/readback/base+fontreference+originalhash/cumulativeBPS reconstruction pass. ISO SHA256 {report['output_sha256']}. Appearance pending user comparison; earlier v51 edge clipping NOT claimed fixed, playername spacing unresolved, fulltranslation notcertified. Source build_font_restore_v53.py. Preserve original/prior builds.\n\n'''
if not old.startswith('Latest candidate English_FontRestore_v53 '):p.write_text(intro+old,encoding='utf8')
print('Built',TARGET,report['output_sha256'],flush=True)
