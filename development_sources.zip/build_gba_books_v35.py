"""English text pools for all five GBA problem books; native file sizes fixed."""
from pathlib import Path
import json,re,shutil,sys,hashlib
from gba_lz_v34 import decode,encode_optimal
from qa_research_v10 import current_files
from patch_utils import sha
from bps_patch import make

R=Path(__file__).parent;W=R/'translation_work'
BASE=R/'English_GBA_v34/Hikaru no Go 3 - English GBA v34.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso'
OUT=R/'English_GBA_Books_v35';OUT.mkdir(exist_ok=True)
TARGET=OUT/'Hikaru no Go 3 - English GBA Books v35.iso'
manifest=json.loads((R/'gba_books_manifest_v35.json').read_text(encoding='utf8'))
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))

def independent_decode(data):
    size=int.from_bytes(data[:4],'little')>>8;result=[];cursor=4
    while len(result)<size:
        flags=data[cursor];cursor+=1
        for mask in (128,64,32,16,8,4,2,1):
            if len(result)==size:return bytes(result)
            if flags&mask:
                value=int.from_bytes(data[cursor:cursor+2],'big');cursor+=2
                for _ in range((value>>12)+3):result.append(result[-((value&4095)+1)])
            else:result.append(data[cursor]);cursor+=1
    return bytes(result)

def replace_pool(original,rows,strategy=('lex',False,0)):
    """Reclaim only verified old strings plus intervening C-string alignment."""
    pools=[]
    for row in sorted(rows,key=lambda r:r['offset']):
        at=row['offset'];raw=row['japanese'].encode('cp932');end=at+len(raw)+1
        assert original[at:end]==raw+b'\0'
        if pools and at==((pools[-1][1]+3)&~3) and at-pools[-1][1]<=3 and all(v in (0,0xcd) for v in original[pools[-1][1]:at]):
            pools[-1][1]=end
        elif pools and at==pools[-1][1]:pools[-1][1]=end
        else:pools.append([at,end])
    free=[p.copy() for p in pools];out=bytearray(original);placed={}
    ordering,best_fit,rotate=strategy
    if free:
        rotate%=len(free);free=free[rotate:]+free[:rotate]
    for lo,hi in pools:out[lo:hi]=b'\0'*(hi-lo)
    unique={r['english'] for r in rows}
    key=(lambda s:s[::-1]) if ordering=='suffix' else ((lambda s:(-len(s.encode('cp932')),s)) if ordering=='length' else (lambda s:s))
    for en in sorted(unique,key=key,reverse=ordering=='reverse'):
        raw=en.encode('cp932')+b'\0';fits=[(hi-lo,i) for i,(lo,hi) in enumerate(free) if hi-lo>=len(raw)]
        assert fits,('Cannot fit text in verified original pools',len(raw),en)
        _,i=min(fits) if best_fit else fits[0];lo,hi=free[i];out[lo:lo+len(raw)]=raw;placed[en]=lo;free[i][0]+=len(raw)
    pointers={};edits=[]
    for row in rows:
        old=row['offset'];new=placed[row['english']]
        for p in row['references']:
            assert int.from_bytes(original[p:p+4],'little')==0x09f00000+old
            assert not any(lo<p+4 and p<hi for lo,hi in pools)
            assert p not in pointers or pointers[p]==new
            out[p:p+4]=(0x09f00000+new).to_bytes(4,'little');pointers[p]=new
        edits.append(dict(**row,new_offset=new))
    allowed=sorted(pools+[[p,p+4] for p in pointers]);cursor=0
    for lo,hi in allowed:
        assert original[cursor:lo]==out[cursor:lo];cursor=hi
    assert original[cursor:]==out[cursor:] and len(out)==len(original)
    for row in edits:
        for p in row['references']:
            at=int.from_bytes(out[p:p+4],'little')-0x09f00000
            assert out[at:out.index(0,at)].decode('cp932')==row['english']
    return bytes(out),dict(text_pools=pools,changed_pointer_words=len(pointers),unique_english_strings=len(placed),entries=len(rows),translations=edits,placement_strategy=strategy,only_verified_text_pools_and_pointer_words_changed=True)

f,fst,files=current_files(BASE);raws={};decoded={};common_paths=[]
for i in range(40):common_paths.append(f'gba/dacs/tutocmn/tutorial1_dacs_0_{i}_LZ.bin')
book_paths={k:sorted([p for p in files if p.startswith(f'gba/dacs/tutorial{k}_dacs/')],key=lambda p:int(p.split('_')[-2])) for k in manifest}
for path in common_paths+sum(book_paths.values(),[]):
    o,n,_=files[path];f.seek(o);raw=f.read(n);assert raw==(W/'extracted'/path).read_bytes()
    data=decode(raw);assert independent_decode(raw)==data;raws[path]=raw;decoded[path]=data
f.close();common=b''.join(decoded[p] for p in common_paths);assert len(common)==0xa0000
common_rows=[r for r in manifest['1'] if r['offset']<len(common)]
for k,rows in manifest.items():assert [r for r in rows if r['offset']<len(common)]==common_rows
common_new,common_report=replace_pool(common,common_rows)
new_decoded={};cursor=0
for path in common_paths:
    n=len(decoded[path]);new_decoded[path]=common_new[cursor:cursor+n];cursor+=n
book_reports=[];roms={}
for k,paths in book_paths.items():
    original=common+b''.join(decoded[p] for p in paths)
    rows=[r for r in manifest[k] if r['offset']>=len(common)]
    # All exercise references are verified bytecode operands (0x54/0x63),
    # or mission/result pointer tables inside the book. Native ARM code
    # lives in the unchanged common engine; no instructions are rewritten.
    strategies=[('lex',False,0),('reverse',False,0),('lex',True,0),('reverse',True,0),('suffix',False,0),('suffix',True,0),('length',True,0)]
    strategies += [('lex',False,n) for n in range(1,65)]
    preferred={'1':('suffix',True,0),'2':('lex',False,0),'3':('lex',False,8),'4':('lex',False,30),'5':('lex',False,0)}[k]
    strategies=[preferred]+[s for s in strategies if s!=preferred]
    if k=='4':strategies=[preferred]+[('lex',False,n) for n in range(25,65) if n!=30]+strategies
    for strategy in strategies:
        try:new,report=replace_pool(original,rows,strategy)
        except AssertionError as exc:
            if exc.args and isinstance(exc.args[0],tuple) and exc.args[0][0]=='Cannot fit text in verified original pools':continue
            raise
        cursor=len(common);overflow=[]
        for path in paths:
            n=len(decoded[path]);size=len(encode_optimal(new[cursor:cursor+n]));cursor+=n
            if size>len(raws[path]):overflow.append(size-len(raws[path]))
        print('Book',k,'placement',strategy,'excess bytes',sum(overflow),flush=True)
        if not overflow:break
    else:raise AssertionError(('No native-size placement found',k))
    assert new[:len(common)]==common
    new=common_new+new[len(common):];roms[k]=new
    cursor=len(common)
    for path in paths:
        n=len(decoded[path]);new_decoded[path]=new[cursor:cursor+n];cursor+=n
    assert cursor==len(new)
    report.update(book=int(k),exercise_count=50,header_occurrences=sum(r['header'] for r in rows))
    book_reports.append(report)
blobs=[];segment_reports=[];overflows=[]
for path,new in new_decoded.items():
    if new==decoded[path]:continue
    packed=encode_optimal(new);stream_size=len(packed);old=raws[path]
    if stream_size>len(old):overflows.append((path,len(old),stream_size))
    packed+=b'\0'*max(0,len(old)-len(packed));assert decode(packed)==independent_decode(packed)==new
    blobs.append((files[path][0],packed,path,new))
    segment_reports.append(dict(path=path,stored_size=len(old),new_stream_size=stream_size,decoded_size=len(new),native_sizes_preserved=True))
assert not overflows,overflows
entries=common_report['entries']+sum(r['entries'] for r in book_reports)
(OUT/'translation_review.txt').write_text('\n\n'.join('Book '+str(r['book'])+'\n'+'\n'.join(hex(e['offset'])+' -> '+hex(e['new_offset'])+' '+e['english'].replace('\u2193',' / ') for e in r['translations']) for r in book_reports),encoding='utf8')
print('Checked',entries,'physical entries across 250 GBA exercises;',len(blobs),'native files changed.',flush=True)
if '--check' in sys.argv:sys.exit()
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as g:
    for offset,blob,_,_ in blobs:g.seek(offset);g.write(blob)
with TARGET.open('rb') as g:
    for offset,blob,path,new in blobs:
        g.seek(offset);got=g.read(len(blob));assert got==blob and independent_decode(got)==new
allowed=sorted((o,o+len(blob)) for o,blob,*_ in blobs)
with BASE.open('rb') as a,TARGET.open('rb') as b:
    pos=0
    while True:
        x=a.read(1048576);y=b.read(1048576)
        if not x:assert not y;break
        assert len(x)==len(y)
        if x!=y:
            checked=0
            for lo,hi in allowed:
                if hi<=pos or lo>=pos+len(x):continue
                aa=max(0,lo-pos);bb=min(len(x),hi-pos)
                assert x[checked:aa]==y[checked:aa];checked=max(checked,bb)
            assert x[checked:]==y[checked:]
        pos+=len(x)
print('Whole disc verified: GameCube components, GBA instructions and FST preserved. Creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_GBA_Books_v35.bps',dict(game='Hikaru no Go 3',version='0.35',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.35',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,new_physical_text_entries=entries,per_program_entries=sum(len(v) for v in manifest.values()),gba_exercises=250,common=common_report,books=book_reports,segments=segment_reports,gamecube_executable_scripts_art_font_fst_exact_v34=True,gba_native_instructions_unchanged=True,all_file_sizes_and_decoded_sizes_preserved=True,all_other_decoded_bytes_exact=True,whole_disc_differences_verified=True,patch=patch,status='Five GBA problem-book text families translated; actual GBA transfer/layout/gameplay pending; full game incomplete')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('Built',TARGET,report['output_sha256'],flush=True)
