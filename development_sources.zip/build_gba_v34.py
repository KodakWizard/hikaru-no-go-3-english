"""Translate native GBA download text without changing any file size or address."""
from pathlib import Path
import json,re,shutil,sys,random,hashlib
from gba_translation_v34 import TEXT
from gba_lz_v34 import decode,encode_optimal
from qa_research_v10 import current_files
from patch_utils import sha
from bps_patch import make

R=Path(__file__).parent;W=R/'translation_work'
BASE=R/'English_Extras_v33/Hikaru no Go 3 - English Extras v33.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso'
OUT=R/'English_GBA_v34';OUT.mkdir(exist_ok=True)
TARGET=OUT/'Hikaru no Go 3 - English GBA v34.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))

def independent_decode(data):
    size=int.from_bytes(data[:4],'little')>>8;result=[];cursor=4
    while len(result)<size:
        mask=data[cursor];cursor+=1
        for flag in (128,64,32,16,8,4,2,1):
            if len(result)==size:return bytes(result)
            if not mask&flag:result.append(data[cursor]);cursor+=1
            else:
                value=int.from_bytes(data[cursor:cursor+2],'big');cursor+=2
                distance=(value&4095)+1
                for _ in range((value>>12)+3):result.append(result[len(result)-distance])
    return bytes(result)

rng=random.Random(34)
for data in [b'',b'x',b'xx',b'xxx',b'A'*5000,bytes(range(256))*20,
             bytes(rng.randrange(256) for _ in range(4300)),b'ABCD'*4097]:
    packed=encode_optimal(data);assert decode(packed)==independent_decode(packed)==data

f,fst,files=current_files(BASE);segments=[];rom=bytearray()
for i in range(45):
    path=f'gba/dacs/magnet/btlmenu_dacs_{i}'+('_LZ.bin' if i<40 else '.bin')
    offset,size,index=files[path];f.seek(offset);raw=f.read(size)
    original=(W/'extracted'/path).read_bytes();assert original==raw
    data=decode(raw) if i<40 else raw
    if i<40:assert independent_decode(raw)==data
    segments.append(dict(path=path,offset=offset,size=size,start=len(rom),end=len(rom)+len(data),raw=raw,data=data,compressed=i<40))
    rom.extend(data)
f.close();before=bytes(rom);edits=[];token_re=r'%[-0-9]*[sd]'
for at,en in sorted(TEXT.items()):
    old=before[at:before.index(0,at)];jp=old.decode('cp932');new=en.encode('cp932')
    assert any('\u3040'<=c<='\u9fff' or c=='・' for c in jp) or at==0x48fec,(hex(at),jp)
    assert len(new)<=len(old) and '\n' not in en and '\r' not in en
    assert re.findall(token_re,jp)==re.findall(token_re,en),(hex(at),jp,en)
    lines=en.split('\u2193')
    expanded=[re.sub(token_re,lambda m:'X'*(int(re.search(r'\d+',m[0])[0]) if re.search(r'\d+',m[0]) else (12 if m[0].endswith('s') else 4)),line) for line in lines]
    assert len(lines)<=4 and max(map(len,expanded))<=28,(hex(at),expanded)
    refs=[m.start() for m in re.finditer(re.escape((at+0x09f00000).to_bytes(4,'little')),before)]
    assert refs,(hex(at),'No direct pointer reference')
    end=at+len(new)+1;rom[at:end]=new+b'\0'
    edits.append(dict(offset=at,end=end,japanese=jp,english=en,capacity_bytes=len(old),used_bytes=len(new),pointer_references=refs,lines=len(lines),expanded_line_cells=max(map(len,expanded))))
cursor=0
for e in edits:
    assert before[cursor:e['offset']]==rom[cursor:e['offset']];cursor=e['end']
assert before[cursor:]==rom[cursor:] and len(before)==len(rom)
for e in edits:
    assert rom[e['offset']:rom.index(0,e['offset'])].decode('cp932')==e['english']
    for at in e['pointer_references']:assert rom[at:at+4]==before[at:at+4]
blobs=[];segment_reports=[]
for s in segments:
    new=bytes(rom[s['start']:s['end']])
    if new==s['data']:continue
    packed=encode_optimal(new) if s['compressed'] else new
    packed_size=len(packed);assert packed_size<=s['size'],(s['path'],packed_size,s['size'])
    packed+=b'\0'*(s['size']-len(packed));assert len(packed)==len(s['raw'])
    assert (decode(packed) if s['compressed'] else packed)==new
    if s['compressed']:assert independent_decode(packed)==new
    blobs.append((s['offset'],packed,s['path'],new,s['compressed']))
    segment_reports.append(dict(path=s['path'],stored_size=s['size'],new_stream_size=packed_size,decoded_size=len(new),native_format_and_file_size_preserved=True,decoded_text_entries=sum(s['start']<=e['offset']<s['end'] for e in edits)))
assert len(blobs)==3
(OUT/'translation_review.txt').write_text('\n\n'.join(hex(e['offset'])+' '+e['japanese']+'\n'+e['english'].replace('\u2193','\n') for e in edits),encoding='utf8')
print('Checked',len(edits),'directly referenced GBA strings across',len(blobs),'files; native sizes/pointers/code preserved.',flush=True)
print(segment_reports,flush=True)
if '--check' in sys.argv:sys.exit()
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as g:
    for offset,blob,_,_,_ in blobs:g.seek(offset);g.write(blob)
with TARGET.open('rb') as g:
    for offset,blob,path,data,compressed in blobs:
        g.seek(offset);got=g.read(len(blob));assert got==blob
        assert (independent_decode(got) if compressed else got)==data
allowed=sorted((o,o+len(b)) for o,b,*_ in blobs)
with BASE.open('rb') as a,TARGET.open('rb') as b:
    pos=0
    while True:
        x=a.read(1048576);y=b.read(1048576)
        if not x:assert not y;break
        assert len(x)==len(y)
        if x!=y:
            checked=0
            for lo,hi in allowed:
                if hi<=pos or lo>=pos+len(x):continue
                aa=max(0,lo-pos);bb=min(len(x),hi-pos)
                assert x[checked:aa]==y[checked:aa];checked=max(checked,bb)
            assert x[checked:]==y[checked:]
        pos+=len(x)
print('Whole disc verified: only three GBA payloads differ; GameCube executable/scripts/art/font/FST exact v33. Creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_GBA_v34.bps',dict(game='Hikaru no Go 3',version='0.34',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.34',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,new_gba_text_entries=len(edits),edits=edits,segments=segment_reports,gamecube_executable_scripts_art_font_fst_exact_v33=True,gba_all_nontext_decoded_bytes_exact=True,gba_pointers_and_decoded_sizes_unchanged=True,native_lz_independent_roundtrips_verified=True,whole_disc_differences_verified=True,patch=patch,status='Bundled GBA match program text; actual GBA transfer/rendering/gameplay pending; full game incomplete')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('Built',TARGET,report['output_sha256'],flush=True)
