"""Restore English interface/result art using native formats and unchanged decoded archive sizes."""
from pathlib import Path
import json,struct,shutil,hashlib
from PIL import Image,ImageDraw
from qa_research_v10 import current_files
from decode_bpe import decode
from encode_bpe import encode
from textures import resources,texture
from smooth_art import write_texture,render_label
from archive_edit import rgba_resource
from patch_utils import sha
from bps_patch import make
from palette_smooth_v42 import improve
R=Path(__file__).parent;W=R/'translation_work';OUT=R/'English_GraphicsSmooth_v42';OUT.mkdir(exist_ok=True)
BASE=R/'English_ManagementSmooth_v41/Hikaru no Go 3 - English Management Smooth v41.iso'
ART=R/'English_CafeRecovery_v28/Hikaru no Go 3 - English Cafe Recovery v28.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso';TARGET=OUT/'Hikaru no Go 3 - English Graphics Smooth v42.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));ar=json.loads((ART.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((W/'disc_metadata.json').read_text())
assert sha(BASE)==prior['output_sha256'] and sha(ART)==ar['output_sha256'] and sha(SOURCE)==prior['source_sha256']
f,fst,files=current_files(BASE);af,_,arts=current_files(ART)
inv=json.loads((W/'inventory.json').read_text(encoding='utf8'));placement=(max(o+n for o,n,_ in files.values() if o<1085734912)+0x7fff)&~0x7fff
blobs={};reports=[];preview=[];audit=[]
candidates=json.loads((W/'graphics_audit_v42.json').read_text())
selected={(r['path'],r['name']):r for r in candidates if r['name'] not in ['cau11.D4','cau12.D4']}

for path in sorted(set(p for p,n in selected)):
 off,size,index=files[path];f.seek(off);old=decode(f.read(size));ao,an,_=arts[path];af.seek(ao);desired=decode(af.read(an));lookup=dict(resources(old));dl=dict(resources(desired));new=bytearray(old);edits=[];ranges=[];overrides={}
 for name,o in resources(old):
  if (path,name) not in selected:continue
  before,desc=texture(old,o);fmt,w,h,start=desc
  im=overrides[name] if name in overrides else texture(desired,dl[name])[0]
  if im.tobytes()==before.tobytes():continue
  assert im.size==before.size
  result=improve(new,o,im,selected[path,name]['colored']==0)
  audit.append(dict(path=path,name=name,**result))
  if not result['accepted']:continue
  ranges.append(tuple(result['palette_range']))
  if fmt in (8,9):after=write_texture(new,o,im);n=((w+7)//8)*8*((h+(7 if fmt==8 else 3))//(8 if fmt==8 else 4))*(8 if fmt==8 else 4)//(2 if fmt==8 else 1)
  elif fmt==6:
   raw=rgba_resource(old,o,im);n=len(raw)-64;new[start:start+n]=raw[64:];after=texture(new,o)[0];assert after.tobytes()==im.tobytes()
  else:raise AssertionError((path,name,fmt))
  ranges.append((start,start+n));assert texture(new,o)[1]==desc
  after.save(OUT/(path.split('/')[-1]+'.'+name+'.png'));preview.append((path+'/'+name,after))
  edits.append(dict(name=name,format=fmt,width=w,height=h,pixel_range=[start,start+n],palette_count_format_descriptor_unchanged=True))
 if not edits:continue
 assert len(new)==len(old)
 cursor=0
 for lo,hi in sorted(ranges):assert old[cursor:lo]==new[cursor:lo];cursor=hi
 assert old[cursor:]==new[cursor:]
 packed=encode(new,4096);assert decode(packed)==new
 assert placement+len(packed)<1085734912
 assert all(placement+len(packed)<=e['offset'] or placement>=e['offset']+e['size'] for e in inv)
 assert all(placement+len(packed)<=o or placement>=o+n for o,n,_ in files.values())
 struct.pack_into('>II',fst,index*12+4,placement,len(packed));blobs[path]=(placement,packed,bytes(new));placement=(placement+len(packed)+0x7fff)&~0x7fff
 reports.append(dict(path=path,previous_stored=size,stored=len(packed),previous_decoded=len(old),decoded=len(new),directory_headers_nonpalette_nonpixel_bytes_exact=True,edits=edits,new_result_hint_atlases=[e['name'] for e in edits if e['name'] in overrides]))
 print(path,len(edits),'English images; decoded unchanged',len(new),'stored',size,'->',len(packed),flush=True)
f.close();af.close()
sheet=Image.new('RGB',(1250,180*((len(preview)+3)//4)),'#666666');d=ImageDraw.Draw(sheet)
for i,(name,im) in enumerate(preview):
 x=i%4*312;y=i//4*180;d.text((x+3,y),name,fill='white');im=im.copy();im.thumbnail((305,150));sheet.paste(im,(x+3,y+23),im)
sheet.save(OUT/'english_art_preview.png')
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 f.seek(meta['fst_offset']);f.write(fst)
 for o,p,_ in blobs.values():f.seek(o);f.write(p)
f,got,fs=current_files(TARGET);assert got==fst
for path,(o,p,b) in blobs.items():f.seek(o);assert fs[path][:2]==(o,len(p)) and decode(f.read(len(p)))==b
f.close()
allowed=sorted([(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(o,o+len(p)) for o,p,b in blobs.values()])
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   checked=0
   for lo,hi in allowed:
    if hi<=pos or lo>=pos+len(x):continue
    aa=max(0,lo-pos);bb=min(len(x),hi-pos);assert x[checked:aa]==y[checked:aa];checked=max(checked,bb)
   assert x[checked:]==y[checked:]
  pos+=len(x)
print('Disc checked: code/scripts/font/all other archives exact v41. Creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_GraphicsSmooth_v42.bps',dict(game='Hikaru no Go 3',version='0.42',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(ART)==ar['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.42',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,archives=reports,dol_scripts_font_other_archives_exact_v41=True,decoded_archive_sizes_exact_v41=True,whole_disc_differences_verified=True,patch=patch,palette_audit=audit,status='Broad native-palette graphics pass from user-confirmed v41; new appearance/runtime pending. Title logo, collectible packaging, runtime fonts and existing loading artwork preserved.')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('Built',TARGET,report['output_sha256'],flush=True)
