"""Reflow selected large dialogue text only, retaining the complete v55 DOL."""
from pathlib import Path
import json,re,struct,shutil,csv
from patch_utils import sha
from qa_research_v10 import current_files
from bps_patch import make
R=Path(__file__).resolve().parent
BASE=R/'English_NameEntry_Test_v55/Hikaru no Go 3 - English Name Entry Test v55.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso'
OUT=R/'English_DialogueLayout_v56';assert not OUT.exists();OUT.mkdir()
TARGET=OUT/'Hikaru no Go 3 - English Dialogue Layout v56.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
with BASE.open('rb') as f:
 f.seek(0x420);dol_at=int.from_bytes(f.read(4),'big');f.seek(dol_at);before=f.read(prior['dol_bytes'])
dol=bytearray(before);original=(R/'translation_work/main.dol').read_bytes()
survey=json.loads((R/'translation_work/large_bubbles_v56/survey.json').read_text(encoding='utf8'))
protected=set()
for folder,key in [('English_Interface_v08','name_display'),('English_Content_v11','hud_names'),('English_Polish_v12','font_uv')]:
 rr=json.loads((R/folder/'build_report.json').read_text(encoding='utf8'))
 protected.update(int(p,16) for p in rr[key]['reclaimed_words'])
plain=lambda s:s.replace('↓',' ')
tokens=lambda s:re.findall(r'\$[0-9]|%[-0-9]*[sd]',s)
cells=lambda s:len(re.sub(r'\$[0-9]','X'*12,s).encode('cp932'))
changes=[];ranges=[]
for row in survey:
 at=int(row['offset'],16);old=row['current'];new=row['proposed']
 assert before[at:before.index(0,at)].decode('cp932')==old
 assert original[at:original.index(0,at)].decode('cp932')==row['japanese']
 assert plain(old)==plain(new) and tokens(old)==tokens(new)
 assert len(new.split('↓'))<=3 and max(cells(s) for s in new.split('↓'))<=26,(hex(at),new)
 assert not 0x259000<=at<=0x260178
 if old==new:continue
 raw=new.encode('cp932')+b'\0';assert len(raw)<=len(old.encode('cp932'))+1
 assert not any(at<p+4 and p<at+len(raw) for p in protected)
 dol[at:at+len(raw)]=raw;ranges.append((at,at+len(raw)))
 changes.append(dict(offset=hex(at),japanese=row['japanese'],before=old,after=new,old_lines=row['old_lines'],new_lines=row['new_lines'],maximum_cells=max(cells(s) for s in new.split('↓'))))
assert len(changes)==478
cursor=0
for lo,hi in sorted(ranges):assert before[cursor:lo]==dol[cursor:lo];cursor=hi
assert before[cursor:]==dol[cursor:] and len(before)==len(dol)
# Every declared code section, including v55's new section, stays exact v55.
for i in range(7):
 off,size=[int.from_bytes(before[k+i*4:k+i*4+4],'big') for k in [0,0x90]]
 if size:assert dol[off:off+size]==before[off:off+size]
assert dol[:0x100]==before[:0x100]
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 for lo,hi in ranges:f.seek(dol_at+lo);f.write(dol[lo:hi])
with TARGET.open('rb') as f:f.seek(dol_at);assert f.read(len(dol))==dol
f,fst,files=current_files(TARGET);g,oldfst,oldfiles=current_files(BASE)
assert fst==oldfst and files==oldfiles and len(files)==719
for path,(off,n,_) in files.items():
 f.seek(off);g.seek(off);assert f.read(n)==g.read(n),path
f.close();g.close()
allowed=[(dol_at+lo,dol_at+hi) for lo,hi in sorted(ranges)]
with BASE.open('rb') as f,TARGET.open('rb') as g:
 pos=0
 while True:
  a=f.read(1048576);b=g.read(1048576)
  if not a:assert not b;break
  assert len(a)==len(b)
  if a!=b:
   cursor=0
   for lo,hi in allowed:
    aa=max(0,lo-pos);bb=min(len(a),hi-pos)
    if aa<bb:assert a[cursor:aa]==b[cursor:aa];cursor=bb
   assert a[cursor:]==b[cursor:]
  pos+=len(a)
print('478 text-only reflows pass; v55 code, all719 resources and whole-disc checks pass. Creating BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_DialogueLayout_v56.bps',dict(game='Hikaru no Go 3',version='0.56',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.56',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),dol_offset=dol_at,dol_bytes=len(dol),room_story_entries_surveyed=1234,multiline_entries_reviewed=len(survey),layout_changes=len(changes),fewer_lines=sum(r['new_lines']<r['old_lines'] for r in changes),wording_and_punctuation_exact_v55=True,all_declared_code_sections_exact_v55=True,v55_name_entry_fix_retained=True,small_battle_bubbles_exact_v55=True,all719_active_resources_exact_v55=True,fonts_graphics_scripts_gba_exact_v55=True,storage_and_runtime_tokens_verified=True,whole_disc_differences_verified=True,saves_settings_untouched=True,patch=patch,runtime='Large-bubble layout pending user Dolphin comparison; no new runtime code or font changes.')
(OUT/'build_report.json').write_text(json.dumps(report,indent=2),encoding='utf8')
(OUT/'dialogue_layout_changes.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),encoding='utf8')
with (OUT/'dialogue_layout_changes.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(changes[0]));writer.writeheader();writer.writerows(changes)
md=['# Large dialogue layout changes v56','','Only line breaks change. ` / ` below marks the displayed line break. Wording and punctuation are retained.','', '| DOL offset | Before | After |','|---|---|---|']
for r in changes:
 fmt=lambda s:s.replace('↓',' / ').replace('|','\\|')
 md.append(f"| {r['offset']} | {fmt(r['before'])} | {fmt(r['after'])} |")
(OUT/'dialogue_layout_changes.md').write_text('\n'.join(md)+'\n',encoding='utf8')
(OUT/'README.md').write_text(f'''# English Dialogue Layout v56

Reflows 478 large room/Story dialogue occurrences after surveying 1234 known entries,
including 896 multiline entries. {report['fewer_lines']} occurrences now use fewer lines.
Existing narrow authored line breaks are removed where they waste space; matching
repeated Story dialogue is kept consistent. One-word endings are adjusted when useful.
All words, punctuation, placeholders and their order are unchanged.

The established 26-halfwidth-cell, three-line large-bubble budget is retained. Every
numbered runtime token still reserves twelve cells for longer names. Small battle
bubbles retain the v52 18-cell wrapping; tutorial/script/GBA panels are unchanged.
This is a layout pass on the known room/Story corpus, not a claim of complete runtime
coverage of every optional dialogue branch.

The v55 game-side name-entry fix is retained byte-for-byte. The font, outlines,
artwork, title overlay, all 719 active resources, scripts and GBA content are unchanged.
No save files or emulator settings were changed. Every declared code section and
all nontext DOL bytes are exact v55. Original byte capacities and tokens, finished
readback, whole-disc permitted differences, original/base hashes and cumulative BPS
reconstruction are checked. BPS applies to the original Japanese ISO.

Please cold boot and compare the Sai introduction and map dialogue from the screenshots,
then try a longer Story bubble and a bubble containing your player name. The new
layouts still need Dolphin visual confirmation. All earlier builds are preserved.

Complete before/after layouts are in dialogue_layout_changes.md and CSV/JSON.
''',encoding='utf8')
print(json.dumps(report,indent=2),flush=True)
