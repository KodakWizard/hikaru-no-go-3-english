"""Load-row localization and profile-heading layout correction, from v0.9."""
from pathlib import Path
import json,struct,re,shutil
from PIL import Image
from textures import resources,texture
from decode_bpe import decode
from archive_edit import rgba_resource
from load_translation_v091 import TEXT,ALIGNED_SLOTS,VALUE_ANCHORS
from load_art_v091 import render_tables,layout_preview
from patch_utils import sha
from bps_patch import make

ROOT=Path(__file__).resolve().parent;WORK=ROOT/'translation_work';OUT=ROOT/'English_Load_v091';OUT.mkdir(exist_ok=True)
BASE=ROOT/'English_Menu_v09/Hikaru no Go 3 - English Menu v09.iso';SOURCE=ROOT/'Hikaru no Go 3 (Japan).iso';TARGET=OUT/'Hikaru no Go 3 - English Load v091.iso'
previous=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((WORK/'disc_metadata.json').read_text())
assert sha(BASE)==previous['output_sha256'] and sha(SOURCE)==previous['source_sha256']
original=(WORK/'main.dol').read_bytes()
with BASE.open('rb') as f:
 f.seek(meta['dol_offset']);old_dol=f.read(len(original));dol=bytearray(old_dol)
 f.seek(meta['fst_offset']);fst=f.read(meta['fst_size']);count=int.from_bytes(fst[8:12],'big');names=fst[count*12:];stack=[('',count)];files={}
 for i in range(1,count):
  while i>=stack[-1][1]:stack.pop()
  word,off,size=struct.unpack_from('>III',fst,i*12);name=names[word&0xffffff:].split(b'\0')[0].decode('cp932');path=stack[-1][0]+name
  if word>>24:stack.append((path+'/',size))
  else:files[path]=(off,size)
 off,size=files['2D/fai.bpe'];f.seek(off);old_blob=f.read(size)
edits=[];ranges=[]
for at,en in TEXT.items():
 old=original[at:original.index(0,at)];new=en.encode('ascii');assert old_dol[at:at+len(old)]==old
 capacity=len(old)
 if at in ALIGNED_SLOTS:
  end=ALIGNED_SLOTS[at];assert original[at+len(old):end]==bytes(end-at-len(old))
  assert old_dol[at+len(old):end]==bytes(end-at-len(old))
  # No stored pointer may address the alignment padding being reclaimed.
  ram=0x804132e0+at-0x2d4c20
  for p in range(at+len(old)+1,end):assert (ram+p-at).to_bytes(4,'big') not in original
  capacity=end-at-1
 assert len(new)<=capacity,(hex(at),en,capacity)
 assert re.findall(rb'%(?:[0-9]*d|s)',old)==re.findall(rb'%(?:[0-9]*d|s)',new)
 used=max(len(old),len(new))+1;dol[at:at+used]=new+bytes(used-len(new));ranges.append((at,at+used))
 edits.append(dict(offset=hex(at),japanese=old.decode('cp932'),english=en,original_string_capacity=len(old),verified_capacity_including_padding=capacity,used=len(new)))
for i,(a,b) in enumerate(zip(old_dol,dol)):
 if a!=b:assert any(lo<=i<hi for lo,hi in ranges),hex(i)
archive=decode(old_blob);new_archive=bytearray(archive);lookup=dict(resources(archive));arts,layout_checks=render_tables(archive);graphic_checks=[]
for n,im in arts.items():
 o=lookup[n];old_im,desc=texture(archive,o);assert desc[0]==6
 replacement=rgba_resource(archive,o,im);length=int.from_bytes(archive[o:o+4],'big')+32;assert len(replacement)==length
 new_archive[o:o+length]=replacement;assert texture(new_archive,o)[0].tobytes()==im.tobytes()
 graphic_checks.append(dict(asset=n,width=im.width,height=im.height,format='RGBA8',in_place_resource_size_unchanged=True,decoded_pixels_exact=True))
 im.save(OUT/(n+'_headings.png'))
for n,o in lookup.items():
 if n in arts:continue
 length=int.from_bytes(archive[o:o+4],'big')+32;assert new_archive[o:o+length]==archive[o:o+length]
assert list(resources(new_archive))==list(resources(archive))
blob=len(new_archive).to_bytes(4,'big')+bytes([254,127,254,255])+len(new_archive).to_bytes(4,'big')+new_archive
assert len(blob)==len(old_blob) and old_blob[:12]==blob[:12] and decode(blob)==new_archive
preview,bounds=layout_preview(arts['fai20.D4']);preview.resize((1200,146),Image.Resampling.NEAREST).save(OUT/'layout_preview_sample_values.png')
# Check all supported grade inputs without altering the original 20-index logic.
grades=[]
for level in range(21):
 row='1 dan' if level>=20 else '%2d kyu'%(20-level)
 detail='1 dan' if level>=20 else '%d kyu'%(20-level)
 assert len(row)<=6 and len(detail)<=6 and len(row)*16<=104
 grades.append(dict(level_index=level,row=row,detail=detail))
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:f.seek(meta['dol_offset']);f.write(dol);f.seek(off);f.write(blob)
with TARGET.open('rb') as f:
 f.seek(meta['dol_offset']);assert f.read(len(dol))==dol
 f.seek(meta['fst_offset']);assert f.read(len(fst))==fst
 f.seek(off);assert decode(f.read(len(blob)))==new_archive
allowed=[(meta['dol_offset']+a,meta['dol_offset']+b) for a,b in ranges]+[(off,off+len(blob))]
with BASE.open('rb') as f,TARGET.open('rb') as g:
 pos=0
 while True:
  a=f.read(1024*1024);b=g.read(1024*1024)
  if not a:assert not b;break
  assert len(a)==len(b)
  if a!=b:
   for i,(x,y) in enumerate(zip(a,b)):
    if x!=y:assert any(lo<=pos+i<hi for lo,hi in allowed)
  pos+=len(a)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Load_v091.bps',dict(game='Hikaru no Go 3',version='0.9.1',base='original Japanese GHTJA4'))
assert sha(BASE)==previous['output_sha256'] and sha(SOURCE)==previous['source_sha256']
report=dict(version='0.9.1',source_sha256=previous['source_sha256'],previous_sha256=previous['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,load_strings=edits,graphic_checks=graphic_checks,layout_checks=layout_checks,recovered_value_anchors=VALUE_ANCHORS,value_bounds=bounds,grade_cases=grades,unchanged_fst_and_archive_directory=True,archive_size_unchanged=True,other_executable_bytes_unchanged=True,whole_disc_changes_verified=True,patch=patch,status='Load-screen fix; file/layout checks passed; Dolphin confirmation required; full game remains incomplete')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('Built',TARGET,'strings',len(edits),'table images',len(arts),'grade cases',len(grades),'BPS bytes',patch['bytes'],flush=True)
