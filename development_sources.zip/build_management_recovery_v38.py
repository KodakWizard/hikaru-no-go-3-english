"""Management transition diagnostic: restore two shared interface archives to v08."""
from pathlib import Path
import json,struct,shutil,hashlib
from qa_research_v10 import current_files
from decode_bpe import decode
from encode_bpe import encode
from art_v11 import compact_archive
from textures import resources
from patch_utils import sha
from bps_patch import make
R=Path(__file__).parent;W=R/'translation_work';OUT=R/'English_ManagementRecovery_v38';OUT.mkdir(exist_ok=True)
BASE=R/'English_System_v37/Hikaru no Go 3 - English System v37.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso'
TARGET=OUT/'Hikaru no Go 3 - English Management Recovery v38.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((W/'disc_metadata.json').read_text())
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
f,fst,files=current_files(BASE);blobs={};reports=[]
reference=R/'English_Interface_v08/Hikaru no Go 3 - English Interface v08.iso'
ref_report=json.loads((reference.parent/'build_report.json').read_text(encoding='utf8'))
assert sha(reference)==ref_report['output_sha256']
rf,_,refs=current_files(reference)
inv=json.loads((W/'inventory.json').read_text(encoding='utf8'))
placement=(max(o+n for o,n,_ in files.values() if o<1085734912)+0x7fff)&~0x7fff
for path in sorted(files):
 if path not in ['2D/win.bpe','2D/mba.bpe']:continue
 oldoff,size,index=files[path];ro,rs,_=refs[path]
 f.seek(oldoff);current=f.read(size);rf.seek(ro);packed=rf.read(rs)
 if current==packed:continue
 off=placement;new=decode(packed)
 assert off+rs<1085734912
 assert all(off+rs<=e['offset'] or off>=e['offset']+e['size'] for e in inv)
 assert all(off+rs<=o or off>=o+n for o,n,_ in files.values())
 blobs[path]=(off,packed,new);struct.pack_into('>II',fst,index*12+4,off,rs)
 reports.append(dict(path=path,offset=off,previous_stored=size,stored=rs,decoded=len(new),stored_bytes_exact_v08=True,sha256=hashlib.sha256(packed).hexdigest()))
 placement=(off+rs+0x7fff)&~0x7fff
 print(path,'restored exact v08',rs,flush=True)
rf.close()
f.close();shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 f.seek(meta['fst_offset']);f.write(fst)
 for off,packed,_ in blobs.values():f.seek(off);f.write(packed)
f,got,fs=current_files(TARGET);assert got==fst
for path,(off,packed,new) in blobs.items():
 assert fs[path][:2]==(off,len(packed));f.seek(off);assert f.read(len(packed))==packed and decode(packed)==new
f.close()
allowed=sorted([(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(off,off+len(packed)) for off,packed,_ in blobs.values()])
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   checked=0
   for lo,hi in allowed:
    if hi<=pos or lo>=pos+len(x):continue
    aa=max(0,lo-pos);bb=min(len(x),hi-pos)
    assert x[checked:aa]==y[checked:aa];checked=max(checked,bb)
   assert x[checked:]==y[checked:]
  pos+=len(x)
assert sha(reference)==ref_report['output_sha256']
print('Whole disc verified: DOL and all scripts exact v37. Creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_ManagementRecovery_v38.bps',dict(game='Hikaru no Go 3',version='0.38',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.38',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,archives=reports,all_restored_archives_exact_v08=True,dol_scripts_font_exact_v37=True,whole_disc_differences_verified=True,patch=patch,root_cause_confirmed=False,status='V37 room Management black screen reported. Restore only win/mba interface archives to exact v08 stored bytes. All other active files and DOL exact v37. Management entry, submenus and return-to-room runtime tests required. Root cause unconfirmed; not claimed fixed.')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('Built',TARGET,report['output_sha256'],flush=True)
