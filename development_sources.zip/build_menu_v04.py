"""Cumulative menu completion batch based on the user's four screenshots."""
from pathlib import Path
import struct,json,hashlib,shutil,re,math
from PIL import Image,ImageDraw,ImageFont
from textures import resources,texture
from decode_bpe import decode
from menu_translation_v04 import LABELS,TEXT

ROOT=Path(__file__).resolve().parent;WORK=ROOT/'translation_work'
OUT=ROOT/'English_Menu_v04';OUT.mkdir(exist_ok=True)
SOURCE=ROOT/'Hikaru no Go 3 (Japan).iso'
BASE=ROOT/'English_Story_v03/Hikaru no Go 3 - English Story v03.iso'
TARGET=OUT/'Hikaru no Go 3 - English Menu v04.iso'
meta=json.loads((WORK/'disc_metadata.json').read_text())
previous=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
poc=json.loads((ROOT/'English_Menu_POC/build_report.json').read_text(encoding='utf8'))
v2=json.loads((ROOT/'English_Story_v02/build_report.json').read_text(encoding='utf8'))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
assert sha(SOURCE)==previous['source_sha256'];assert sha(BASE)==previous['output_sha256']
original=(WORK/'main.dol').read_bytes()
with BASE.open('rb') as f:
 f.seek(meta['dol_offset']);dol=bytearray(f.read(len(original)))
 f.seek(meta['fst_offset']);fst=bytearray(f.read(meta['fst_size']))
edits=[]
for o,en in TEXT.items():
 old=original[o:original.index(0,o)];new=en.encode('cp932')
 assert dol[o:o+len(old)]==old,(hex(o),'already patched')
 assert len(new)<=len(old),(hex(o),'storage')
 assert re.findall(rb'%[sd]',old)==re.findall(rb'%[sd]',new),(hex(o),'format args')
 assert max(map(len,en.split('\n')))<=40,(hex(o),'message width')
 dol[o:o+len(old)+1]=new+b'\0'*(len(old)+1-len(new))
 edits.append(dict(offset=hex(o),japanese=old.decode('cp932'),english=en,used_bytes=len(new),capacity=len(old)))

blobs={};fit=[];previews=[]
for src,mapping in LABELS.items():
 b=bytearray((WORK/'decoded'/Path(src+'.bin')).read_bytes());original_len=len(b);seen=set()
 for name,o in resources(b):
  if name not in mapping:continue
  seen.add(name);en=mapping[name];im,(fmt,w,h,start)=texture(b,o);assert fmt in (8,9)
  badge=src=='2D/mba';tiny=w<=32
  stroke=0 if tiny else 1
  margin=2 if tiny else 3
  size=min(22,h-2*margin) if not badge else 18
  lines=en.split('\n')
  while size>=10:
   font=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',size)
   boxes=[font.getbbox(l,stroke_width=stroke) for l in lines]
   widths=[a[2]-a[0] for a in boxes];heights=[a[3]-a[1] for a in boxes]
   total=sum(heights)+2*(len(lines)-1)
   if max(widths)<=w-margin*2 and total<=h-margin*2:break
   size-=1
  assert size>=10,(src,name,'does not fit',en,w,h)
  canvas=Image.new('RGBA',(w,h),im.getpixel((0,0)));dr=ImageDraw.Draw(canvas);y=(h-total)//2
  for line,box,tw,th in zip(lines,boxes,widths,heights):
   dr.text(((w-tw)//2-box[0],y-box[1]),line,font=font,fill='white',stroke_width=stroke,stroke_fill='black');y+=th+2
  pf,n=struct.unpack_from('>HH',b,o+44);pal=[]
  for j in range(n):
   v=int.from_bytes(b[o+64+j*2:o+66+j*2],'big')
   if pf==0:c=(v&255,v&255,v&255,v>>8)
   elif pf==1:c=(((v>>11)&31)*255//31,((v>>5)&63)*255//63,(v&31)*255//31,255)
   else:c=(((v>>10)&31)*255//31,((v>>5)&31)*255//31,(v&31)*255//31,255) if v&32768 else (((v>>8)&15)*17,((v>>4)&15)*17,(v&15)*17,((v>>12)&7)*255//7)
   pal.append(c)
  if fmt==8:pal=pal[:16]
  cache={}
  def nearest(c):
   if c not in cache:cache[c]=min(range(len(pal)),key=lambda j:sum((c[k]-pal[j][k])**2 for k in range(4)))
   return cache[c]
  pix=list(canvas.getdata());bw,bh=(8,8) if fmt==8 else (8,4);packed=bytearray()
  for ty in range(0,h,bh):
   for tx in range(0,w,bw):
    vals=[nearest(pix[(ty+yy)*w+tx+xx]) if ty+yy<h and tx+xx<w else 0 for yy in range(bh) for xx in range(bw)]
    packed.extend(((vals[i]<<4)|vals[i+1] for i in range(0,len(vals),2)) if fmt==8 else vals)
  b[start:start+len(packed)]=packed;assert len(b)==original_len
  after,_=texture(b,o)
  (OUT/'label_previews').mkdir(exist_ok=True);after.save(OUT/'label_previews'/(name+'.png'))
  fit.append(dict(archive=src,asset=name,english=en,width=w,height=h,font_size=size,ink_width=max(widths),ink_height=total,margin=margin))
  previews.append((src,name,im,after))
 assert seen==set(mapping),(src,'missing assets',set(mapping)-seen)
 blob=len(b).to_bytes(4,'big')+bytes([254,127,254,255])+len(b).to_bytes(4,'big')+b
 assert decode(blob)==b;blobs[src+'.bpe']=(blob,bytes(b))

placement=(v2['room_archive_offset']+v2['room_archive_bytes']+0x7fff)&~0x7fff
entries=json.loads((WORK/'inventory.json').read_text(encoding='utf8'));relocated={}
for path,(blob,data) in blobs.items():
 assert all(placement+len(blob)<=e['offset'] or placement>=e['offset']+e['size'] for e in entries)
 relocated[path]=dict(offset=placement,size=len(blob));placement=(placement+len(blob)+0x7fff)&~0x7fff
count=int.from_bytes(fst[8:12],'big');names=fst[count*12:];stack=[('',count)];found=set()
for i in range(1,count):
 while i>=stack[-1][1]:stack.pop()
 word,off,size=struct.unpack_from('>III',fst,i*12);name=names[word&0xffffff:].split(b'\0')[0].decode('cp932');path=stack[-1][0]+name
 if word>>24:stack.append((path+'/',size))
 elif path in relocated:
  e=relocated[path];struct.pack_into('>II',fst,i*12+4,e['offset'],e['size']);found.add(path)
assert found==set(blobs)
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 f.seek(meta['dol_offset']);f.write(dol)
 f.seek(meta['fst_offset']);f.write(fst)
 for path,(blob,data) in blobs.items():f.seek(relocated[path]['offset']);f.write(blob)
with TARGET.open('rb') as f:
 f.seek(meta['dol_offset']);assert f.read(len(dol))==dol
 f.seek(meta['fst_offset']);assert f.read(len(fst))==fst
 for path,(blob,data) in blobs.items():f.seek(relocated[path]['offset']);assert decode(f.read(len(blob)))==data

allowed=[(meta['dol_offset'],meta['dol_offset']+len(dol)),(meta['fst_offset'],meta['fst_offset']+len(fst)),(poc['title_archive_offset'],poc['title_archive_offset']+poc['title_archive_size']),(v2['room_archive_offset'],v2['room_archive_offset']+v2['room_archive_bytes'])]+[(e['offset'],e['offset']+e['size']) for e in relocated.values()]
patch=bytearray(b'PATCH');changed=0
with SOURCE.open('rb') as f,TARGET.open('rb') as g:
 pos=0
 while True:
  a=f.read(1024*1024);b=g.read(1024*1024)
  if not a:assert not b;break
  assert len(a)==len(b)
  if a!=b:
   i=0
   while i<len(a):
    if a[i]==b[i]:i+=1;continue
    s=i;i+=1
    while i<len(a) and a[i]!=b[i] and i-s<65535:i+=1
    at=pos+s;assert at<0x1000000 and at!=0x454f46
    assert any(lo<=at and pos+i<=hi for lo,hi in allowed)
    patch.extend(at.to_bytes(3,'big')+(i-s).to_bytes(2,'big')+b[s:i]);changed+=i-s
  pos+=len(a)
patch.extend(b'EOF');(OUT/'Hikaru_no_Go_3_English_Menu_v04.ips').write_bytes(patch)
target_sha=sha(TARGET)
ops=[];i=5
while patch[i:i+3]!=b'EOF':
 o=int.from_bytes(patch[i:i+3],'big');n=int.from_bytes(patch[i+3:i+5],'big');assert n;ops.append((o,patch[i+5:i+5+n]));i+=5+n
h=hashlib.sha256();ix=0;pos=0
with SOURCE.open('rb') as f:
 while True:
  b=bytearray(f.read(1024*1024))
  if not b:break
  end=pos+len(b)
  while ix<len(ops) and ops[ix][0]<end:
   o,data=ops[ix];lo=max(pos,o);hi=min(end,o+len(data));b[lo-pos:hi-pos]=data[lo-o:hi-o]
   if o+len(data)<=end:ix+=1
   else:break
  h.update(b);pos=end
assert h.hexdigest()==target_sha
assert sha(SOURCE)==previous['source_sha256'] and sha(BASE)==previous['output_sha256']
report=dict(version='0.4',source_sha256=previous['source_sha256'],output_sha256=target_sha,previous_build_preserved=True,original_unchanged=True,new_graphic_labels=len(fit),new_system_strings=len(edits),cumulative_dol_strings=previous['cumulative_string_occurrences']+len(edits),relocated_archives=relocated,whole_disc_differences_verified=True,ips_reconstructs_target=True,layout='All labels fit original dimensions; system message format argument order retained. Dynamic substituted message layout still needs Dolphin testing.',status='v0.4 runtime test required',labels=fit,text=edits)
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
for pg in range(math.ceil(len(previews)/12)):
 items=previews[pg*12:(pg+1)*12];sheet=Image.new('RGB',(900,90*len(items)),'#304050');dr=ImageDraw.Draw(sheet)
 for i,(src,name,im,after) in enumerate(items):
  dr.text((5,i*90+2),src+' / '+name,fill='white');sheet.paste(im,(5,i*90+25),im);sheet.paste(after,(460,i*90+25),after)
 sheet.save(OUT/f'labels_comparison_{pg+1}.png')
print('Built',TARGET,'new graphics',len(fit),'new system strings',len(edits))
