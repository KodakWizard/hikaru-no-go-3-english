"""Smoother menu lettering, memory-card artwork and remaining prompt text."""
from pathlib import Path
import json,struct,re,shutil,math
from PIL import Image,ImageDraw,ImageFont
from textures import resources,texture
from decode_bpe import decode
from smooth_art import render_label,write_texture,title_palette
from menu_translation_v04 import LABELS
from menu_translation_v05 import TEXT
from patch_utils import sha,package

ROOT=Path(__file__).resolve().parent;WORK=ROOT/'translation_work'
OUT=ROOT/'English_Menu_v05';OUT.mkdir(exist_ok=True)
SOURCE=ROOT/'Hikaru no Go 3 (Japan).iso'
BASE=ROOT/'English_Menu_v04/Hikaru no Go 3 - English Menu v04.iso'
TARGET=OUT/'Hikaru no Go 3 - English Menu v05.iso'
meta=json.loads((WORK/'disc_metadata.json').read_text())
previous=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
poc=json.loads((ROOT/'English_Menu_POC/build_report.json').read_text(encoding='utf8'))
v2=json.loads((ROOT/'English_Story_v02/build_report.json').read_text(encoding='utf8'))
assert sha(SOURCE)==previous['source_sha256'];assert sha(BASE)==previous['output_sha256']
original=(WORK/'main.dol').read_bytes()
with BASE.open('rb') as f:
 f.seek(meta['dol_offset']);dol=bytearray(f.read(len(original)))
 f.seek(meta['fst_offset']);fst=f.read(meta['fst_size'])
 count=int.from_bytes(fst[8:12],'big');names=fst[count*12:];stack=[('',count)];files={}
 for i in range(1,count):
  while i>=stack[-1][1]:stack.pop()
  word,off,size=struct.unpack_from('>III',fst,i*12);name=names[word&0xffffff:].split(b'\0')[0].decode('cp932');path=stack[-1][0]+name
  if word>>24:stack.append((path+'/',size))
  else:files[path]=(off,size)
 archives={}
 for path in ['title/title.bpe']+[s+'.bpe' for s in LABELS]:
  off,size=files[path];f.seek(off);archives[path]=bytearray(decode(f.read(size)))
edits=[]
for o,en in TEXT.items():
 old=original[o:original.index(0,o)];new=en.encode('cp932')
 assert dol[o:o+len(old)]==old,(hex(o),'already changed')
 assert len(new)<=len(old),(hex(o),'storage')
 assert re.findall(rb'%[sd]',old)==re.findall(rb'%[sd]',new),(hex(o),'format args')
 assert max(map(len,en.split('\n')))<=40
 dol[o:o+len(old)+1]=new+b'\0'*(len(old)+1-len(new))
 edits.append(dict(offset=hex(o),japanese=old.decode('cp932'),english=en,capacity=len(old),used=len(new)))
previews=[];fit=[];stats=[]
for path,b in archives.items():
 src=path.removesuffix('.bpe');lookup=dict(resources(b))
 if src=='title/title':
  mapping={n:('STORY' if n in ('tit04.D4','tit06.D4') else 'FREE MATCH') for n in ('tit04.D4','tit05.D4','tit06.D4','tit07.D4')}
 else:mapping=LABELS[src]
 for name,text in mapping.items():
  o=lookup[name];before,desc=texture(b,o)
  if src=='title/title':
   art,budget=render_label(before,text,max_size=29,margin=4,italic=True,title=True)
   grey=name in ('tit06.D4','tit07.D4')
   if grey:art.putdata([(round(r*170/255),round(r*170/255),round(r*170/255),a) for r,g,bl,a in art.getdata()])
   title_palette(b,o,grey)
  else:
   art,budget=render_label(before,text,max_size=18 if src=='2D/mba' else min(22,before.height-6),margin=2 if before.width<=32 else 3)
  after=write_texture(b,o,art);previews.append((path,name,before,after));fit.append(dict(archive=path,asset=name,text=text,**budget))
  if src=='title/title':
   stats.append(dict(asset=name,old_partial_alpha_pixels=sum(0<a<255 for r,g,bl,a in before.getdata()),new_partial_alpha_pixels=sum(0<a<255 for r,g,bl,a in after.getdata())))
  (OUT/'label_previews').mkdir(exist_ok=True);after.save(OUT/'label_previews'/(name+'.png'))
 if src=='title/title':
  # The Japanese save-requirements notice is a single baked-in image.
  o=lookup['err7.D4'];before,desc=texture(b,o);w,h=before.size;scale=6
  art=before.resize((w*scale,h*scale),Image.Resampling.NEAREST);dr=ImageDraw.Draw(art)
  bg=before.getpixel((40,28));dr.rectangle((35*scale,24*scale,425*scale,222*scale),fill=bg)
  lines=['Hikaru no Go 3 needs at least','1 file and 2 free blocks for','each of these save types:',
         '- System data (Slot A only)','- Story data (Slot A only)','- Kifu data','- Suspended game data']
  font=ImageFont.truetype('C:/Windows/Fonts/arialbi.ttf',18*scale)
  ys=[32,54,76,113,136,159,182]
  for line,y in zip(lines,ys):
   box=dr.textbbox((0,0),line,font=font);assert box[2]-box[0]<(w-85)*scale
   dr.text((43*scale,y*scale),line,font=font,fill=(255,170,0,255))
  # Keep the border's original pixels; downsample only the rewritten interior.
  down=art.resize((w,h),Image.Resampling.LANCZOS);final=before.copy();final.paste(down.crop((35,24,426,223)),(35,24))
  after=write_texture(b,o,final);after.save(OUT/'save_requirements_English.png');previews.insert(0,(path,'err7.D4',before,after))

shutil.copyfile(BASE,TARGET);written={}
with TARGET.open('r+b') as f:
 f.seek(meta['dol_offset']);f.write(dol)
 for path,b in archives.items():
  blob=len(b).to_bytes(4,'big')+bytes([254,127,254,255])+len(b).to_bytes(4,'big')+b
  off,size=files[path];assert len(blob)==size,(path,'must preserve FST length')
  assert decode(blob)==b;f.seek(off);f.write(blob);written[path]=dict(offset=off,size=size)
with TARGET.open('rb') as f:
 f.seek(meta['dol_offset']);assert f.read(len(dol))==dol
 f.seek(meta['fst_offset']);assert f.read(len(fst))==fst
 for path,b in archives.items():off,size=files[path];f.seek(off);assert decode(f.read(size))==b
allowed=[(meta['dol_offset'],meta['dol_offset']+len(dol)),(meta['fst_offset'],meta['fst_offset']+len(fst)),(poc['title_archive_offset'],poc['title_archive_offset']+poc['title_archive_size']),(v2['room_archive_offset'],v2['room_archive_offset']+v2['room_archive_bytes'])]+[(e['offset'],e['offset']+e['size']) for e in written.values()]
result=package(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Menu_v05.ips',allowed)
assert sha(SOURCE)==previous['source_sha256'] and sha(BASE)==previous['output_sha256']
report=dict(version='0.5',source_sha256=previous['source_sha256'],original_unchanged=True,previous_build_preserved=True,new_dol_strings=len(edits),cumulative_dol_strings=previous['cumulative_dol_strings']+len(edits),rerendered_labels=len(fit),new_save_requirements_image=True,rendering='6x supersampling, Lanczos downsample, premultiplied-alpha palette distance; title CI4 palette rebuilt with eight text and eight black-edge coverage levels',native_resolution_preserved=True,fst_unchanged_from_v04=True,archives=written,title_alpha_statistics=stats,labels=fit,text=edits,runtime_status='v0.5 Dolphin test required',**result)
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
for pg in range(math.ceil(len(previews)/12)):
 part=previews[pg*12:(pg+1)*12];height=sum(max(90,before.height+32) for _,_,before,_ in part);sheet=Image.new('RGB',(1000,height),'#304050');dr=ImageDraw.Draw(sheet);y=0
 for path,name,before,after in part:
  dr.text((5,y+2),path+' / '+name,fill='white');sheet.paste(before,(5,y+25),before);sheet.paste(after,(510,y+25),after);y+=max(90,before.height+32)
 sheet.save(OUT/f'quality_comparison_{pg+1}.png')
print('Built',TARGET,'new text',len(edits),'smoother labels',len(fit),'alpha checks',stats)
