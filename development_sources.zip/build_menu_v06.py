"""Focused lossless RGBA8 experiment for title and main-menu lettering."""
from pathlib import Path
import struct,json,shutil
from PIL import Image,ImageDraw
from textures import resources,texture
from smooth_art import render_label,write_texture
from decode_bpe import decode
from menu_translation_v04 import LABELS
from patch_utils import sha,package

ROOT=Path(__file__).resolve().parent;WORK=ROOT/'translation_work'
OUT=ROOT/'English_Menu_v06';OUT.mkdir(exist_ok=True)
SOURCE=ROOT/'Hikaru no Go 3 (Japan).iso'
BASE=ROOT/'English_Menu_v05/Hikaru no Go 3 - English Menu v05.iso'
TARGET=OUT/'Hikaru no Go 3 - English Menu v06.iso'
previous=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
meta=json.loads((WORK/'disc_metadata.json').read_text())
assert sha(SOURCE)==previous['source_sha256'];assert sha(BASE)==previous['output_sha256']
with BASE.open('rb') as f:
 f.seek(meta['fst_offset']);fst=bytearray(f.read(meta['fst_size']))
 count=int.from_bytes(fst[8:12],'big');names=fst[count*12:];stack=[('',count)];files={}
 for i in range(1,count):
  while i>=stack[-1][1]:stack.pop()
  word,off,size=struct.unpack_from('>III',fst,i*12);name=names[word&0xffffff:].split(b'\0')[0].decode('cp932');path=stack[-1][0]+name
  if word>>24:stack.append((path+'/',size))
  else:files[path]=(off,size,i)
 data={}
 for path in ('title/title.bpe','2D/win.bpe'):
  off,size,i=files[path];f.seek(off);data[path]=decode(f.read(size))

def rgba_resource(original,o,im):
 w,h=im.size;pixels=im.load();payload=bytearray()
 for y in range(0,h,4):
  for x in range(0,w,4):
   tile=[pixels[x+xx,y+yy] if x+xx<w and y+yy<h else (0,0,0,0) for yy in range(4) for xx in range(4)]
   for r,g,b,a in tile:payload.extend((a,r))
   for r,g,b,a in tile:payload.extend((g,b))
 b=bytearray(original[o:o+64]);struct.pack_into('>I',b,0,32+len(payload))
 struct.pack_into('>HHHHI',b,32,6,w,h,0,32)
 b[44:64]=bytes(20) # no palette or mipmap metadata
 b.extend(payload)
 decoded,desc=texture(b,0);assert decoded.tobytes()==im.tobytes(),'RGBA8 must be lossless'
 return bytes(b)

def rebuild(original,replacements):
 olddir=int.from_bytes(original[4:8],'big')+32;n=int.from_bytes(original[12:16],'big')
 tail=bytearray(original[olddir:]);body=bytearray(original[:olddir]);res=dict(resources(original))
 for i,(name,o) in enumerate(resources(original)):
  if name not in replacements:continue
  body.extend(bytes((-len(body))%32));new_o=len(body)
  body.extend(replacements[name]);struct.pack_into('>I',tail,i*8,new_o-32)
 body.extend(bytes((-len(body))%32));newdir=len(body)
 body.extend(tail);struct.pack_into('>II',body,0,len(body),newdir-32)
 # Every resource other than a replaced D4 retains the original byte slice.
 newres=dict(resources(body))
 for name,o in res.items():
  size=int.from_bytes(original[o:o+4],'big')+32
  if name not in replacements:assert body[newres[name]:newres[name]+size]==original[o:o+size],name
 return bytes(body)

outputs={};previews=[];checks=[]
for path,b in data.items():
 lookup=dict(resources(b));replacement={}
 mapping={n:('STORY' if n in ('tit04.D4','tit06.D4') else 'FREE MATCH') for n in ('tit04.D4','tit05.D4','tit06.D4','tit07.D4')} if path.startswith('title') else {n:t for n,t in LABELS['2D/win'].items() if n.startswith('win03_')}
 for name,text in mapping.items():
  o=lookup[name];before,desc=texture(b,o);is_title=path.startswith('title')
  art,budget=render_label(before,text,max_size=29 if is_title else 22,margin=4 if is_title else 3,italic=is_title,title=is_title)
  if name in ('tit06.D4','tit07.D4'):art.putdata([(round(r*170/255),round(r*170/255),round(r*170/255),a) for r,g,bl,a in art.getdata()])
  # Same desired image through the previous palette versus direct RGBA8.
  quantised=write_texture(bytearray(b),o,art)
  replacement[name]=rgba_resource(b,o,art);after=texture(replacement[name],0)[0]
  error=sum(abs(a[3]-c[3]) for a,c in zip(art.getdata(),quantised.getdata()))/(art.width*art.height)
  checks.append(dict(asset=name,archive=path,old_format=desc[0],new_format=6,width=art.width,height=art.height,indexed_mean_alpha_error=error,rgba_mean_alpha_error=0.0,rgba_pixels_exact=True,**{k:v for k,v in budget.items() if k not in ('width','height')}))
  previews.append((name,before,quantised,after))
  (OUT/'label_previews').mkdir(exist_ok=True);after.save(OUT/'label_previews'/(name+'.png'))
 new=rebuild(b,replacement)
 blob=len(new).to_bytes(4,'big')+bytes([254,127,254,255])+len(new).to_bytes(4,'big')+new
 assert decode(blob)==new;outputs[path]=(blob,new)

# Place larger archives after all existing replacements, within the known FST gap.
placement=(max(off+size for off,size,i in files.values() if off<0x1000000)+0x7fff)&~0x7fff
inventory=json.loads((WORK/'inventory.json').read_text(encoding='utf8'));relocated={}
for path,(blob,new) in outputs.items():
 assert all(placement+len(blob)<=e['offset'] or placement>=e['offset']+e['size'] for e in inventory)
 assert placement+len(blob)<0x1000000,'IPS address limit'
 assert all(placement+len(blob)<=off or placement>=off+size for off,size,i in files.values())
 relocated[path]=dict(offset=placement,size=len(blob));i=files[path][2]
 struct.pack_into('>II',fst,i*12+4,placement,len(blob));placement=(placement+len(blob)+0x7fff)&~0x7fff
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 f.seek(meta['fst_offset']);f.write(fst)
 for path,(blob,new) in outputs.items():f.seek(relocated[path]['offset']);f.write(blob)
with TARGET.open('rb') as f,BASE.open('rb') as g:
 f.seek(meta['fst_offset']);assert f.read(len(fst))==fst
 f.seek(meta['dol_offset']);g.seek(meta['dol_offset']);n=(WORK/'main.dol').stat().st_size;assert f.read(n)==g.read(n)
 for path,(blob,new) in outputs.items():f.seek(relocated[path]['offset']);assert decode(f.read(len(blob)))==new
allowed=[(meta['dol_offset'],meta['dol_offset']+(WORK/'main.dol').stat().st_size),(meta['fst_offset'],meta['fst_offset']+len(fst))]
# Earlier relocated resources remain present and byte-for-byte inherited.
for version in ['English_Menu_POC','English_Story_v02','English_Menu_v04']:
 r=json.loads((ROOT/version/'build_report.json').read_text(encoding='utf8'))
 if 'title_archive_offset'in r:allowed.append((r['title_archive_offset'],r['title_archive_offset']+r['title_archive_size']))
 if 'room_archive_offset'in r:allowed.append((r['room_archive_offset'],r['room_archive_offset']+r['room_archive_bytes']))
 for e in r.get('relocated_archives',{}).values():allowed.append((e['offset'],e['offset']+e['size']))
allowed.extend((e['offset'],e['offset']+e['size']) for e in relocated.values())
result=package(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Menu_v06.ips',allowed)
assert sha(SOURCE)==previous['source_sha256'] and sha(BASE)==previous['output_sha256']
report=dict(version='0.6',source_sha256=previous['source_sha256'],original_unchanged=True,previous_build_preserved=True,replaced_textures=len(checks),changes='Controlled RGBA8 texture test; same dimensions and artwork renderer as v0.5, no palette quantisation for 11 labels',dol_unchanged_from_v05=True,loader_observation='D4 constructors at 0x8001CF98 and 0x8001D258 call LOD setup 0x8020CAC8 with min/mag arguments 1/1; no sampler or Dolphin settings modified',relocated_archives=relocated,texture_checks=checks,runtime_status='Experimental format change; needs Dolphin check for loading, geometry and edge quality',**result)
(OUT/'build_report.json').write_text(json.dumps(report,indent=2),encoding='utf8')
sheet=Image.new('RGB',(1000,90*(len(previews)+1)),'#304050');dr=ImageDraw.Draw(sheet)
dr.text((5,5),'v0.5 decoded artwork',fill='white');dr.text((510,5),'v0.6 decoded RGBA8 artwork',fill='white')
for i,(name,before,quantised,after) in enumerate(previews):
 y=35+i*90;dr.text((5,y),name,fill='white');sheet.paste(before,(5,y+23),before);sheet.paste(after,(510,y+23),after)
sheet.save(OUT/'format_comparison.png')
print('Built',TARGET,'RGBA8 labels',len(checks),'placements',relocated)
