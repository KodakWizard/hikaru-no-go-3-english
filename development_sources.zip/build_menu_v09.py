"""Cumulative menu audit, credit overlay and alias-safe card message wording."""
from pathlib import Path
import json,struct,re,shutil,math
from PIL import Image,ImageDraw
from textures import resources,texture
from decode_bpe import decode
from archive_edit import rgba_resource,rebuild_archive
from smooth_art import render_label
from menu_translation_v09 import TEXT,CARD_FIXES,LABELS
from menu_translation_v04 import TEXT as PREVIOUS_CARD4
from menu_translation_v05 import TEXT as PREVIOUS_CARD5
from menu_art_v09 import extra_assets,copyright_overlay
from check_cards_v09 import verify as verify_cards
from patch_utils import sha
from bps_patch import make

ROOT=Path(__file__).resolve().parent;WORK=ROOT/'translation_work';OUT=ROOT/'English_Menu_v09';OUT.mkdir(exist_ok=True)
BASE=ROOT/'English_Title_v081/Hikaru no Go 3 - English Title v081.iso';SOURCE=ROOT/'Hikaru no Go 3 (Japan).iso';TARGET=OUT/'Hikaru no Go 3 - English Menu v09.iso'
previous=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((WORK/'disc_metadata.json').read_text())
assert sha(BASE)==previous['output_sha256'] and sha(SOURCE)==previous['source_sha256']
original=(WORK/'main.dol').read_bytes()
with BASE.open('rb') as f:
 f.seek(meta['dol_offset']);old_dol=f.read(len(original));dol=bytearray(old_dol)
 f.seek(meta['fst_offset']);fst=bytearray(f.read(meta['fst_size']));count=int.from_bytes(fst[8:12],'big');names=fst[count*12:];stack=[('',count)];files={}
 for i in range(1,count):
  while i>=stack[-1][1]:stack.pop()
  word,off,size=struct.unpack_from('>III',fst,i*12);name=names[word&0xffffff:].split(b'\0')[0].decode('cp932');path=stack[-1][0]+name
  if word>>24:stack.append((path+'/',size))
  else:files[path]=(off,size,i)
name_report=json.loads((ROOT/'English_Interface_v08/build_report.json').read_text(encoding='utf8'))['name_display']
protected=[int(x,16) for x in name_report['reclaimed_words']]
edits=[];ranges=[]
for at,en in (TEXT|CARD_FIXES).items():
 source=original[at:original.index(0,at)];current=old_dol[at:old_dol.index(0,at)];new=en.encode('cp932')
 assert len(new)<=len(source),(hex(at),'byte capacity',en)
 assert re.findall(rb'%[sd]',source)==re.findall(rb'%[sd]',new),(hex(at),'format tokens')
 assert max(map(len,en.split('\n')))<=40,(hex(at),'line width')
 if current==new:continue
 # Never erase the executable name-normaliser placed in reclaimed string tails.
 # Clear only the previous visible string extent, not its full Japanese slot.
 end=at+max(len(current),len(new))+1
 assert all(end<=p or at>=p+4 for p in protected),(hex(at),'name code overlap')
 dol[at:end]=new+bytes(end-at-len(new));ranges.append((at,end))
 edits.append(dict(offset=hex(at),japanese=source.decode('cp932'),previous=current.decode('cp932'),english=en,capacity=len(source),used=len(new),card_alias_fix=at in CARD_FIXES))
for p in protected:assert dol[p:p+4]==old_dol[p:p+4]
for at in (PREVIOUS_CARD4|PREVIOUS_CARD5|TEXT|CARD_FIXES):
 if not 0x22f900<=at<0x230ef0:continue
 source=original[at:original.index(0,at)]
 if source.startswith(b'%s'):
  assert dol[at:at+2]==b'%s',(hex(at),'in-place card format gained a prefix')
for i,(a,b) in enumerate(zip(old_dol,dol)):
 if a!=b:assert any(lo<=i<hi for lo,hi in ranges),hex(i)
card_checks=verify_cards();blobs={};graphic_checks=[];previews=[]
with BASE.open('rb') as f:
 for src in ['2D/win','2D/brs','2D/rec','2D/fai','2D/scs','title/title']:
  path=src+'.bpe';off,size,_=files[path];f.seek(off);b=decode(f.read(size));lookup=dict(resources(b));arts={}
  for n,t in LABELS.get(src,{}).items():
   im,_=texture(b,lookup[n]);art,budget=render_label(im,t,max_size=min(22,im.height-6),margin=1 if im.width<50 else 3)
   arts[n]=(art,t)
  arts.update(extra_assets(src,b))
  if src=='title/title':arts['lic00.D4']=(copyright_overlay(b),'English creator / publisher copyright overlay')
  replacements={}
  for n,(art,en) in arts.items():
   o=lookup[n];before,_=texture(b,o);assert art.size==before.size
   replacements[n]=rgba_resource(b,o,art);assert texture(replacements[n],0)[0].tobytes()==art.tobytes()
   graphic_checks.append(dict(archive=src,asset=n,english=en,width=art.width,height=art.height,format='RGBA8',decoded_pixels_exact=True));previews.append((n,art))
   if n=='lic00.D4':
    art.save(OUT/'copyright_overlay.png')
    # In-game draw colour may tint this white glyph mask; preview over dark grey.
    title,_=texture(b,lookup['tit02.D4']);title.save(OUT/'title_logo_preserved.png')
  new=rebuild_archive(b,replacements)
  if src=='title/title':
   newlookup=dict(resources(new))
   for n in ['tit00.D4','tit02.D4','tit04.D4','tit05.D4','tit06.D4','tit07.D4']:
    o=lookup[n];z=int.from_bytes(b[o:o+4],'big')+32;a=newlookup[n];assert b[o:o+z]==new[a:a+z]
  blob=len(new).to_bytes(4,'big')+bytes([254,127,254,255])+len(new).to_bytes(4,'big')+new;assert decode(blob)==new;blobs[path]=(blob,new)
entries=json.loads((WORK/'inventory.json').read_text(encoding='utf8'));placement=(max(o+n for o,n,i in files.values() if o<1085734912)+0x7fff)&~0x7fff;relocated={}
for path,(blob,new) in blobs.items():
 assert placement+len(blob)<1085734912
 assert all(placement+len(blob)<=e['offset'] or placement>=e['offset']+e['size'] for e in entries)
 assert all(placement+len(blob)<=o or placement>=o+n for o,n,_ in files.values())
 relocated[path]=dict(offset=placement,size=len(blob));struct.pack_into('>II',fst,files[path][2]*12+4,placement,len(blob));placement=(placement+len(blob)+0x7fff)&~0x7fff
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 f.seek(meta['dol_offset']);f.write(dol);f.seek(meta['fst_offset']);f.write(fst)
 for path,(blob,new) in blobs.items():f.seek(relocated[path]['offset']);f.write(blob)
with TARGET.open('rb') as f:
 f.seek(meta['dol_offset']);assert f.read(len(dol))==dol
 f.seek(meta['fst_offset']);assert f.read(len(fst))==fst
 for path,(blob,new) in blobs.items():f.seek(relocated[path]['offset']);assert decode(f.read(len(blob)))==new
allowed=[(meta['dol_offset'],meta['dol_offset']+len(dol)),(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(e['offset'],e['offset']+e['size']) for e in relocated.values()]
with BASE.open('rb') as f,TARGET.open('rb') as g:
 pos=0
 while True:
  a=f.read(1024*1024);b=g.read(1024*1024)
  if not a:assert not b;break
  assert len(a)==len(b)
  if a!=b:
   for i,(x,y) in enumerate(zip(a,b)):
    if x!=y:assert any(lo<=pos+i<hi for lo,hi in allowed)
  pos+=len(a)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Menu_v09.bps',dict(game='Hikaru no Go 3',version='0.9',base='original Japanese GHTJA4'))
assert sha(BASE)==previous['output_sha256'] and sha(SOURCE)==previous['source_sha256']
report=dict(version='0.9',source_sha256=previous['source_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,text_edits=len(edits),graphic_edits=len(graphic_checks),name_normalizer_code_preserved=True,title_logo_resources_identical_to_v081=True,relocated_files=relocated,edits=edits,graphic_checks=graphic_checks,card_regression=card_checks,patch=patch,new_changes_confined_to_verified_ranges=True,status='Broader menu and card-fix batch; Dolphin test pending; full-game translation remains incomplete')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'translated_text.txt').write_text('\n\n'.join(e['offset']+' '+e['japanese']+'\n'+e['english'] for e in edits),encoding='utf8')
for pg in range(math.ceil(len(previews)/30)):
 items=previews[pg*30:pg*30+30];sheet=Image.new('RGB',(1000,105*((len(items)+1)//2)),'#405060');dr=ImageDraw.Draw(sheet)
 for i,(n,im) in enumerate(items):
  im=im.copy();im.thumbnail((490,78));x=i%2*500;y=i//2*105;dr.text((x+3,y),n,fill='white');sheet.paste(im,(x+3,y+22),im)
 sheet.save(OUT/f'menu_preview_{pg+1}.png')
print('Built',TARGET,'strings',len(edits),'graphics',len(graphic_checks),'card cases',card_checks['slot_and_data_type_tests'],'BPS',patch['bytes'],flush=True)
