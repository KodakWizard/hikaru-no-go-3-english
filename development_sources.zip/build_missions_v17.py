"""Cumulative English application missions, preserving the stable v16 executable/artwork."""
from pathlib import Path
import json,struct,shutil,re,sys
from mission_translation_v17 import TEXT
from qa_translation_v10 import wrap,cells
from qa_research_v10 import current_files
from gcs_text import text_tail
from gcs_rebuild import rebuild,verify_original_roundtrip
from patch_utils import sha
from bps_patch import make
R=Path(__file__).parent;W=R/'translation_work';OUT=R/'English_Missions_v17';OUT.mkdir(exist_ok=True)
BASE=R/'English_ResultRecovery_v16/Hikaru no Go 3 - English Result Recovery v16.iso';SOURCE=R/'Hikaru no Go 3 (Japan).iso';TARGET=OUT/'Hikaru no Go 3 - English Missions v17.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((W/'disc_metadata.json').read_text());f,fst,files=current_files(BASE);blobs={};scripts=[]
assert set(TEXT)==set(range(1,51))
for k,entries in sorted(TEXT.items()):
 path=f'script/mission/mis_{k:03d}.gcs';orig=(W/'extracted'/path).read_bytes();verify_original_roundtrip(orig,True);_,_,rows=text_tail(orig);assert len(entries)==len(rows),(k,len(entries),len(rows));en=[]
 for i,(s,row) in enumerate(zip(entries,rows)):
  is_header=any(int.from_bytes(orig[p-4:p],'big')==0xa6 for p in row['references'])
  if is_header:assert '\n' not in s and '\r' not in s and cells(s)<=44,(k,i,s)
  else:s=wrap(s)
  assert '\r' not in s
  assert re.findall(r'\$\d|%[-0-9]*[sd]',row['japanese'])==re.findall(r'\$\d|%[-0-9]*[sd]',s)
  for symbol in '△□×⑪⑫Д':assert row['japanese'].count(symbol)==s.count(symbol),(k,i,symbol)
  assert not any('\u3040'<=c<='\u9fff' for c in s),(k,i,'Japanese remains')
  en.append(s)
 assert en[0].startswith(f'5-{k:02d}:')
 new,report=rebuild(orig,en,False,True);blobs[path]=(new,new);scripts.append(dict(path=path,entries=len(rows),original_roundtrip_exact=True,non_pointer_code_unchanged=True,header_cell_limit=44,spoken_line_limit=22,spoken_lines=3,translations=report))
assert sum(s['entries'] for s in scripts)==267
(OUT/'translation_review.txt').write_text('\n\n'.join(s['path']+'\n'+'\n'.join(str(r['index'])+': '+r['english'].replace('\n',' / ') for r in s['translations']) for s in scripts),encoding='utf8')
if '--check' in sys.argv:
 print('All checks passed:',len(scripts),'scripts;',sum(s['entries'] for s in scripts),'entries.');sys.exit()
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
inv=json.loads((W/'inventory.json').read_text(encoding='utf8'));placement=(max(o+s for o,s,_ in files.values() if o<1085734912)+0x7fff)&~0x7fff;relocated={}
for path,(blob,_) in blobs.items():
 assert placement+len(blob)<1085734912
 assert all(placement+len(blob)<=e['offset'] or placement>=e['offset']+e['size'] for e in inv)
 assert all(placement+len(blob)<=o or placement>=o+s for o,s,_ in files.values())
 relocated[path]=dict(offset=placement,size=len(blob));struct.pack_into('>II',fst,files[path][2]*12+4,placement,len(blob));placement=(placement+len(blob)+0x7fff)&~0x7fff
f.close();shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as g:
 g.seek(meta['fst_offset']);g.write(fst)
 for path,(blob,_) in blobs.items():g.seek(relocated[path]['offset']);g.write(blob)
with TARGET.open('rb') as g:
 g.seek(meta['fst_offset']);assert g.read(len(fst))==fst
 for path,(blob,new) in blobs.items():g.seek(relocated[path]['offset']);assert g.read(len(blob))==new
allowed=[(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(v['offset'],v['offset']+v['size']) for v in relocated.values()]
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   checked=0
   for lo,hi in sorted(allowed):
    if hi<=pos or lo>=pos+len(x):continue
    aa=max(0,lo-pos);bb=min(len(x),hi-pos)
    if aa>checked:assert x[checked:aa]==y[checked:aa]
    checked=max(checked,bb)
   assert x[checked:]==y[checked:]
  pos+=len(x)
print('Disc differences verified: executable, artwork and other scripts unchanged. Creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Missions_v17.bps',dict(game='Hikaru no Go 3',version='0.17',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.17',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,executable_and_artwork_exactly_v16=True,script_checks=scripts,new_scripts=50,new_entries=267,mission_verified_entries_english=267,numbered_drills_english=200,drill_verified_entries_english=1535,relocated_files=relocated,whole_disc_differences_verified=True,patch=patch,status='All numbered mission scripts translated; v16 stability components preserved; Dolphin gameplay testing pending; full game incomplete')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('Built',TARGET,report['output_sha256'],flush=True)
