"""Experimental shareable game patch: CNameInput normalises confirmed Latin names."""
from pathlib import Path
import json,struct,shutil
from name_entry_v55 import code,validate,branch,CODE_BASE,RESERVED_END
from patch_utils import sha
from qa_research_v10 import current_files
from bps_patch import make
R=Path(__file__).resolve().parent
BASE=R/'English_FontRestore_v53/Hikaru no Go 3 - English Font Restore v53.iso'
ORIGINAL=R/'Hikaru no Go 3 (Japan).iso'
OUT=R/'English_NameEntry_Test_v55'
TARGET=OUT/'Hikaru no Go 3 - English Name Entry Test v55.iso'
assert not OUT.exists(),'Preserve previous test builds.'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
assert sha(BASE)==prior['output_sha256'] and sha(ORIGINAL)==prior['source_sha256']
tests=validate();blob,labels=code()
original=(R/'translation_work/main.dol').read_bytes()
with BASE.open('rb') as f:
 f.seek(0x420);old_dol_offset=int.from_bytes(f.read(4),'big')
 f.seek(old_dol_offset);before=f.read(len(original))
dol=bytearray(before)
sections=[]
for i in range(18):
 off,addr,n=[int.from_bytes(original[k+i*4:k+i*4+4],'big') for k in [0,0x48,0x90]]
 if n:sections.append((i,off,addr,n))
assert all(CODE_BASE+len(blob)<=addr or CODE_BASE>=addr+n for _,_,addr,n in sections)
bss,bss_n=struct.unpack_from('>II',original,0xd8)
assert bss+bss_n<0x80429d98<CODE_BASE<RESERVED_END
# Confirm stock startup stack, OS fallback arena low, and setter signatures.
def offset(addr):
 for _,o,a,n in sections:
  if a<=addr<a+n:return o+addr-a
 raise AssertionError(hex(addr))
def word(addr):return int.from_bytes(original[offset(addr):offset(addr)+4],'big')
assert word(0x80003278)==0x3c208042 and word(0x8000327c)==0x60219d98
assert word(0x801ecd08)==0x3c608043 and word(0x801ecd0c)==0x3863bda0
assert word(0x801ee138)==0x906d9048 and word(0x801ee13c)==0x4e800020
# A real DOL text section, not code in translated-string tails or BSS.
section=2
assert all(struct.unpack_from('>I',dol,k+section*4)[0]==0 for k in [0,0x48,0x90])
new_off=(len(dol)+31)&~31
dol.extend(bytes(new_off-len(dol)));dol.extend(blob)
for k,v in [(0,new_off),(0x48,CODE_BASE),(0x90,len(blob))]:struct.pack_into('>I',dol,k+section*4,v)
edits={
 0x80173e64:branch(0x80173e64,labels['expand'],True),
 0x80173e6c:0x389f00ed, # display the expanded editor buffer
 0x80173e74:0x387f00ed, # original strlen/2 now sees the expanded editor buffer
 0x80173f98:branch(0x80173f98,labels['narrow'],True),
 0x80149554:branch(0x80149554,labels['narrow'],True), # fresh Story profile
 0x80171ff8:branch(0x80171ff8,labels['narrow'],True), # registered player creation
 0x8017209c:branch(0x8017209c,labels['narrow'],True), # player-list creation
 0x8014df54:branch(0x8014df54,labels['narrow'],True), # registered player rename
 0x8014e574:branch(0x8014e574,labels['expand'],True), # registered player editor
 0x8014e57c:0x389d00ed,
 0x8014e584:0x387d00ed,
 0x801ee138:branch(0x801ee138,labels['arena_floor']),
}
assert word(0x80173e64)==branch(0x80173e64,0x8021d080,True)
assert word(0x80173f98)==branch(0x80173f98,0x8021d080,True)
assert word(0x80173e6c)==0x389e1e40 and word(0x80173e74)==0x387e1e40
for addr in [0x80149554,0x80171ff8,0x8017209c,0x8014df54,0x8014e574]:assert word(addr)==branch(addr,0x8021d080,True)
assert word(0x8014e57c)==0x7fc4f378 and word(0x8014e584)==0x7fc3f378
for addr,w in edits.items():
 o=offset(addr);assert dol[o:o+4]==original[o:o+4]
 struct.pack_into('>I',dol,o,w)
# All other original code and data must be byte-exact v53, including old hooks.
allowed_dol=[(k+section*4,k+section*4+4) for k in [0,0x48,0x90]]+[(offset(a),offset(a)+4) for a in edits]
for i,(a,b) in enumerate(zip(before,dol)):
 if a!=b:assert any(lo<=i<hi for lo,hi in allowed_dol),hex(i)
old_sites=[0x801a3c0c,0x80024b10,0x80025530,0x80142010,0x8014201c,0x8014204c,0x80142058]
assert all(dol[offset(a):offset(a)+4]==original[offset(a):offset(a)+4] for a in old_sites)
f,fst,files=current_files(BASE)
placement=(max(o+n for o,n,_ in files.values() if o<1085734912)+0x7fff)&~0x7fff
inv=json.loads((R/'translation_work/inventory.json').read_text())
while placement+len(dol)<1085734912:
 f.seek(placement);probe=f.read(len(dol))
 with ORIGINAL.open('rb') as source:source.seek(placement);padding=source.read(len(dol))
 if probe==padding:break
 # Prior inactive versions remain preserved. Search a fresh aligned extent.
 placement=(placement+len(dol)+0x7fff)&~0x7fff
assert placement+len(dol)<1085734912
assert all(placement+len(dol)<=row['offset'] or placement>=row['offset']+row['size'] for row in inv)
assert all(placement+len(dol)<=o or placement>=o+n for o,n,_ in files.values())
f.seek(placement);replaced=f.read(len(dol))
with ORIGINAL.open('rb') as source:source.seek(placement);assert replaced==source.read(len(dol))
f.close()
OUT.mkdir();shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 f.seek(placement);f.write(dol)
 f.seek(0x420);f.write(placement.to_bytes(4,'big'))
with TARGET.open('rb') as f:
 f.seek(0x420);assert int.from_bytes(f.read(4),'big')==placement
 f.seek(placement);assert f.read(len(dol))==dol
f,got,active=current_files(TARGET);g,_,old=current_files(BASE)
assert got==fst and active==old and len(active)==719
for p,(o,n,_) in active.items():
 f.seek(o);g.seek(o);assert f.read(n)==g.read(n),p
f.close();g.close()
allowed=[(0x420,0x424),(placement,placement+len(dol))]
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   cursor=0
   for lo,hi in allowed:
    aa=max(0,lo-pos);bb=min(len(x),hi-pos)
    if aa<bb:assert x[cursor:aa]==y[cursor:aa];cursor=bb
   assert x[cursor:]==y[cursor:]
  pos+=len(x)
print('Readback, scoped code changes, all719 resources and whole-disc ranges pass. Creating cumulative BPS.',flush=True)
patch=make(ORIGINAL,TARGET,OUT/'Hikaru_no_Go_3_English_NameEntry_Test_v55.bps',dict(game='Hikaru no Go 3',version='0.55-test',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(ORIGINAL)==prior['source_sha256']
report=dict(version='0.55-test',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),tests=tests,dol_offset=placement,dol_bytes=len(dol),new_section=dict(index=section,file_offset=new_off,ram=hex(CODE_BASE),size=len(blob)),reserved_arena_floor=hex(RESERVED_END),code_edits={hex(a):hex(w) for a,w in edits.items()},original_name_and_font_display_hooks_disabled=True,all719_active_resources_exact_v53=True,font_graphics_scripts_dialogue_gba_exact_v53=True,normal_saves_and_settings_untouched=True,whole_disc_verified=True,patch=patch,runtime='Pending user Dolphin tests. Not a release candidate.',existing_saves='Reconfirm the player name through the game name-entry screen. No automatic load-time conversion.')
(OUT/'build_report.json').write_text(json.dumps(report,indent=2),encoding='utf8')
(OUT/'README.md').write_text('''# Shareable game-side name-entry experiment v55

This BPS applies to the original Japanese ISO and contains the complete translation
plus the new name-entry experiment. It contains no personal save files or emulator
profile. All v53 translation, font, artwork and title-overlay changes are retained.

Latin letters/digits are converted to ordinary ASCII when the player confirms their
name in the game. The normal game handles saving and checksums. New players use the
ordinary name-entry screen. Existing fullwidth names need to be opened and confirmed
once through the in-game name editor; simply loading a save does not convert it.

Inside name entry, Latin names are temporarily expanded to the original two-byte
editor format so character count, five-character limit, deletion, selection and
Japanese input keep their original behaviour. Cancelling does not confirm a rename.
Names therefore still look widely spaced while editing, then compact elsewhere.

The change is confined to five name-confirmation copies (fresh Story, Story rename,
registered-player creation and renaming), two editor-input copies, four editor-buffer
references, and a small arena-memory reservation. A declared 436-byte DOL text section holds the
conversion functions; the arena floor is clamped to 0x8042c400 to prevent allocation
over it. It lies beyond the original BSS and startup/default-thread stacks. Earlier
font, Story-name and battle-name display hooks remain disabled.

Offline instruction tests cover 2068 fullwidth Latin, digits, Japanese and mixed-name
cases, round trips, original two-byte deletion/counting, bounded editor capacity,
source preservation and nonvolatile registers. Six arena-boundary cases pass.
Finished-disc readback, all 719 active resources, exact permitted differences,
original/base hashes and cumulative BPS reconstruction are verified.

## Required testing before sharing publicly

Use a backup/test memory card. Cold boot this ISO; avoid emulator savestates.
1. Start a fresh game and enter a Latin name, including deleting/replacing letters.
2. Confirm it and check dialogue, battle HUD, Player Results and match results.
3. On a copied existing fullwidth save, reconfirm the name through the game editor.
4. Reopen that editor; delete/replace letters, cancel once, then confirm once.
5. Save/reload, finish a match, leave its result screen, and return to the room.
6. Test a Japanese and mixed Japanese/Latin name if retaining that input support.

This is an experimental game patch, not a certified release. Runtime, real-hardware
boot and broader regression testing remain outstanding. Normal saves were not edited.
The v54 converted saves are not needed and should not be distributed with the patch.
''',encoding='utf8')
print('Built',TARGET,report['output_sha256'],flush=True)
