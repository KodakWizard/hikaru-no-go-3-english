"""Build the English opening-menu experiment without writing the source ISO."""
from pathlib import Path
import struct,json,hashlib,shutil,zipfile,base64,re
from PIL import Image,ImageDraw,ImageFont
from textures import resources,texture
from decode_bpe import decode

ROOT=Path(__file__).resolve().parent
WORK=ROOT/'translation_work'; RELEASE=ROOT/'English_Menu_POC'; RELEASE.mkdir(exist_ok=True)
source=ROOT/'Hikaru no Go 3 (Japan).iso'; target=RELEASE/'Hikaru no Go 3 - English Menu POC.iso'
assert source.resolve()!=target.resolve()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
original_sha=sha(source)

# Preserve dimensions, GX CI4 format, palettes, and every non-menu resource.
b=bytearray((WORK/'decoded/title/title.bin').read_bytes()); previews=[]
for name,o in resources(b):
 if name not in ('tit04.D4','tit05.D4','tit06.D4','tit07.D4'):continue
 im,desc=texture(b,o);fmt,w,h,start=desc
 assert (fmt,w,h)==(8,190,46)
 text='STORY' if name in ('tit04.D4','tit06.D4') else 'FREE MATCH'
 mask=Image.new('L',(w,h));dr=ImageDraw.Draw(mask)
 font=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',29)
 box=dr.textbbox((0,0),text,font=font);tw=box[2]-box[0];th=box[3]-box[1]
 dr.text(((w-tw)//2-box[0],(h-th)//2-box[1]),text,font=font,fill=255,stroke_width=0)
 # Derive alpha shades from the existing RGB5A3 palette; retain gold/grey styling.
 pf,n=struct.unpack_from('>HH',b,o+44);assert pf==2
 alphas=[]
 for j in range(n):
  v=int.from_bytes(b[o+64+j*2:o+66+j*2],'big');alphas.append(255 if v&0x8000 else ((v>>12)&7)*255//7)
 colors=[]
 for j in range(n):
  v=int.from_bytes(b[o+64+j*2:o+66+j*2],'big')
  rgb=(((v>>10)&31)*255//31,((v>>5)&31)*255//31,(v&31)*255//31) if v&32768 else (((v>>8)&15)*17,((v>>4)&15)*17,(v&15)*17)
  colors.append(rgb)
 indices=[min(range(n),key=lambda j:(abs(alphas[j]-v),-sum(colors[j]))) for v in mask.getdata()]
 packed=bytearray()
 for y in range(0,h,8):
  for x in range(0,w,8):
   vals=[indices[(y+yy)*w+x+xx] if y+yy<h and x+xx<w else 0 for yy in range(8) for xx in range(8)]
   packed.extend((vals[j]<<4)|vals[j+1] for j in range(0,64,2))
 b[start:start+len(packed)]=packed
 after,_=texture(b,o);after.save(RELEASE/(name+'_English.png'));previews.append((name,im,after))

# Identity dictionaries are valid BPE. Larger archive is placed in an unused FST gap.
identity=bytes([254,127,254,255])
archive=len(b).to_bytes(4,'big')+identity+len(b).to_bytes(4,'big')+b
assert decode(archive)==b
(WORK/'title_english.bpe').write_bytes(archive)
dol=bytearray((WORK/'main.dol').read_bytes()); edits=[]
translations={
 'ストーリー':'Story',
 '１対１の対局をします':'Play a 1-on-1 match.',
 '２人対２人で対局します':'Play a 2-on-2 match.',
 '２人対２人の対局をします':'Play a 2-on-2 match.',
 '棋譜と名対局をみることができます':'View records and famous games.',
 '対局成績やエフェクトを管理します':'Manage results and effects.',
 'コントローラとサウンドを設定します':'Set controls and sound.',
 '成績とプレイ時間をみることができます':'View results and play time.',
 'プレイヤーデータを設定します':'Set player data.',
 '棋譜データを選択して下さい':'Select a game record.',
 '対局を選択して下さい':'Select a match.',
 '名前を入力してください':'Enter your name.',
 'ストーリーはポート１のコントローラを使用してください':'Use the controller in Port 1 for Story.',
 '対局するキャラクターを設定してください':'Select the characters for the match.',
}
for jp,en in translations.items():
 old=jp.encode('cp932');new=en.encode('ascii');assert len(new)<=len(old),(jp,en)
 for m in list(re.finditer(re.escape(old)+b'\0',bytes(dol))):
  off=m.start();dol[off:off+len(old)+1]=new+b'\0'*(len(old)+1-len(new));edits.append(dict(dol_offset=off,japanese=jp,english=en,capacity=len(old)))
metadata=json.loads((WORK/'disc_metadata.json').read_text());entries=json.loads((WORK/'inventory.json').read_text(encoding='utf8'))
ordered=sorted(entries,key=lambda e:e['offset']);gaps=[(a['offset']+a['size'],z['offset']) for a,z in zip(ordered,ordered[1:])]
gaps=[((s+0x7fff)&~0x7fff,e) for s,e in gaps];gaps=[(s,e) for s,e in gaps if e-s>=len(archive)]
assert gaps,'No safe inter-file gap for title archive'
placement=max(gaps,key=lambda g:g[1]-g[0])[0]
with source.open('rb') as f:
 f.seek(metadata['fst_offset']);fst=bytearray(f.read(metadata['fst_size']))
count=int.from_bytes(fst[8:12],'big');strings=fst[count*12:];stack=[('',count)];found=False
for i in range(1,count):
 while i>=stack[-1][1]:stack.pop()
 word,off,size=struct.unpack_from('>III',fst,i*12);name=strings[word&0xffffff:].split(b'\0')[0].decode('cp932');path=stack[-1][0]+name
 if word>>24:stack.append((path+'/',size))
 elif path=='title/title.bpe':
  struct.pack_into('>II',fst,i*12+4,placement,len(archive));found=True
assert found
shutil.copyfile(source,target)
with target.open('r+b') as f:
 f.seek(metadata['dol_offset']);f.write(dol)
 f.seek(metadata['fst_offset']);f.write(fst)
 f.seek(placement);f.write(archive)
assert target.stat().st_size==source.stat().st_size
assert sha(source)==original_sha
with target.open('rb') as f:
 f.seek(placement);assert decode(f.read(len(archive)))==b
 f.seek(metadata['dol_offset']);assert f.read(len(dol))==dol
 f.seek(metadata['fst_offset']);assert f.read(len(fst))==fst
report=dict(source_sha256=original_sha,output_sha256=sha(target),source_unchanged=True,disc_id=metadata['id'],title_archive_offset=placement,title_archive_size=len(archive),modified_textures=[p[0] for p in previews],text_changes=edits,status='Binary and texture checks passed; Dolphin test required')
(RELEASE/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
sheet=Image.new('RGB',(440,len(previews)*80),'#203040');dr=ImageDraw.Draw(sheet)
for i,(name,before,after) in enumerate(previews):
 dr.text((10,i*80+2),name,fill='white');sheet.paste(before,(10,i*80+23),before);sheet.paste(after,(230,i*80+23),after)
sheet.save(RELEASE/'menu_before_after.png')
print(json.dumps(report,ensure_ascii=True,indent=2))
