"""Score prediction, problem-heading and graphics fixes from v0.11."""
from pathlib import Path
import json,struct,shutil,re,sys
from PIL import Image,ImageDraw,ImageFont
from qa_research_v10 import current_files
from translation_v12 import TEXT,PAD_SLOTS,HEADINGS
from qa_translation_v10 import cells
from art_v12 import counters,extra_graphics
from font_uv_v12 import patch as patch_uv
from textures import resources,texture
from archive_edit import rgba_resource,rebuild_archive
from decode_bpe import decode
from gcs_rebuild import rebuild,verify_original_roundtrip
from patch_utils import sha
from bps_patch import make
R=Path(__file__).parent;W=R/'translation_work';OUT=R/'English_Polish_v12';OUT.mkdir(exist_ok=True);(OUT/'assets').mkdir(exist_ok=True)
BASE=R/'English_Content_v11/Hikaru no Go 3 - English Content v11.iso';SOURCE=R/'Hikaru no Go 3 (Japan).iso';TARGET=OUT/'Hikaru no Go 3 - English Polish v12.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((W/'disc_metadata.json').read_text());original=(W/'main.dol').read_bytes();f,fst,files=current_files(BASE);f.seek(meta['dol_offset']);before=f.read(len(original));dol=bytearray(before);edits=[];ranges=[]
protected={int(p,16) for p in json.loads((R/'English_Interface_v08/build_report.json').read_text())['name_display']['reclaimed_words']};protected.update(int(p,16) for p in prior['hud_names']['reclaimed_words'])
for at,en in TEXT.items():
 raw=original[at:original.index(0,at)];now=before[at:before.index(0,at)];encoded=en.encode('cp932');capacity=len(raw)
 if at in PAD_SLOTS:
  end=PAD_SLOTS[at];assert original[at+len(raw):end]==bytes(end-at-len(raw)) and before[at+len(now):end]==bytes(end-at-len(now))
  ram=0x804132e0+at-0x2d4c20
  for p in range(at+len(raw)+1,end):assert (ram+p-at).to_bytes(4,'big') not in original
  capacity=end-at-1
 assert len(encoded)<=capacity,(hex(at),en,capacity)
 assert re.findall(rb'%[-0-9]*[sd]',raw)==re.findall(rb'%[-0-9]*[sd]',encoded)
 used=max(len(now),len(encoded))+1;assert not any(at<p+4 and p<at+used for p in protected)
 dol[at:at+used]=encoded+bytes(used-len(encoded));ranges.append((at,at+used));edits.append(dict(offset=hex(at),japanese=raw.decode('cp932'),previous=now.decode('cp932'),english=en,capacity=capacity))
uv=patch_uv(dol,original,protected);ranges+=uv['ranges'];h=int(uv['hook'],16)-0x80018ba0+0x2620;ranges.append((h,h+4))
assert all(before[p:p+4]==dol[p:p+4] for p in protected)
assert all(a==b or any(lo<=i<hi for lo,hi in ranges) for i,(a,b) in enumerate(zip(before,dol)))
def archive(path):
 o,s,_=files[path];f.seek(o);return decode(f.read(s))
blobs={};graphics=[];previews=[]
for path in ['2D/bbg.bpe','2D/mjw.bpe','2D/mba.bpe','2D/agbctrdl.bpe','2D/end.bpe']:
 b=archive(path);mapping=counters(decode((W/'extracted/2D/bbg.bpe').read_bytes())) if path=='2D/bbg.bpe' else extra_graphics(path,b);look=dict(resources(b));replace={}
 for n,im in mapping.items():
  old,_=texture(b,look[n]);assert old.size==im.size;replace[n]=rgba_resource(b,look[n],im);assert texture(replace[n],0)[0].tobytes()==im.tobytes();im.save(OUT/'assets'/(path.split('/')[-1]+'.'+n+'.png'));graphics.append(dict(path=path,asset=n,dimensions=list(im.size),rgba8_exact=True));previews.append((path+'/'+n,im))
 new=rebuild_archive(b,replace);blob=len(new).to_bytes(4,'big')+bytes([254,127,254,255])+len(new).to_bytes(4,'big')+new;assert decode(blob)==new;blobs[path]=(blob,new)
scripts=[];v11={s['path']:s for s in prior['script_checks']}
for k,heading in HEADINGS.items():
 assert '\n' not in heading and '\r' not in heading and cells(heading)<=44,(k,heading,cells(heading))
 path=f'script/drill/dri_{k:03d}.gcs';orig=(W/'extracted'/path).read_bytes();verify_original_roundtrip(orig,True);en=[r['english'] for r in v11[path]['translations']];en[0]=heading;new,report=rebuild(orig,en,False,True)
 assert [r['english'] for r in report[1:]]==[r['english'] for r in v11[path]['translations'][1:]]
 blobs[path]=(new,new);scripts.append(dict(path=path,header=heading,halfwidth_cells=cells(heading),original_roundtrip_exact=True,non_pointer_code_unchanged=True,all_feedback_unchanged_from_v11=True,translations=report))
# Graphic previews use a textured background and actual counter-number overlays.
sheet=Image.new('RGB',(1000,125*((len(previews)+3)//4)),'#6d5947');dr=ImageDraw.Draw(sheet)
for i,(n,im) in enumerate(previews):
 if 'bbg11_' in n:im=im.crop((0,392,122,448))
 im=im.copy();im.thumbnail((240,100));x=i%4*250;y=i//4*125;dr.text((x,y),n.split('/')[-1],fill='white');sheet.paste(im,(x,y+20),im)
sheet.save(OUT/'asset_preview.png')
bar=Image.new('RGBA',(300,76),(112,77,43,255));b=archive('2D/bbg.bpe');look=dict(resources(b));src=decode((W/'extracted/2D/bbg.bpe').read_bytes());fixed=counters(src);bar.alpha_composite(fixed['bbg01_0_1.D4'],(0,10));bar.alpha_composite(fixed['bbg11_1.D4'].crop((0,392,122,448)),(170,10));ImageDraw.Draw(bar).text((94,23),'0',font=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',20),fill='white');ImageDraw.Draw(bar).text((186,23),'0',font=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',20),fill='white');bar.resize((1200,304)).save(OUT/'counter_layout_preview.png')
(OUT/'headers.txt').write_text('\n'.join(HEADINGS.values()),encoding='utf8')
if '--preview' in sys.argv:
 (OUT/'font_uv_check.json').write_text(json.dumps(uv,indent=2),encoding='utf8');print('Preview checks passed:',len(edits),'constants,',len(graphics),'graphics,',len(scripts),'headers;',uv['ppc_grid_tests'],'PPC font grid tests.');sys.exit()
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
inv=json.loads((W/'inventory.json').read_text(encoding='utf8'));placement=(max(o+s for o,s,_ in files.values() if o<1085734912)+0x7fff)&~0x7fff;relocated={}
for path,(blob,_) in blobs.items():
 assert placement+len(blob)<1085734912
 assert all(placement+len(blob)<=e['offset'] or placement>=e['offset']+e['size'] for e in inv)
 assert all(placement+len(blob)<=o or placement>=o+s for o,s,_ in files.values())
 relocated[path]=dict(offset=placement,size=len(blob));struct.pack_into('>II',fst,files[path][2]*12+4,placement,len(blob));placement=(placement+len(blob)+0x7fff)&~0x7fff
f.close();shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as g:
 g.seek(meta['dol_offset']);g.write(dol);g.seek(meta['fst_offset']);g.write(fst)
 for path,(blob,_) in blobs.items():g.seek(relocated[path]['offset']);g.write(blob)
with TARGET.open('rb') as g:
 g.seek(meta['dol_offset']);assert g.read(len(dol))==dol;g.seek(meta['fst_offset']);assert g.read(len(fst))==fst
 for path,(blob,new) in blobs.items():g.seek(relocated[path]['offset']);got=g.read(len(blob));assert (decode(got) if path.endswith('.bpe') else got)==new
allowed=[(meta['dol_offset']+a,meta['dol_offset']+b) for a,b in ranges]+[(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(v['offset'],v['offset']+v['size']) for v in relocated.values()]
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   checked=0
   for lo,hi in sorted(allowed):
    if hi<=pos or lo>=pos+len(x):continue
    aa=max(0,lo-pos);bb=min(len(x),hi-pos)
    if aa>checked:assert x[checked:aa]==y[checked:aa]
    checked=max(checked,bb)
   assert x[checked:]==y[checked:]
  pos+=len(x)
print('Disc verification passed; generating cumulative patch.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Polish_v12.bps',dict(game='Hikaru no Go 3',version='0.12',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.12',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,dol_strings=edits,font_uv=uv,prior_name_code_preserved=True,native_font_archive_unchanged=True,graphic_checks=graphics,script_checks=scripts,relocated_files=relocated,whole_disc_differences_verified=True,patch=patch,status='Screenshot repair batch; Dolphin verification required; full game incomplete')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('Built',TARGET,report['output_sha256'],flush=True)
