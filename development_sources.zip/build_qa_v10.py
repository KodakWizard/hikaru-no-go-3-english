"""Cumulative fixes for tutorial, loading and battle screenshot reports."""
from pathlib import Path
import json,struct,shutil,re,sys
from PIL import Image,ImageDraw
from qa_research_v10 import current_files
from qa_translation_v10 import TEXT,LESSONS,wrap,cells
from qa_art_v10 import counters,tabs,padded_ascii,label
from textures import resources,texture
from archive_edit import rgba_resource,rebuild_archive
from decode_bpe import decode
from gcs_rebuild import rebuild,verify_original_roundtrip
from gcs_text import text_tail
from name_display_v08 import branch
from patch_utils import sha
from bps_patch import make
ROOT=Path(__file__).parent;WORK=ROOT/'translation_work';OUT=ROOT/'English_QA_v10';OUT.mkdir(exist_ok=True)
SOURCE=ROOT/'Hikaru no Go 3 (Japan).iso';BASE=ROOT/'English_Load_v091/Hikaru no Go 3 - English Load v091.iso';TARGET=OUT/'Hikaru no Go 3 - English QA v10.iso'
previous=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((WORK/'disc_metadata.json').read_text())
f,fst,files=current_files();original=(WORK/'main.dol').read_bytes();f.seek(meta['dol_offset']);old_dol=f.read(len(original));dol=bytearray(old_dol);ranges=[];edits=[]
protected={int(x,16) for x in json.loads((ROOT/'English_Interface_v08/build_report.json').read_text())['name_display']['reclaimed_words']}
for at,en in TEXT.items():
 raw=original[at:original.index(0,at)];now=old_dol[at:old_dol.index(0,at)];new=en.encode('cp932');assert len(new)<=len(raw),(hex(at),en,len(raw))
 assert now in [raw,new,b'Ah, such memories...'],(hex(at),'unexpected prior edit',now)
 assert re.findall(rb'%[-0-9]*[sd]',raw)==re.findall(rb'%[-0-9]*[sd]',new)
 used=max(len(now),len(new))+1;assert not any(at<=p<at+used or p<=at<p+4 for p in protected)
 dol[at:at+used]=new+bytes(used-len(new));ranges.append((at,at+used));edits.append(dict(offset=hex(at),japanese=raw.decode('cp932'),english=en))
hooks=[0x80146944,0x8014696c,0x8014698c,0x801469b4,0x801469e8,0x80146a14]
entry=int(json.loads((ROOT/'English_Interface_v08/build_report.json').read_text())['name_display']['entry'],16)
for addr in hooks:
 at=addr-0x80018ba0+0x2620;assert int.from_bytes(dol[at:at+4],'big')==branch(addr,0x8021d080,True)
 struct.pack_into('>I',dol,at,branch(addr,entry,True));ranges.append((at,at+4))
assert all(old_dol[p:p+4]==dol[p:p+4] for p in protected)
assert all(a==b or any(lo<=i<hi for lo,hi in ranges) for i,(a,b) in enumerate(zip(old_dol,dol)))
def archive(path):
 o,s,_=files[path];f.seek(o);return decode(f.read(s))
blobs={};graphics=[];previews=[]
arts={};current={}
for path in ['2D/fai.bpe','2D/bbg.bpe','2D/mjw.bpe','2D/agbctrdl.bpe','font24/hggc24.bpe']:
 current[path]=archive(path);arts[path]={}
arts['2D/fai.bpe']=tabs(current['2D/fai.bpe'])
arts['2D/bbg.bpe']=counters(decode((WORK/'extracted/2D/bbg.bpe').read_bytes()))
b=current['2D/mjw.bpe'];o=dict(resources(b))['mba02_30.D4'];im,_=texture(b,o);arts['2D/mjw.bpe']['mba02_30.D4']=label(im.size,'Go\nCourse',17)
b=current['font24/hggc24.bpe'];o=dict(resources(b))['hggc24_a.D4'];im,_=texture(b,o);arts['font24/hggc24.bpe']['hggc24_a.D4']=padded_ascii(im)
b=current['2D/agbctrdl.bpe'];look=dict(resources(b));im,_=texture(b,look['cau11.D4'])
incoming=Image.open(OUT/'assets/loading_logo_generated.png').convert('RGBA');bbox=incoming.getchannel('A').getbbox();incoming=incoming.crop(bbox);incoming.thumbnail((im.width-4,im.height-4),Image.Resampling.LANCZOS)
art=Image.new('RGBA',im.size);art.alpha_composite(incoming,((im.width-incoming.width)//2,(im.height-incoming.height)//2));arts['2D/agbctrdl.bpe']['cau11.D4']=art
im,_=texture(b,look['cau12.D4']);art=Image.new('RGBA',im.size);art.paste(im.crop((0,21,640,23)),(0,21));art.alpha_composite(label((125,20),'Now Loading...',14),(334,0));art.alpha_composite(label((170,20),'Please wait.',14,(255,180,0,255)),(460,0));arts['2D/agbctrdl.bpe']['cau12.D4']=art
for path,mapping in arts.items():
 b=current[path];look=dict(resources(b));replacements={}
 for n,im in mapping.items():
  before,desc=texture(b,look[n]);replacements[n]=rgba_resource(b,look[n],im);assert texture(replacements[n],0)[0].tobytes()==im.tobytes()
  im.save(OUT/'assets'/(n+'.png'));graphics.append(dict(archive=path,asset=n,before_dimensions=list(before.size),dimensions=list(im.size),rgba8_exact=True));previews.append((n,im))
 new=rebuild_archive(b,replacements);blob=len(new).to_bytes(4,'big')+bytes([254,127,254,255])+len(new).to_bytes(4,'big')+new;assert decode(blob)==new;blobs[path]=(blob,new)
script_checks=[]
for name,rows in LESSONS.items():
 path='script/tutorial/'+name+'.gcs';orig=(WORK/'extracted'/path).read_bytes();verify_original_roundtrip(orig);_,_,source_rows=text_tail(orig);en=[wrap(s) for s in rows]
 for src,s in zip(source_rows,en):
  assert '\r' not in s and len(s.split('\n'))<=3 and all(cells(line)<=22 for line in s.split('\n'))
  assert re.findall(r'\$\d|%[sd]',s)==re.findall(r'\$\d|%[sd]',src['japanese'])
  assert s.count('⑪')==src['japanese'].count('⑪')
 new,report=rebuild(orig,en,False);blobs[path]=(new,new);script_checks.append(dict(path=path,entries=len(en),original_exact_roundtrip=True,code_unchanged_except_verified_string_operands=True,lines_max=3,cells_max=22,line_break='LF only',translations=report))
# Native-scale previews enlarged only for inspection, not a Dolphin capture.
sheet=Image.new('RGB',(900,150*((len(previews)+2)//3)),'#554f49');dr=ImageDraw.Draw(sheet)
for i,(n,im) in enumerate(previews):
 if n.startswith('hggc'):im=im.crop((0,96,384,384))
 if n.startswith('bbg11'):im=im.crop((0,392,122,448))
 im=im.copy();im.thumbnail((290,125));x=i%3*300;y=i//3*150;dr.text((x,y),n,fill='white');sheet.paste(im,(x,y+20),im)
sheet.save(OUT/'asset_preview.png')
if '--preview' in sys.argv:print('Preview prepared; all script and DOL checks pass.');sys.exit()
assert sha(BASE)==previous['output_sha256'] and sha(SOURCE)==previous['source_sha256']
inv=json.loads((WORK/'inventory.json').read_text(encoding='utf8'));placement=(max(o+s for o,s,_ in files.values() if o<1085734912)+0x7fff)&~0x7fff;relocated={}
for path,(blob,_) in blobs.items():
 assert placement+len(blob)<1085734912
 assert all(placement+len(blob)<=e['offset'] or placement>=e['offset']+e['size'] for e in inv)
 assert all(placement+len(blob)<=o or placement>=o+s for o,s,_ in files.values())
 relocated[path]=dict(offset=placement,size=len(blob));struct.pack_into('>II',fst,files[path][2]*12+4,placement,len(blob));placement=(placement+len(blob)+0x7fff)&~0x7fff
f.close();shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as g:
 g.seek(meta['dol_offset']);g.write(dol);g.seek(meta['fst_offset']);g.write(fst)
 for path,(blob,_) in blobs.items():g.seek(relocated[path]['offset']);g.write(blob)
with TARGET.open('rb') as g:
 g.seek(meta['dol_offset']);assert g.read(len(dol))==dol;g.seek(meta['fst_offset']);assert g.read(len(fst))==fst
 for path,(blob,new) in blobs.items():g.seek(relocated[path]['offset']);got=g.read(len(blob));assert (decode(got) if path.endswith('.bpe') else got)==new
allowed=[(meta['dol_offset']+lo,meta['dol_offset']+hi) for lo,hi in ranges]+[(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(v['offset'],v['offset']+v['size']) for v in relocated.values()]
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   for i,(u,v) in enumerate(zip(x,y)):
    if u!=v:assert any(lo<=pos+i<hi for lo,hi in allowed),hex(pos+i)
  pos+=len(x)
print('ISO read-back and whole-disc checks passed; building cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_QA_v10.bps',dict(game='Hikaru no Go 3',version='0.10',base='original Japanese GHTJA4'))
assert sha(BASE)==previous['output_sha256'] and sha(SOURCE)==previous['source_sha256']
report=dict(version='0.10',source_sha256=previous['source_sha256'],previous_sha256=previous['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,dol_strings=edits,battle_display_copy_hooks=[hex(x) for x in hooks],name_normalizer_entry=hex(entry),existing_name_code_unchanged=True,saved_name_data_unchanged=True,graphic_checks=graphics,script_checks=script_checks,relocated_files=relocated,whole_disc_differences_verified=True,patch=patch,status='Screenshot repair batch; Dolphin verification required; full game incomplete',font_status='Transparent gutters on doubled ASCII atlas mitigate suspected bilinear sampling bleed; runtime visual/memory test pending')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('Built',TARGET,'SHA256',report['output_sha256'],flush=True)
