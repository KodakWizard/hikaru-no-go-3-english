"""Screenshot graphics QA with native image layouts and visible estimate-format edits only."""
from pathlib import Path
import json, re, shutil, sys
from qa_text_v47 import TEXT as MATCH, EXPECTED, AUDIT
import textwrap
TEXT={}
for at,en in MATCH.items():
 TEXT[at]=en
from patch_utils import sha
from bps_patch import make

R=Path(__file__).parent; W=R/'translation_work'
OUT=R/'English_QA_v47'; OUT.mkdir(exist_ok=True)
BASE=R/'English_QA_v46/Hikaru no Go 3 - English QA v46.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso'
TARGET=OUT/'Hikaru no Go 3 - English QA v47.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
meta=json.loads((W/'disc_metadata.json').read_text())
original=(W/'main.dol').read_bytes()
with BASE.open('rb') as f:
 f.seek(meta['dol_offset']); before=f.read(len(original))
dol=bytearray(before)
protected=set()
for folder,key in [('English_Interface_v08','name_display'),('English_Content_v11','hud_names'),('English_Polish_v12','font_uv')]:
 report=json.loads((R/folder/'build_report.json').read_text(encoding='utf8'))
 protected.update(int(p,16) for p in report[key]['reclaimed_words'])
edits={}; skipped=[]
for canonical,en in TEXT.items():
 assert original[canonical-1]==0 and canonical>=0x220000
 old=original[canonical:original.index(0,canonical)]; new=en.encode('cp932')
 assert len(new)<=len(old),(hex(canonical),len(new),len(old),en)
 assert re.findall(rb'\$[0-9]|%[sd]',re.sub(rb'%[-0-9]*',b'%',old))==re.findall(rb'\$[0-9]|%[sd]',re.sub(rb'%[-0-9]*',b'%',new))
 lines=re.split('[\u2193\n]',en);expanded=[re.sub(r'\$[0-9]','X'*12,line) for line in lines]
 assert len(lines)<=(6 if canonical<0x231900 else 3),(hex(canonical),expanded)
 assert not any('\u3040'<=c<='\u9fff' for c in en)
 positions={canonical}
 if False: # no broad duplicate matching for small-data/interface constants
  positions.update(m.start() for m in re.finditer(re.escape(old)+b'\0',original) if 0x22d420<=m.start()<0x27ab00 and original[m.start()-1]==0 and m.start()%4==0)
 for at in sorted(positions):
  if at in edits:
   assert edits[at]['english']==en
   continue
  assert before[at:before.index(0,at)].decode('cp932')==EXPECTED[at],hex(at)
  # Write only new visible bytes and terminator, preserving all remaining bytes.
  end=at+len(new)+1
  assert not any(at<p+4 and p<end for p in protected)
  assert not any(at<e['end'] and start<end for start,e in edits.items())
  dol[at:end]=new+b'\0'
  edits[at]=dict(offset=hex(at),end=end,canonical=hex(canonical),japanese=old.decode('cp932'),english=en,capacity_bytes=len(old),used_bytes=len(new),lines=len(lines),expanded_line_cells=max(map(len,expanded)))
 assert canonical in edits,(hex(canonical),'Canonical not applied')
assert all(before[p:p+4]==dol[p:p+4] for p in protected)
for i in range(7):
 off,n=[int.from_bytes(original[p+4*i:p+4*i+4],'big') for p in [0,0x90]]
 if n:assert before[off:off+n]==dol[off:off+n]==original[off:off+n]

allowed_dol=sorted((at,e['end']) for at,e in edits.items())
cursor=0
for lo,hi in allowed_dol:
 assert before[cursor:lo]==dol[cursor:lo];cursor=hi
assert before[cursor:]==dol[cursor:]
for at,e in edits.items():
 assert dol[at:dol.index(0,at)].decode('cp932')==e['english']
(OUT/'translated_scenes.txt').write_text('\n\n'.join(e['offset']+' '+e['japanese']+'\n'+e['english'].replace('\u2193','\n') for e in edits.values()),encoding='utf8')
print('Checks passed:',len(TEXT),'canonical strings;',len(edits),'occurrences; protected code exact.',flush=True)
if '--check' in sys.argv:sys.exit()
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
from qa_native_v47 import prepare
fst,art_blobs,art_reports=prepare(BASE,OUT)
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 f.seek(meta['fst_offset']);f.write(fst)
 for off,packed,_ in art_blobs:f.seek(off);f.write(packed)
 for at,e in edits.items():
  f.seek(meta['dol_offset']+at);f.write(dol[at:e['end']])
with TARGET.open('rb') as f:
 f.seek(meta['dol_offset']);assert f.read(len(dol))==dol
allowed=sorted([(meta['dol_offset']+lo,meta['dol_offset']+hi) for lo,hi in allowed_dol]+[(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(off,off+len(packed)) for off,packed,_ in art_blobs])
from qa_research_v10 import current_files
from decode_bpe import decode
f,got,fs=current_files(TARGET);assert got==fst
for row,(off,packed,decoded) in zip(art_reports,art_blobs):
 assert fs[row['path']][:2]==(off,len(packed));f.seek(off);assert f.read(len(packed))==packed and decode(packed)==decoded
f.close()
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   checked=0
   for lo,hi in allowed:
    if hi<=pos or lo>=pos+len(x):continue
    aa=max(0,lo-pos);bb=min(len(x),hi-pos)
    assert x[checked:aa]==y[checked:aa];checked=max(checked,bb)
   assert x[checked:]==y[checked:]
  pos+=len(x)
print('Whole disc verified: only recorded text/archive/FST ranges differ. Creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_QA_v47.bps',dict(game='Hikaru no Go 3',version='0.47',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.47',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,canonical_strings=len(TEXT),match_entries=len(MATCH),all_executable_text_sections_exact_original=True,new_string_occurrences=len(edits),edits=list(edits.values()),skipped=skipped,all_other_unrecorded_disc_bytes_exact_v46=True,protected_code_words_unchanged=len(protected),fonts_scripts_unchanged=True,whole_disc_differences_verified=True,patch=patch,collectible_packaging='Japanese retained with user approval',estimate_column_audit=True,graphics=art_reports,status='Title board overlay restored; only tit02 pixels and FST/archive placement change. All other v46 content preserved. Dolphin testing pending.')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('Built',TARGET,report['output_sha256'],flush=True)
