"""Build v51 native screenshot QA from v50; never modifies executable code."""
from pathlib import Path
import json,shutil
from patch_utils import sha
from bps_patch import make
from qa_native_v51 import prepare,PATHS
from qa_research_v10 import current_files
from decode_bpe import decode

R=Path(__file__).resolve().parent;W=R/'translation_work'
OUT=R/'English_QA_v51';OUT.mkdir(exist_ok=True)
BASE=R/'English_Dialogue_v50/Hikaru no Go 3 - English Dialogue v50.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso'
TARGET=OUT/'Hikaru no Go 3 - English QA v51.iso'
assert not TARGET.exists(),'Preserve an existing build; do not overwrite it.'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
meta=json.loads((W/'disc_metadata.json').read_text())
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
original=(W/'main.dol').read_bytes()
with BASE.open('rb') as f:f.seek(meta['dol_offset']);dol=f.read(len(original))
for i in range(7):
    o=int.from_bytes(original[i*4:i*4+4],'big');n=int.from_bytes(original[0x90+i*4:0x94+i*4],'big')
    if n:assert dol[o:o+n]==original[o:o+n]
fst,blobs,reports=prepare(BASE,OUT)
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
    f.seek(meta['fst_offset']);f.write(fst)
    for off,packed,_ in blobs.values():f.seek(off);f.write(packed)
with TARGET.open('rb') as f:f.seek(meta['dol_offset']);assert f.read(len(dol))==dol
f,got,files=current_files(TARGET);g,_,basefiles=current_files(BASE)
assert got==fst and files.keys()==basefiles.keys() and len(files)==719
for path,(off,size,_) in files.items():
    f.seek(off);current=f.read(size)
    if path in blobs:
        o,packed,decoded=blobs[path]
        assert (off,size)==(o,len(packed)) and current==packed and decode(current)==decoded
    else:
        o,n,_=basefiles[path];g.seek(o);assert current==g.read(n),path
f.close();g.close()
allowed=sorted([(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(o,o+len(p)) for o,p,_ in blobs.values()])
with BASE.open('rb') as a,TARGET.open('rb') as b:
    pos=0
    while True:
        x=a.read(1048576);y=b.read(1048576)
        if not x:assert not y;break
        assert len(x)==len(y)
        if x!=y:
            checked=0
            for lo,hi in allowed:
                if hi<=pos or lo>=pos+len(x):continue
                aa=max(0,lo-pos);bb=min(len(x),hi-pos)
                assert x[checked:aa]==y[checked:aa];checked=max(checked,bb)
            assert x[checked:]==y[checked:]
        pos+=len(x)
print('All719 resources/readback/whole-disc ranges verified; creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_QA_v51.bps',
           dict(game='Hikaru no Go 3',version='0.51',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report={'version':'0.51','source_sha256':prior['source_sha256'],
        'previous_sha256':prior['output_sha256'],'output_sha256':sha(TARGET),
        'original_and_previous_unchanged':True,'all_active_files_compared':len(files),
        'archives':reports,'all_other_active_files_exact_v50':True,
        'dol_exact_v50':True,'all_executable_text_sections_exact_original':True,
        'disabled_hooks_preserved':True,'all_scripts_and_gba_exact_v50':True,
        'title_and_board_overlay_exact_v50':True,'native_layout_dimensions_palette_counts_preserved':True,
        'decoded_archive_sizes_unchanged':True,'whole_disc_differences_verified':True,'patch':patch,
        'runtime_status':'Not tested in Dolphin: product policy blocks emulator inspection/control.',
        'changes':['Results captions moved clear of score rows.',
                   'Player headings centred at existing value anchors; header ink ends before value rows.',
                   'Connect/Capture/Fight/Best re-rendered with area-filtered coverage and black-alpha palette edges.',
                   'ASCII native font cell perimeters cleared: original glyph interiors, metrics, non-ASCII and control cells exact.'],
        'limits':['Player-name spacing unresolved; no saved data modified.',
                  'Name heading uses the screenshot four-character name centre; dynamic names vary in width.',
                  'Native resolution, palette limits and runtime filtering still affect edge appearance.',
                  'Exact live result alignment, font appearance and transitions need user Dolphin testing.']}
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'README.md').write_text('''# English QA v51

Built from final English Dialogue v50. Use this ISO for the new screenshot fixes.

- Moves Standard/Survival Matches captions above their score rows, and tidies Play Time/GBA captions.
- Centres Name, Skill, Rank, Games, Wins, Losses and Draws headings over existing value anchors, raising them within the header band. Name matches the four-character player shown in the supplied screenshots; other name lengths can differ.
- Rebuilds Connect/Capture/Fight/Best lettering with cleaner antialiasing and a black-alpha outer palette instead of transparent white around the black outline.
- Clears only ASCII font-cell white perimeter pixels to create native one-pixel gutters. Original glyph interiors and character advances remain exact, as do Japanese/control/yen glyphs. No font enlargement or runtime hook.

All native dimensions, texture formats, palette capacities and decoded archive sizes are unchanged. DOL/code/scripts/GBA/title art are exact v50. Original and previous builds are preserved; saves and normal Dolphin settings are untouched.

This build has passed static/readback/whole-disc/BPS reconstruction checks. It has not been run in Dolphin: computer-use product policy blocks the emulator. Cold boot the ISO using a normal memory-card save, and compare the supplied results, Equip Effects, problem-list and player-data screens. Also check room Management entry/return and Internet Cafe transitions because of their historical sensitivity to graphics changes.

No claim that every jagged edge or every runtime layout is eliminated. Player-name spacing remains unresolved. Translation coverage is inherited from v50, not newly certified complete.

comparison_0.png and comparison_1.png show decoded before/after resources. heading_layout_mockup.png is a native-anchor layout illustration, not an emulator screenshot.
''',encoding='utf8')
print('Built',TARGET,report['output_sha256'],flush=True)
