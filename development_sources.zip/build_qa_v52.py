"""Complete-cell outlined font insets and reviewed punctuation, from v51."""
from pathlib import Path
import json,shutil,csv
from qa_native_v52 import prepare as art_prepare
from prepare_text_v52 import prepare as text_prepare
from prepare_bubbles_v52 import prepare as bubble_prepare
from qa_research_v10 import current_files
from decode_bpe import decode as bpe_decode
from gba_lz_v34 import decode as gba_decode
from patch_utils import sha
from bps_patch import make

R=Path(__file__).resolve().parent;W=R/'translation_work/qa_v52'
OUT=R/'English_QA_v52';OUT.mkdir(exist_ok=True)
BASE=R/'English_QA_v51/Hikaru no Go 3 - English QA v51.iso'
SOURCE=R/'Hikaru no Go 3 (Japan).iso';TARGET=OUT/'Hikaru no Go 3 - English QA v52.iso'
assert not TARGET.exists(),'Never overwrite an existing candidate.'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
meta=json.loads((R/'translation_work/disc_metadata.json').read_text())
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
dol,writes,gba_blobs,changes=text_prepare(BASE)
dol,bubble_writes,bubble_changes=bubble_prepare(dol)
writes+=bubble_writes
fst,art_blobs,art_reports=art_prepare(BASE,OUT)
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
    f.seek(meta['fst_offset']);f.write(fst)
    for off,packed,_ in art_blobs.values():f.seek(off);f.write(packed)
    for off,packed,_ in gba_blobs.values():f.seek(off);f.write(packed)
    for off,raw,label in writes:f.seek(off);f.write(raw)
with TARGET.open('rb') as f:
    f.seek(meta['dol_offset']);assert f.read(len(dol))==dol
f,got,files=current_files(TARGET);g,_,previous=current_files(BASE)
assert got==fst and files.keys()==previous.keys() and len(files)==719
for path,(off,n,_) in files.items():
    f.seek(off);cur=f.read(n)
    if path in art_blobs:
        o,packed,decoded=art_blobs[path]
        assert (off,n)==(o,len(packed)) and cur==packed and bpe_decode(cur)==decoded
    elif path in gba_blobs:
        o,packed,decoded=gba_blobs[path]
        assert (off,n)==(o,len(packed)) and cur==packed and gba_decode(cur)==decoded
    else:
        o,size,_=previous[path];g.seek(o);assert cur==g.read(size),path
f.close();g.close()
allowed=sorted([(meta['fst_offset'],meta['fst_offset']+len(fst))]+
               [(o,o+len(packed)) for o,packed,_ in list(art_blobs.values())+list(gba_blobs.values())]+
               [(o,o+len(raw)) for o,raw,_ in writes])
with BASE.open('rb') as a,TARGET.open('rb') as b:
    pos=0
    while True:
        x=a.read(1048576);y=b.read(1048576)
        if not x:assert not y;break
        assert len(x)==len(y)
        if x!=y:
            checked=0
            for lo,hi in allowed:
                if hi<=pos or lo>=pos+len(x):continue
                aa=max(0,lo-pos);bb=min(len(x),hi-pos)
                assert x[checked:aa]==y[checked:aa];checked=max(checked,bb)
            assert x[checked:]==y[checked:]
        pos+=len(x)
print('Finished readback, all719 active files and whole-disc ranges pass; creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_QA_v52.bps',dict(game='Hikaru no Go 3',version='0.52',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.52',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],
            output_sha256=sha(TARGET),original_and_previous_unchanged=True,
            all_active_files_compared=719,graphics=art_reports,punctuation_changes=changes,
            punctuation_occurrences=len(changes),dol_write_operations=len(writes),gba_changed_segments=list(gba_blobs),
            battle_bubbles_checked=796,battle_bubble_changes=bubble_changes,
            battle_bubbles_reflowed=len(bubble_changes),battle_wording_shortened=sum(r['wording_shortened'] for r in bubble_changes),
            all_executable_text_sections_exact_original=True,removed_hooks_disabled=True,
            font_atlas_native_size_format_palette_and_descriptors_preserved=True,
            gamecube_scripts_exact_v51=True,all_other_graphics_and_title_exact_v51=True,
            gba_nontext_bytes_and_pointers_exact_v51=True,whole_disc_differences_verified=True,patch=patch,
            runtime='Dolphin appearance/stability pending; product policy blocks emulator automation.',
            limitations=['Known inventoried corpus audit, not exhaustive runtime branch certification.',
                         'Native original glyph content fitted from12x24 to10x22; glyph ink becomes slightly smaller, advances stay original.',
                         'Player-name spacing unresolved; saves/settings untouched.'])
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'punctuation_changes.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),encoding='utf8')
with (OUT/'punctuation_changes.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.writer(f);writer.writerow(['Area','Offset','Japanese','Before','After','Alignment bytes used'])
    for c in changes:writer.writerow([c['area'],c['offset'],c['japanese'],c['before'],c['after'],c['alignment_padding_used']])
lines=['# v52 punctuation changes','','All listed sentence endings were checked against the Japanese. Menu labels, names, headings, choice-button captions and continuing dialogue are retained.','', '| Location | Before | After |','|---|---|---|']
for c in changes:
    clean=lambda s:s.replace('|','\\|').replace('\u2193',' / ').replace('\n',' / ')
    lines.append(f"| {c['area']} {c['offset']} | {clean(c['before'])} | {clean(c['after'])} |")
(OUT/'punctuation_changes.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
(OUT/'battle_bubble_changes.json').write_text(json.dumps(bubble_changes,ensure_ascii=False,indent=2),encoding='utf8')
with (OUT/'battle_bubble_changes.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.writer(f);writer.writerow(['Offset','Japanese','Before','After','Wording shortened','Cells per line'])
    for c in bubble_changes:writer.writerow([c['offset'],c['japanese'],c['before'],c['after'],c['wording_shortened'],c['maximum_cells']])
lines=['# v52 battle-bubble wording changes','','All 796 inventoried battle reactions/commentary checked at 18 cells by three lines. 552 entries reflowed; the following 31 are condensed to fit.','', '| Offset | Before | After |','|---|---|---|']
for c in bubble_changes:
    if c['wording_shortened']:
        clean=lambda s:s.replace('|','\\|').replace('\u2193',' / ')
        lines.append(f"| {c['offset']} | {clean(c['before'])} | {clean(c['after'])} |")
(OUT/'battle_bubble_wording_changes.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
print('Built',TARGET,report['output_sha256'],flush=True)
