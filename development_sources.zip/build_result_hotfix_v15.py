"""Isolate the result hang: restore original result name calls, retain v14."""
from pathlib import Path
import json,struct,shutil
from name_display_v08 import branch
from patch_utils import sha
from bps_patch import make
R=Path(__file__).parent;W=R/'translation_work';OUT=R/'English_ResultHotfix_v15';OUT.mkdir(exist_ok=True)
BASE=R/'English_Problems_v14/Hikaru no Go 3 - English Problems v14.iso';SOURCE=R/'Hikaru no Go 3 (Japan).iso';TARGET=OUT/'Hikaru no Go 3 - English Result Hotfix v15.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));v13=json.loads((R/'English_Courses_v13/build_report.json').read_text(encoding='utf8'));v12=json.loads((R/'English_Polish_v12/build_report.json').read_text(encoding='utf8'));meta=json.loads((W/'disc_metadata.json').read_text());orig=(W/'main.dol').read_bytes()
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
with BASE.open('rb') as f:f.seek(meta['dol_offset']);before=f.read(len(orig))
with (R/'English_Polish_v12/Hikaru no Go 3 - English Polish v12.iso').open('rb') as f:f.seek(meta['dol_offset']);known=f.read(len(orig))
assert sha(R/'English_Polish_v12/Hikaru no Go 3 - English Polish v12.iso')==v12['output_sha256']
dol=bytearray(before);ranges=[];changes=[];name=v13['result_names']
for h in name['hooks']:
 ram=int(h,16);at=ram-0x80016580;old=branch(ram,0x800a25c0,True);injected=branch(ram,int(name['entry'],16),True)
 assert int.from_bytes(before[at:at+4],'big')==injected and int.from_bytes(orig[at:at+4],'big')==old and known[at:at+4]==orig[at:at+4]
 struct.pack_into('>I',dol,at,old);ranges.append((at,at+4));changes.append(dict(call=h,restored_target='0x800a25c0',matches_original_and_v12=True))
for h in name['reclaimed_words']:
 at=int(h,16);assert known[at:at+4]==bytes(4)
 dol[at:at+4]=known[at:at+4];ranges.append((at,at+4))
assert len(changes)==8
assert all(a==b or any(lo<=i<hi for lo,hi in ranges) for i,(a,b) in enumerate(zip(before,dol)))
# Prior working HUD and font hooks are untouched; only v13 result hook words
# and their now-unreachable helper are rolled back.
for p,key in [('English_Interface_v08/build_report.json','name_display'),('English_Content_v11/build_report.json','hud_names'),('English_Polish_v12/build_report.json','font_uv')]:
 j=json.loads((R/p).read_text(encoding='utf8'))[key]
 assert all(dol[int(a,16):int(a,16)+4]==before[int(a,16):int(a,16)+4] for a in j['reclaimed_words'])
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:f.seek(meta['dol_offset']);f.write(dol)
allowed=sorted((meta['dol_offset']+lo,meta['dol_offset']+hi) for lo,hi in ranges)
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   checked=0
   for lo,hi in allowed:
    if hi<=pos or lo>=pos+len(x):continue
    aa=max(0,lo-pos);bb=min(len(x),hi-pos)
    if aa>checked:assert x[checked:aa]==y[checked:aa]
    checked=max(checked,bb)
   assert x[checked:]==y[checked:]
  pos+=len(x)
print('Verified isolated result-hook rollback; all archives, scripts, FST and other code exact v14.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_ResultHotfix_v15.bps',dict(game='Hikaru no Go 3',version='0.15',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.15',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],output_sha256=sha(TARGET),restored_calls=changes,removed_helper_words=len(name['reclaimed_words']),all_other_iso_bytes_exact_v14=True,original_and_previous_unchanged=True,patch=patch,status='Result hang isolation: v13 result-name hooks removed; Dolphin result transition test required; root cause not confirmed')
(OUT/'build_report.json').write_text(json.dumps(report,indent=2),encoding='utf8');print('Built',TARGET,report['output_sha256'],flush=True)
