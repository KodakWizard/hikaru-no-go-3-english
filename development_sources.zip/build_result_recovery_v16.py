"""Restore pre-v13 executable/menu/font while preserving translated scripts."""
from pathlib import Path
import json,struct,shutil
from qa_research_v10 import current_files
from patch_utils import sha
from bps_patch import make
R=Path(__file__).parent;W=R/'translation_work';OUT=R/'English_ResultRecovery_v16';OUT.mkdir(exist_ok=True)
BASE=R/'English_ResultHotfix_v15/Hikaru no Go 3 - English Result Hotfix v15.iso';REF=R/'English_Polish_v12/Hikaru no Go 3 - English Polish v12.iso';SOURCE=R/'Hikaru no Go 3 (Japan).iso';TARGET=OUT/'Hikaru no Go 3 - English Result Recovery v16.iso'
prior=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));ref_report=json.loads((REF.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((W/'disc_metadata.json').read_text());n=len((W/'main.dol').read_bytes())
assert sha(BASE)==prior['output_sha256'] and sha(REF)==ref_report['output_sha256'] and sha(SOURCE)==prior['source_sha256']
f,fst,files=current_files(BASE);rf,_,refs=current_files(REF);rf.seek(meta['dol_offset']);dol=rf.read(n);changes={};blobs={}
for path in ['2D/win.bpe','font24/hggc24.bpe']:
 ro,rs,_=refs[path];o,s,idx=files[path];assert rs<=s
 rf.seek(ro);data=rf.read(rs);assert len(data)==rs;blobs[path]=(o,data)
 struct.pack_into('>II',fst,idx*12+4,o,rs);changes[path]=dict(reference_offset=ro,reference_bytes=rs,output_offset=o,previous_bytes=s,sha256=__import__('hashlib').sha256(data).hexdigest())
f.close();rf.close();shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 f.seek(meta['dol_offset']);f.write(dol);f.seek(meta['fst_offset']);f.write(fst)
 for o,data in blobs.values():f.seek(o);f.write(data)
with TARGET.open('rb') as f:
 f.seek(meta['dol_offset']);assert f.read(n)==dol;f.seek(meta['fst_offset']);assert f.read(len(fst))==fst
 for o,data in blobs.values():f.seek(o);assert f.read(len(data))==data
allowed=sorted([(meta['dol_offset'],meta['dol_offset']+n),(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(o,o+len(b)) for o,b in blobs.values()])
with BASE.open('rb') as a,TARGET.open('rb') as b:
 pos=0
 while True:
  x=a.read(1048576);y=b.read(1048576)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   checked=0
   for lo,hi in allowed:
    if hi<=pos or lo>=pos+len(x):continue
    aa=max(0,lo-pos);bb=min(len(x),hi-pos)
    if aa>checked:assert x[checked:aa]==y[checked:aa]
    checked=max(checked,bb)
   assert x[checked:]==y[checked:]
  pos+=len(x)
# FST inventory equality and content verification independently prove that
# every active script remains exactly the v15 version at the same location.
tf,_,tfst=current_files(TARGET);bf,_,bfst=current_files(BASE);script_count=0
for path,(o,s,idx) in bfst.items():
 if not path.startswith('script/'):continue
 assert tfst[path]==(o,s,idx);tf.seek(o);bf.seek(o);assert tf.read(s)==bf.read(s);script_count+=1
tf.close();bf.close()
print('Verified v12 executable/menu/font; all',script_count,'active script files exact v15. Creating cumulative BPS.',flush=True)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_ResultRecovery_v16.bps',dict(game='Hikaru no Go 3',version='0.16',base='original Japanese GHTJA4'))
assert sha(BASE)==prior['output_sha256'] and sha(REF)==ref_report['output_sha256'] and sha(SOURCE)==prior['source_sha256']
report=dict(version='0.16',source_sha256=prior['source_sha256'],previous_sha256=prior['output_sha256'],reference_sha256=ref_report['output_sha256'],output_sha256=sha(TARGET),restored_executable_exact_v12=True,restored_archives=changes,scripts_exact_v15=script_count,whole_disc_difference_check=True,original_previous_reference_unchanged=True,patch=patch,status='Recovery baseline after v15 failed to cure result hang; actual Dolphin transition test required; root cause unconfirmed')
(OUT/'build_report.json').write_text(json.dumps(report,indent=2),encoding='utf8');print('Built',TARGET,report['output_sha256'],flush=True)
