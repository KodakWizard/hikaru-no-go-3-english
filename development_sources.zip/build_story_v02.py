"""Build Story room translation and validate its storage and layout budgets."""
from pathlib import Path
import json,struct,hashlib,shutil,math
from PIL import Image,ImageDraw,ImageFont
from textures import resources,texture
from decode_bpe import decode
from story_translation import ROOM_LABELS,DIALOGUE

ROOT=Path(__file__).resolve().parent;WORK=ROOT/'translation_work'
RELEASE=ROOT/'English_Story_v02';RELEASE.mkdir(exist_ok=True)
BASE=ROOT/'English_Menu_POC/Hikaru no Go 3 - English Menu POC.iso'
SOURCE=ROOT/'Hikaru no Go 3 (Japan).iso';TARGET=RELEASE/'Hikaru no Go 3 - English Story v02.iso'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
 return h.hexdigest()
baseline=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
assert sha(BASE)==baseline['output_sha256'],'POC changed: inspect before rebuilding'
assert sha(SOURCE)==baseline['source_sha256'],'Original ISO does not match'
meta=json.loads((WORK/'disc_metadata.json').read_text())
original=(WORK/'main.dol').read_bytes()
with BASE.open('rb') as f:
 f.seek(meta['dol_offset']);dol=bytearray(f.read(len(original)))
 f.seek(meta['fst_offset']);fst=bytearray(f.read(meta['fst_size']))
dialogue=[]
for offset,en in DIALOGUE.items():
 end=original.index(0,offset);old=original[offset:end];jp=old.decode('cp932');new=en.encode('cp932')
 assert dol[offset:end]==old,(hex(offset),'unexpected data')
 assert len(new)<=len(old),(hex(offset),len(new),len(old),en)
 lines=en.split('↓')
 assert len(lines)<=3 and max(map(len,lines))<=26,(hex(offset),'line budget',en)
 # Conservative cross-check: allow a full 24px cell for each Latin character;
 # reflow original Japanese at a 16-cell line limit and compare total area.
 dol[offset:end+1]=new+b'\0'*(len(old)+1-len(new))
 dialogue.append(dict(offset=hex(offset),japanese=jp,english=en,capacity_bytes=len(old),used_bytes=len(new),lines=len(lines),longest_line_chars=max(map(len,lines)),width_status='26 ASCII characters maximum; exact on-screen scale requires Dolphin check'))

archive=bytearray((WORK/'decoded/2D/roo.bin').read_bytes());before=bytes(archive);labels=[];previews=[]
for name,o in resources(archive):
 if name not in ROOM_LABELS:continue
 jp,en=ROOM_LABELS[name];im,(fmt,w,h,start)=texture(archive,o);assert fmt in (8,9)
 fill=im.getpixel((0,0));newim=Image.new('RGBA',(w,h),fill);dr=ImageDraw.Draw(newim)
 size=min(22,h-6)
 while size>=14:
  font=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',size)
  box=dr.textbbox((0,0),en,font=font)
  if box[2]-box[0]<=w-10 and box[3]-box[1]<=h-6:break
  size-=1
 assert size>=14,(name,'text too long',en,w,h)
 x=(w-(box[2]-box[0]))//2-box[0];y=(h-(box[3]-box[1]))//2-box[1]
 dr.text((x,y),en,font=font,fill=(0,0,0,255))
 pf,n=struct.unpack_from('>HH',archive,o+44);palette=[]
 for j in range(n):
  v=int.from_bytes(archive[o+64+j*2:o+66+j*2],'big')
  if pf==0:c=(v&255,v&255,v&255,v>>8)
  elif pf==1:c=(((v>>11)&31)*255//31,((v>>5)&63)*255//63,(v&31)*255//31,255)
  else:c=(((v>>10)&31)*255//31,((v>>5)&31)*255//31,(v&31)*255//31,255) if v&32768 else (((v>>8)&15)*17,((v>>4)&15)*17,(v&15)*17,((v>>12)&7)*255//7)
  palette.append(c)
 if fmt==8:palette=palette[:16]
 cache={}
 def nearest(c):
  if c not in cache:cache[c]=min(range(len(palette)),key=lambda j:sum((c[k]-palette[j][k])**2 for k in range(4)))
  return cache[c]
 pix=list(newim.getdata());bw,bh=(8,8) if fmt==8 else (8,4);packed=bytearray()
 for ty in range(0,h,bh):
  for tx in range(0,w,bw):
   vals=[nearest(pix[(ty+yy)*w+tx+xx]) if ty+yy<h and tx+xx<w else 0 for yy in range(bh) for xx in range(bw)]
   packed.extend(((vals[i]<<4)|vals[i+1] for i in range(0,len(vals),2)) if fmt==8 else vals)
 archive[start:start+len(packed)]=packed
 after,desc=texture(archive,o);assert after.size==im.size
 assert len(archive)==len(before)
 (RELEASE/'label_previews').mkdir(exist_ok=True);after.save(RELEASE/'label_previews'/(name+'.png'))
 labels.append(dict(asset=name,japanese=jp,english=en,width=w,height=h,font_px=size,text_width=box[2]-box[0],text_height=box[3]-box[1],horizontal_margin=(w-(box[2]-box[0]))//2))
 previews.append((name,im,after))
assert len(labels)==len(ROOM_LABELS)
blob=len(archive).to_bytes(4,'big')+bytes([254,127,254,255])+len(archive).to_bytes(4,'big')+archive
assert decode(blob)==archive
placement=(baseline['title_archive_offset']+baseline['title_archive_size']+0x7fff)&~0x7fff
entries=json.loads((WORK/'inventory.json').read_text(encoding='utf8'))
assert all(placement+len(blob)<=e['offset'] or placement>=e['offset']+e['size'] for e in entries)
count=int.from_bytes(fst[8:12],'big');names=fst[count*12:];stack=[('',count)];found=False
for i in range(1,count):
 while i>=stack[-1][1]:stack.pop()
 word,off,size=struct.unpack_from('>III',fst,i*12);name=names[word&0xffffff:].split(b'\0')[0].decode('cp932');path=stack[-1][0]+name
 if word>>24:stack.append((path+'/',size))
 elif path=='2D/roo.bpe':struct.pack_into('>II',fst,i*12+4,placement,len(blob));found=True
assert found
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 f.seek(meta['dol_offset']);f.write(dol)
 f.seek(meta['fst_offset']);f.write(fst)
 f.seek(placement);f.write(blob)
with TARGET.open('rb') as f:
 f.seek(placement);assert decode(f.read(len(blob)))==archive
 f.seek(meta['dol_offset']);assert f.read(len(dol))==dol
 f.seek(meta['fst_offset']);assert f.read(len(fst))==fst
assert TARGET.stat().st_size==SOURCE.stat().st_size

# Validate all differences, create a cumulative IPS for the ORIGINAL ISO.
allowed=[(meta['dol_offset'],meta['dol_offset']+len(dol)),(meta['fst_offset'],meta['fst_offset']+len(fst)),(baseline['title_archive_offset'],baseline['title_archive_offset']+baseline['title_archive_size']),(placement,placement+len(blob))]
patch=bytearray(b'PATCH');changed=0
with SOURCE.open('rb') as f,TARGET.open('rb') as g:
 pos=0
 while True:
  a=f.read(1024*1024);b=g.read(1024*1024)
  if not a:assert not b;break
  assert len(a)==len(b)
  if a!=b:
   i=0
   while i<len(a):
    if a[i]==b[i]:i+=1;continue
    s=i;i+=1
    while i<len(a) and a[i]!=b[i] and i-s<65535:i+=1
    at=pos+s;assert at<0x1000000 and at!=0x454f46
    assert any(lo<=at and pos+i<=hi for lo,hi in allowed)
    patch.extend(at.to_bytes(3,'big')+(i-s).to_bytes(2,'big')+b[s:i]);changed+=i-s
  pos+=len(a)
patch.extend(b'EOF');(RELEASE/'Hikaru_no_Go_3_English_Story_v02.ips').write_bytes(patch)
assert sha(SOURCE)==baseline['source_sha256']
report=dict(version='0.2',source_sha256=baseline['source_sha256'],output_sha256=sha(TARGET),original_unchanged=True,previous_poc_preserved=True,room_archive_offset=placement,room_archive_bytes=len(blob),new_graphic_labels=len(labels),new_dialogue_strings=len(dialogue),inherited_poc_strings=len(baseline['text_changes']),changed_bytes=changed,all_iso_differences_verified=True,asset_fit_checks='All labels fit original dimensions with margins; no resized textures',dialogue_fit_checks='All storage budgets passed; at most 3 lines of 26 ASCII characters. Runtime box dimensions not yet measured.',runtime_status='User verified v0.1; v0.2 still requires Dolphin test',labels=labels,dialogue=dialogue)
(RELEASE/'build_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf8')
for page in range(math.ceil(len(previews)/12)):
 items=previews[page*12:(page+1)*12];sheet=Image.new('RGB',(560,80*len(items)),'#304050');dr=ImageDraw.Draw(sheet)
 for i,(name,im,after) in enumerate(items):
  dr.text((5,i*80+2),name,fill='white');sheet.paste(im,(5,i*80+26),im);sheet.paste(after,(290,i*80+26),after)
 sheet.save(RELEASE/f'labels_comparison_{page+1}.png')
print('Built',TARGET,'labels',len(labels),'dialogue',len(dialogue))
