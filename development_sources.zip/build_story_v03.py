"""Cumulative v0.3 Story patch; preserves both original and earlier test images."""
from pathlib import Path
import json,hashlib,shutil,re
from story_scenes_v03 import SCENES

ROOT=Path(__file__).resolve().parent;WORK=ROOT/'translation_work'
OUT=ROOT/'English_Story_v03';OUT.mkdir(exist_ok=True)
SOURCE=ROOT/'Hikaru no Go 3 (Japan).iso'
BASE=ROOT/'English_Story_v02/Hikaru no Go 3 - English Story v02.iso'
TARGET=OUT/'Hikaru no Go 3 - English Story v03.iso'
meta=json.loads((WORK/'disc_metadata.json').read_text())
previous=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'))
poc=json.loads((ROOT/'English_Menu_POC/build_report.json').read_text(encoding='utf8'))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
assert sha(SOURCE)==previous['source_sha256']
assert sha(BASE)==previous['output_sha256']
original=(WORK/'main.dol').read_bytes()
with BASE.open('rb') as f:
 f.seek(meta['dol_offset']);dol=bytearray(f.read(len(original)))
edits={};skipped=[]
for canonical,en in SCENES.items():
 old=original[canonical:original.index(0,canonical)];new=en.encode('cp932')
 assert len(new)<=len(old),(hex(canonical),'byte budget')
 assert sorted(re.findall(rb'\$[0-9]',old))==sorted(re.findall(rb'\$[0-9]',new))
 lines=en.split('↓');expanded=[re.sub(r'\$[12]','X'*12,line) for line in lines]
 assert len(lines)<=3 and max(map(len,expanded))<=26,(hex(canonical),'layout budget')
 positions=[canonical]
 # Long exact duplicate strings share the same translation. Avoid global
 # substitutions for tiny generic interjections and retain previous English.
 if len(old)>=14 and len(set(old))>=4:
  positions=sorted({canonical}|{m.start() for m in re.finditer(re.escape(old)+b'\0',original) if 0x22d420<=m.start()<0x27ab00 and original[m.start()-1] in (0,0xcd)})
 for offset in positions:
  if dol[offset:offset+len(old)]!=old:
   if offset in edits:
    assert edits[offset]['english']==en
   else:skipped.append(dict(offset=hex(offset),reason='already translated in prior build'))
   continue
  assert not any(offset<e['end'] and offset+len(old)+1>o for o,e in edits.items()),'overlapping replacements'
  dol[offset:offset+len(old)+1]=new+b'\0'*(len(old)+1-len(new))
  edits[offset]=dict(end=offset+len(old)+1,canonical=hex(canonical),offset=hex(offset),japanese=old.decode('cp932'),english=en,capacity_bytes=len(old),used_bytes=len(new),lines=len(lines),longest_expanded_line=max(map(len,expanded)),name_reserve_ascii_cells=12)
 assert canonical in edits,(hex(canonical),'canonical was not applied')
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:f.seek(meta['dol_offset']);f.write(dol)
with TARGET.open('rb') as f:f.seek(meta['dol_offset']);assert f.read(len(dol))==dol

# Standard cumulative IPS and whole-disc comparison with permitted ranges.
allowed=[(meta['dol_offset'],meta['dol_offset']+len(dol)),(meta['fst_offset'],meta['fst_offset']+meta['fst_size']),(poc['title_archive_offset'],poc['title_archive_offset']+poc['title_archive_size']),(previous['room_archive_offset'],previous['room_archive_offset']+previous['room_archive_bytes'])]
patch=bytearray(b'PATCH');changed=0
with SOURCE.open('rb') as f,TARGET.open('rb') as g,BASE.open('rb') as base:
 pos=0
 while True:
  a=f.read(1024*1024);b=g.read(1024*1024);c=base.read(1024*1024)
  if not a:assert not b and not c;break
  assert len(a)==len(b)==len(c)
  # New version must differ from v0.2 only in the DOL.
  if b!=c:
   for i,(v,w) in enumerate(zip(b,c)):
    if v!=w:assert meta['dol_offset']<=pos+i<meta['dol_offset']+len(dol)
  if a!=b:
   i=0
   while i<len(a):
    if a[i]==b[i]:i+=1;continue
    s=i;i+=1
    while i<len(a) and a[i]!=b[i] and i-s<65535:i+=1
    at=pos+s;assert at<0x1000000 and at!=0x454f46
    assert any(lo<=at and pos+i<=hi for lo,hi in allowed)
    patch.extend(at.to_bytes(3,'big')+(i-s).to_bytes(2,'big')+b[s:i]);changed+=i-s
  pos+=len(a)
patch.extend(b'EOF');(OUT/'Hikaru_no_Go_3_English_Story_v03.ips').write_bytes(patch)
target_sha=sha(TARGET)
# Independently reconstruct target hash from original plus IPS records.
ops=[];i=5
while patch[i:i+3]!=b'EOF':
 o=int.from_bytes(patch[i:i+3],'big');n=int.from_bytes(patch[i+3:i+5],'big');assert n
 ops.append((o,patch[i+5:i+5+n]));i+=5+n
h=hashlib.sha256();ix=0;pos=0
with SOURCE.open('rb') as f:
 while True:
  b=bytearray(f.read(1024*1024))
  if not b:break
  end=pos+len(b)
  while ix<len(ops) and ops[ix][0]<end:
   o,data=ops[ix];lo=max(pos,o);hi=min(end,o+len(data));b[lo-pos:hi-pos]=data[lo-o:hi-o]
   if o+len(data)<=end:ix+=1
   else:break
  h.update(b);pos=end
assert h.hexdigest()==target_sha
assert sha(SOURCE)==previous['source_sha256'] and sha(BASE)==previous['output_sha256']
report=dict(version='0.3',source_sha256=previous['source_sha256'],output_sha256=target_sha,previous_version_sha256=previous['output_sha256'],original_and_prior_build_unchanged=True,canonical_scene_strings=len(SCENES),new_string_occurrences=len(edits),cumulative_string_occurrences=len(edits)+previous['new_dialogue_strings']+previous['inherited_poc_strings'],inherited_graphic_labels=35,ips_reconstructs_target_hash=True,whole_disc_diff_verified=True,only_dol_changed_from_v02=True,layout='Unchanged alignment; <=3 lines, <=26 ASCII cells per line with a provisional 12-cell name reserve. Player name maximum has not been established.',runtime_status='v0.2 room screenshot confirmed rendering; v0.3 new scenes require Dolphin testing',edits=list(edits.values()),skipped_existing=skipped)
(OUT/'build_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf8')
(OUT/'translated_scenes.txt').write_text('\n\n'.join(e['offset']+' '+e['japanese']+'\n'+e['english'].replace('↓','\n') for e in edits.values()),encoding='utf8')
print('Built',TARGET,'canonical strings',len(SCENES),'new occurrences',len(edits),'cumulative',report['cumulative_string_occurrences'])
