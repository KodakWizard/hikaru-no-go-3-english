"""Title-only art revision; all v0.8 translation and executable bytes retained."""
from pathlib import Path
import json,struct,shutil
from PIL import Image
from textures import resources,texture
from archive_edit import rgba_resource,rebuild_archive
from decode_bpe import decode
from patch_utils import sha
from bps_patch import make

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'English_Title_v081';WORK=ROOT/'translation_work'
BASE=ROOT/'English_Interface_v08/Hikaru no Go 3 - English Interface v08.iso';SOURCE=ROOT/'Hikaru no Go 3 (Japan).iso';TARGET=OUT/'Hikaru no Go 3 - English Title v081.iso'
previous=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((WORK/'disc_metadata.json').read_text())
assert sha(BASE)==previous['output_sha256'] and sha(SOURCE)==previous['source_sha256']
def read_archive(iso,path):
 with iso.open('rb') as f:
  f.seek(meta['fst_offset']);fst=bytearray(f.read(meta['fst_size']));count=int.from_bytes(fst[8:12],'big');names=fst[count*12:];stack=[('',count)]
  for i in range(1,count):
   while i>=stack[-1][1]:stack.pop()
   word,off,size=struct.unpack_from('>III',fst,i*12);name=names[word&0xffffff:].split(b'\0')[0].decode('cp932');p=stack[-1][0]+name
   if word>>24:stack.append((p+'/',size))
   elif p==path:
    f.seek(off);return decode(f.read(size)),off,size,fst,i
 raise KeyError(path)
active,off,oldsize,fst,index=read_archive(BASE,'title/title.bpe');lookup=dict(resources(active))
# Rebuild from the pre-v0.8 archive to avoid accumulating unused title images.
seed,*_=read_archive(ROOT/'English_Course_v07/Hikaru no Go 3 - English Course v07.iso','title/title.bpe');seed_lookup=dict(resources(seed))
replacements={};checks=[];bounds=(0,50,390,235)
for name,asset in [('tit00.D4','title_intro_generated.png'),('tit02.D4','title_menu_generated.png')]:
 before,_=texture(active,lookup[name]);incoming=Image.open(OUT/'assets'/asset).convert('RGBA')
 assert abs(incoming.width/incoming.height-4/3)<0.01
 native=incoming.resize(before.size,Image.Resampling.LANCZOS)
 # Asset integration: constrain the generated edit to the original logo area.
 # Keep v0.8's translated credits, face, fan and all other pixels exactly.
 after=before.copy();after.paste(native.crop(bounds),bounds[:2])
 for box in [(0,0,640,50),(0,235,640,480),(390,50,640,235)]:assert after.crop(box).tobytes()==before.crop(box).tobytes()
 after.save(OUT/(name+'_english.png'));replacements[name]=rgba_resource(seed,seed_lookup[name],after)
 assert texture(replacements[name],0)[0].tobytes()==after.tobytes()
 checks.append(dict(asset=name,native_dimensions=list(after.size),format='RGBA8',edited_bounds=list(bounds),all_pixels_outside_logo_bounds_identical_to_v08=True,decoded_pixels_exact=True))
for name,o in seed_lookup.items():
 if name in replacements:continue
 n=int.from_bytes(seed[o:o+4],'big')+32;a=lookup[name]
 assert seed[o:o+n]==active[a:a+n],name
new=rebuild_archive(seed,replacements);blob=len(new).to_bytes(4,'big')+bytes([254,127,254,255])+len(new).to_bytes(4,'big')+new
assert decode(blob)==new and len(blob)==oldsize,(len(blob),oldsize)
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:f.seek(off);f.write(blob)
with TARGET.open('rb') as f:
 f.seek(off);assert decode(f.read(len(blob)))==new
with BASE.open('rb') as f,TARGET.open('rb') as g:
 pos=0
 while True:
  a=f.read(1024*1024);b=g.read(1024*1024)
  if not a:assert not b;break
  assert len(a)==len(b)
  if a!=b:
   lo=max(0,off-pos);hi=min(len(a),off+len(blob)-pos)
   assert 0<=lo<=hi<=len(a) and a[:lo]==b[:lo] and a[hi:]==b[hi:]
  pos+=len(a)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Title_v081.bps',dict(game='Hikaru no Go 3',version='0.8.1',base='original Japanese GHTJA4'))
assert sha(BASE)==previous['output_sha256'] and sha(SOURCE)==previous['source_sha256']
report=dict(version='0.8.1',source_sha256=previous['source_sha256'],previous_sha256=previous['output_sha256'],output_sha256=sha(TARGET),original_and_previous_unchanged=True,title_only_changes_verified=True,executable_and_fst_identical_to_v08=True,archive_size_unchanged=True,relocated_files={'title/title.bpe':dict(offset=off,size=len(blob))},graphic_checks=checks,patch=patch,artwork_tool='Built-in image_gen',runtime_status='Dolphin visual test pending; full-game translation still in progress')
(OUT/'build_report.json').write_text(json.dumps(report,indent=2),encoding='utf8');print('Built',TARGET,'SHA256',report['output_sha256'],'BPS bytes',patch['bytes'],flush=True)
