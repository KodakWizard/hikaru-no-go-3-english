"""Cumulative screenshot fixes, smooth battle navigation and English title art."""
from pathlib import Path
import json,struct,shutil,re,math
from PIL import Image,ImageDraw
from textures import resources,texture
from decode_bpe import decode
from smooth_art import render_label
from archive_edit import rgba_resource,rebuild_archive
from ui_translation_v08 import LABELS,TEXT,MATCH_CUES
from title_art_v08 import english_title
from name_display_v08 import patch as patch_names
from patch_utils import sha
from bps_patch import make

ROOT=Path(__file__).resolve().parent;WORK=ROOT/'translation_work';OUT=ROOT/'English_Interface_v08';OUT.mkdir(exist_ok=True)
SOURCE=ROOT/'Hikaru no Go 3 (Japan).iso';BASE=ROOT/'English_Course_v07/Hikaru no Go 3 - English Course v07.iso';TARGET=OUT/'Hikaru no Go 3 - English Interface v08.iso'
previous=json.loads((BASE.parent/'build_report.json').read_text(encoding='utf8'));meta=json.loads((WORK/'disc_metadata.json').read_text())
assert sha(SOURCE)==previous['source_sha256'] and sha(BASE)==previous['output_sha256']
original=(WORK/'main.dol').read_bytes()
with BASE.open('rb') as f:
 f.seek(meta['dol_offset']);dol=bytearray(f.read(len(original)))
 f.seek(meta['fst_offset']);fst=bytearray(f.read(meta['fst_size']))
 count=int.from_bytes(fst[8:12],'big');names=fst[count*12:];stack=[('',count)];files={}
 for i in range(1,count):
  while i>=stack[-1][1]:stack.pop()
  word,off,size=struct.unpack_from('>III',fst,i*12);name=names[word&0xffffff:].split(b'\0')[0].decode('cp932');path=stack[-1][0]+name
  if word>>24:stack.append((path+'/',size))
  else:files[path]=(off,size,i)
edits=[]
def replace(at,en):
 old=original[at:original.index(0,at)];new=en.encode('cp932');assert len(new)<=len(old),(hex(at),en,len(new),len(old))
 assert dol[at:at+len(old)]==old,(hex(at),'already changed')
 dol[at:at+len(old)+1]=new+bytes(len(old)+1-len(new));edits.append(dict(offset=hex(at),japanese=old.decode('cp932'),english=en,capacity=len(old),used=len(new)))
for at,en in TEXT.items():replace(at,en)
for jp,en in MATCH_CUES.items():
 old=jp.encode('cp932');start=0x258000
 while True:
  at=original.find(old+b'\0',start,0x260000)
  if at<0:break
  start=at+len(old)+1
  if original[at-1] not in (0,0xcd) or dol[at:at+len(old)]!=old:continue
  replace(at,en)
name_check=patch_names(dol,original)
with BASE.open('rb') as f:
 f.seek(meta['dol_offset']);old_dol=f.read(len(dol))
dol_ranges=[(int(e['offset'],16),int(e['offset'],16)+e['capacity']+1) for e in edits]
dol_ranges += [(int(x,16),int(x,16)+4) for x in name_check['reclaimed_words']]
dol_ranges += [(int(x,16)-0x80018ba0+0x2620,int(x,16)-0x80018ba0+0x2620+4) for x in name_check['hooks']]
for i,(a,b) in enumerate(zip(old_dol,dol)):
 if a!=b:assert any(lo<=i<hi for lo,hi in dol_ranges),hex(i)
blobs={};checks=[];previews=[]
with BASE.open('rb') as f:
 for src,mapping in LABELS.items():
  path=src+'.bpe';off,size,_=files[path];f.seek(off);b=decode(f.read(size));lookup=dict(resources(b));replacements={}
  for name,en in mapping.items():
   o=lookup[name];im,_=texture(b,o);room=name.startswith('roo')
   art,budget=render_label(im,en,max_size=18 if 'mba' in src else min(22,im.height-6),margin=3,text_colour=(0,0,0,255) if room else None,outline_width=0 if room else None)
   replacements[name]=rgba_resource(b,o,art);checks.append(dict(archive=src,asset=name,english=en,**budget));previews.append((name,art))
  if src=='2D/bbg':
   for name in ['bbg01_0_1.D4','bbg01_1_1.D4']:
    o=lookup[name];im,_=texture(b,o);art=im.copy();x=0 if '_0_1' in name else 44
    # Retain the grey counter bar, stone-shaped counter and all lower pixels.
    art.paste((0,0,0,0),(x,0,x+78,26))
    label,_=render_label(Image.new('RGBA',(78,24)), 'Captures',max_size=13,margin=1,title=True,text_colour=(255,255,255,255))
    art.alpha_composite(label,(x,1));replacements[name]=rgba_resource(b,o,art);checks.append(dict(archive=src,asset=name,english='Captures',composite_preserved=True));previews.append((name,art))
   name='bbg12.D4';o=lookup[name];im,_=texture(b,o);art=Image.new('RGBA',im.size)
   for i in range(21):
    x=i%4*64;y=i//4*32;cell=Image.new('RGBA',(64,32));dr=ImageDraw.Draw(cell);dr.rounded_rectangle((4,2,59,27),radius=12,fill=(90,90,90,255))
    label,_=render_label(Image.new('RGBA',(54,25)),f'{(i+1)/2:g}',max_size=21,margin=1,title=True,text_colour=(255,255,255,255));cell.alpha_composite(label,(5,2));art.alpha_composite(cell,(x,y))
   replacements[name]=rgba_resource(b,o,art);checks.append(dict(archive=src,asset=name,english='Komi values 0.5 through 10.5',atlas_cells=21));previews.append((name,art))
  new=rebuild_archive(b,replacements);blob=len(new).to_bytes(4,'big')+bytes([254,127,254,255])+len(new).to_bytes(4,'big')+new
  assert decode(blob)==new;blobs[path]=(blob,new)
 # Preserve the English notice and four approved title buttons in the active archive.
 path='title/title.bpe';off,size,_=files[path];f.seek(off);b=decode(f.read(size));lookup=dict(resources(b));replacements={}
 for name in ['tit00.D4','tit02.D4']:
  o=lookup[name];im,_=texture(b,o);art=english_title(im);art.save(OUT/(name+'_english.png'));replacements[name]=rgba_resource(b,o,art);checks.append(dict(archive='title/title',asset=name,english='HIKARU NO GO 3 and copyright credits',rgba_exact=True))
 new=rebuild_archive(b,replacements);blob=len(new).to_bytes(4,'big')+bytes([254,127,254,255])+len(new).to_bytes(4,'big')+new;assert decode(blob)==new;blobs[path]=(blob,new)
orig_entries=json.loads((WORK/'inventory.json').read_text(encoding='utf8'))
placement=(max(off+size for off,size,i in files.values() if off<1085734912)+0x7fff)&~0x7fff;relocated={}
for path,(blob,new) in blobs.items():
 assert placement+len(blob)<1085734912
 assert all(placement+len(blob)<=e['offset'] or placement>=e['offset']+e['size'] for e in orig_entries)
 assert all(placement+len(blob)<=o or placement>=o+n for o,n,_ in files.values())
 relocated[path]=dict(offset=placement,size=len(blob));struct.pack_into('>II',fst,files[path][2]*12+4,placement,len(blob));placement=(placement+len(blob)+0x7fff)&~0x7fff
shutil.copyfile(BASE,TARGET)
with TARGET.open('r+b') as f:
 f.seek(meta['fst_offset']);f.write(fst);f.seek(meta['dol_offset']);f.write(dol)
 for path,(blob,new) in blobs.items():f.seek(relocated[path]['offset']);f.write(blob)
with TARGET.open('rb') as f:
 f.seek(meta['dol_offset']);assert f.read(len(dol))==dol
 f.seek(meta['fst_offset']);assert f.read(len(fst))==fst
 for path,(blob,new) in blobs.items():f.seek(relocated[path]['offset']);assert decode(f.read(len(blob)))==new
# Compare against the previous build so every new byte change is accounted for.
allowed=[(meta['dol_offset'],meta['dol_offset']+len(dol)),(meta['fst_offset'],meta['fst_offset']+len(fst))]+[(e['offset'],e['offset']+e['size']) for e in relocated.values()]
with BASE.open('rb') as f,TARGET.open('rb') as g:
 pos=0
 while True:
  a=f.read(1024*1024);b=g.read(1024*1024)
  if not a:assert not b;break
  assert len(a)==len(b)
  if a!=b:
   for i,(x,y) in enumerate(zip(a,b)):
    if x!=y:assert any(lo<=pos+i<hi for lo,hi in allowed)
  pos+=len(a)
patch=make(SOURCE,TARGET,OUT/'Hikaru_no_Go_3_English_Interface_v08.bps',dict(game='Hikaru no Go 3',version='0.8',base='original Japanese GHTJA4'))
assert sha(SOURCE)==previous['source_sha256'] and sha(BASE)==previous['output_sha256']
report=dict(version='0.8',source_sha256=previous['source_sha256'],output_sha256=sha(TARGET),original_unchanged=True,previous_build_preserved=True,new_dol_strings=len(edits),new_graphics=len(checks),name_display=name_check,relocated_files=relocated,graphic_checks=checks,text_checks=edits,patch=patch,new_changes_confined_to_verified_ranges=True,runtime_status='Dolphin testing required; full-game translation remains in progress')
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
for pg in range(math.ceil(len(previews)/30)):
 items=previews[pg*30:pg*30+30];sheet=Image.new('RGB',(900,90*((len(items)+2)//3)),'#354555');dr=ImageDraw.Draw(sheet)
 for i,(name,im) in enumerate(items):
  im=im.copy();im.thumbnail((294,65));x=i%3*300;y=i//3*90;dr.text((x+3,y),name,fill='white');sheet.paste(im,(x+3,y+20),im)
 sheet.save(OUT/f'interface_preview_{pg+1}.png')
print('Built',TARGET,'strings',len(edits),'graphics',len(checks),'name hook',name_check,'BPS',patch['bytes'])
