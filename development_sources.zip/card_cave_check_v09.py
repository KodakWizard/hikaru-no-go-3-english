﻿from pathlib import Path
import json
from menu_translation_v09 import CARD_FIXES
from menu_translation_v04 import TEXT as V4
from menu_translation_v05 import TEXT as V5
r=json.loads(Path('English_Interface_v08/build_report.json').read_text(encoding='utf8'));words=[int(x,16) for x in r['name_display']['reclaimed_words']]
for at,en in CARD_FIXES.items():
 old=(V4|V5)[at];clash=[hex(w) for w in words if at<=w<at+max(len(old.encode('cp932')),len(en.encode('cp932')))+1]
 if clash:print(hex(at),'name code conflict',repr(en),clash)
