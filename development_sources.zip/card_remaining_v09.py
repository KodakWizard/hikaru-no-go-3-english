﻿from pathlib import Path
import json
from menu_translation_v04 import TEXT as A
from menu_translation_v05 import TEXT as B
r=json.loads(Path('translation_work/text/japanese_candidates.json').read_text(encoding='utf8'))
for e in r:
 if e['file']=='main.dol' and 0x22f900<=int(e['offset'],16)<0x230eb0 and int(e['offset'],16) not in A|B:print(e['offset'],repr(e['japanese']))
