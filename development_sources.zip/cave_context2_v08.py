﻿from pathlib import Path
b=Path('translation_work/main.dol').read_bytes()
for at in [0x230fa3,0x277290,0x247886]:
 i=at
 while i>0 and b[i-1]!=0:i-=1
 print(hex(at),hex(i),repr(b[i:b.find(b'\0',i)].decode('cp932','replace')))
 print(repr(b[at-80:at+80].decode('cp932','replace')))
