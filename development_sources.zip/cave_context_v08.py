﻿from pathlib import Path
b=Path('translation_work/main.dol').read_bytes()
for i in [0x246b2c,0x2470ca,0x24d23c]:
 s=b.rfind(b'\0',0,i-1)+1;print(hex(i),hex(s),repr(b[s:b.find(b'\0',s)].decode('cp932','replace')))
print(repr(b[0x247000:0x247380].decode('cp932','replace')))
