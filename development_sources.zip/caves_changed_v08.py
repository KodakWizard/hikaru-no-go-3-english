﻿from pathlib import Path
import json
m=json.loads(Path('translation_work/disc_metadata.json').read_text());orig=Path('translation_work/main.dol').read_bytes()
with Path('English_Course_v07/Hikaru no Go 3 - English Course v07.iso').open('rb') as f:f.seek(m['dol_offset']);b=f.read(len(orig))
i=0x22d420
while i<0x27ab00:
 if b[i]==0:
  j=i
  while j<len(b) and b[j]==0:j+=1
  if j-i>=64 and any(orig[i:j]):print(hex(i),j-i,repr(orig[i:j].decode('cp932','replace')[:45]))
  i=j
 else:i+=1
