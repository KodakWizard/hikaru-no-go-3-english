﻿import json
from pathlib import Path
m=json.loads(Path('translation_work/disc_metadata.json').read_text());p=Path('English_Course_v07/Hikaru no Go 3 - English Course v07.iso')
with p.open('rb') as f:f.seek(m['dol_offset']);b=f.read(Path('translation_work/main.dol').stat().st_size)
runs=[];i=0x22d420
while i<0x27ab00:
 if b[i]==0:
  j=i
  while j<len(b) and b[j]==0:j+=1
  if j-i>=128:runs.append((hex(i),j-i))
  i=j
 else:i+=1
print(runs)
