"""Regression model for the verified in-place sprintf call at 0x80037ef8."""
import re
from menu_translation_v09 import CARD_FIXES
from menu_translation_v05 import TEXT as OLD

def inplace(fmt,slot,datatype):
 buf=bytearray(2048);buf[:len(slot)]=slot.encode();out=0;tokens=list(re.finditer(r'%[sd]',fmt));start=0
 for index,m in enumerate(tokens):
  prefix=fmt[start:m.start()].encode('ascii');buf[out:out+len(prefix)]=prefix;out+=len(prefix)
  if index==0:arg=bytes(buf[:buf.index(0)])
  else:arg=datatype.encode('ascii')
  buf[out:out+len(arg)]=arg;out+=len(arg);start=m.end()
 tail=fmt[start:].encode('ascii');buf[out:out+len(tail)]=tail;out+=len(tail);buf[out]=0
 return buf[:out].decode('ascii')

def verify():
 broken=inplace(OLD[0x230b3c],'Slot A','Story data')
 assert ' '.join(broken.split())=='On the On the card, create Story data?'
 tests=[]
 for at,fmt in CARD_FIXES.items():
  assert fmt.startswith('%s'),hex(at)
  count=len(re.findall(r'%[sd]',fmt));assert 1<=count<=2
  for slot in ['Slot A','Slot B']:
   for datatype in ['system data','Story data','kifu data','suspended game data']:
    args=(slot,datatype) if count==2 else (slot,)
    expected=fmt%args;got=inplace(fmt,slot,datatype);assert got==expected,(hex(at),got,expected)
    assert max(map(len,got.splitlines()))<=40,(hex(at),got)
    tests.append(dict(offset=hex(at),slot=slot,data_type=datatype,english=got))
 return dict(reproduces_reported_on_the_on_the_error=True,disassembly_callsite='0x80037ef8..0x80037f0c: destination r3 and first string argument r5 are identical',fixed_template_count=len(CARD_FIXES),slot_and_data_type_tests=len(tests),tests=tests)

if __name__=='__main__':
 r=verify();print('Card regression verified:',r['slot_and_data_type_tests'],'cases')
