from pathlib import Path
import json,re,textwrap,unicodedata
from dialogue_polish_v50 import REVISIONS,SCRIPT_REVISIONS
R=Path(__file__).parent
rows=json.loads((R/'translation_work/dialogue_v50/dol_unique.json').read_text(encoding='utf8'))
def wrap(s,width=26):
 if '\u2193' in s:return s
 # Reserve twelve half-width cells for every runtime name token.
 tokens={};n=0
 def reserve(m):
  nonlocal n
  key=chr(0xe000+n);n+=1;tokens[key]=m.group();return key*12
 expanded=re.sub(r'\$[0-9]',reserve,s)
 def wide(m):
  nonlocal n
  c=m.group()
  if unicodedata.east_asian_width(c) not in ('W','F','A'):return c
  key=chr(0xe000+n);n+=1;tokens[key]=c;return key*2
 expanded=re.sub(r'[^\x00-\x7f\ue000-\uf8ff]',wide,expanded)
 lines=textwrap.wrap(expanded,width=width,break_long_words=False,break_on_hyphens=False)
 out='\u2193'.join(lines)
 for key,token in tokens.items():out=out.replace(key*(12 if token.startswith('$') else 2),token)
 assert not any(k in out for k in tokens),('Token split',s)
 return out
if __name__=='__main__':
 errors=0
 for i,new in REVISIONS.items():
  r=rows[i];en=wrap(new);ln=en.split('\u2193');raw=en.encode('cp932')
  expanded=[re.sub(r'\$[0-9]','X'*12,l) for l in ln]
  problems=[]
  if len(raw)>r['capacity']:problems.append(f"bytes {len(raw)}/{r['capacity']}")
  if len(ln)>3:problems.append(f'{len(ln)} lines')
  if max(map(len,expanded))>26:problems.append('width')
  if re.findall(r'\$[0-9]|%[-0-9]*[sd]',new)!=re.findall(r'\$[0-9]|%[-0-9]*[sd]',r['japanese']):problems.append('tokens')
  if problems:print(i,', '.join(problems),repr(en));errors+=1
 print(len(REVISIONS),'unique revisions;',errors,'issues')
 sr=json.loads((R/'translation_work/dialogue_v50/script_unique.json').read_text(encoding='utf8'))
 errors=0
 for i,s in SCRIPT_REVISIONS.items():
  r=sr[i];header=bool(re.match(r'\d-\d\d:',r['english']))
  en=s if header else wrap(s,22).replace('\u2193','\n')
  lines=en.split('\n')
  if (header and len(en)>44) or (not header and (len(lines)>3 or max(map(len,lines))>22)):
   print('SCRIPT',i,'layout',repr(en));errors+=1
 print(len(SCRIPT_REVISIONS),'script revisions;',errors,'issues')
