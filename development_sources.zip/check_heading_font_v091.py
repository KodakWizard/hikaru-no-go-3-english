﻿from PIL import ImageFont
f=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',60)
for t in ['Skill','Rank','Games','Wins','Losses','Draws']:print(t,f.getbbox(t,stroke_width=6))
