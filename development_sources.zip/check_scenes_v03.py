from pathlib import Path
from story_scenes_v03 import SCENES
import re
b=Path('translation_work/main.dol').read_bytes()
for o,s in SCENES.items():
 old=b[o:b.index(0,o)];issues=[]
 if len(s.encode('cp932'))>len(old):issues.append(f'bytes {len(s.encode("cp932"))}/{len(old)}')
 if len(s.split('↓'))>3:issues.append('too many lines')
 if max(len(re.sub(r'\$[12]','X'*12,l)) for l in s.split('↓'))>26:issues.append('name-expanded width')
 if sorted(re.findall(rb'\$[0-9]',old))!=sorted(re.findall(rb'\$[0-9]',s.encode('cp932'))):issues.append('name tokens changed')
 if issues:print(hex(o),'; '.join(issues),s)
print('Canonical entries:',len(SCENES))
