from pathlib import Path
import textwrap,re,unicodedata
from gcs_text import text_tail
from tutorial_translation_v07 import LESSONS

def wrap(s):
 lines=[]
 for line in s.split('\n'):
  current=''
  for word in line.split():
   candidate=(current+' '+word).strip()
   cells=sum(2 if unicodedata.east_asian_width(c) in ('W','F') or c=='⑪' else 1 for c in candidate)
   if current and cells>22:lines.append(current);current=word
   else:current=candidate
  lines.append(current)
 return '\n'.join(lines)

if __name__=='__main__':
 for name,translations in LESSONS.items():
  b=Path('translation_work/extracted/script/tutorial/'+name+'.gcs').read_bytes();base,start,rows=text_tail(b)
  print(name,'source',len(rows),'English',len(translations));assert len(rows)==len(translations)
  for i,(r,en) in enumerate(zip(rows,translations)):
   en=wrap(en);new=en.encode('cp932');issues=[]
   if len(new)>r['end']-r['offset']:issues.append(f'bytes {len(new)}/{r["end"]-r["offset"]}')
   if len(en.split('\n'))>3:issues.append('more than 3 lines')
   if issues:print(i,','.join(issues),en.replace('\n',' / '))
