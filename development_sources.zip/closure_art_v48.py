"""English promotional end cards using the complete approved title artwork."""
from PIL import Image,ImageDraw,ImageFont
from qa_research_v10 import current_files
from decode_bpe import decode
from textures import resources,texture

def edits(path,b):
 assert path=='2D/jfend.bpe'
 f,_,fs=current_files('English_QA_v47/Hikaru no Go 3 - English QA v47.iso')
 off,n,_=fs['title/title.bpe'];f.seek(off);source=decode(f.read(n));f.close()
 title=texture(source,dict(resources(source))['tit00.D4'])[0]
 out={}
 for name,lines in [
  ('jfend00.D4',['The story ends here in this demo.','Enjoy the rest in the full game,','scheduled for release March 20, 2003.']),
  ('jfend01.D4',['GAME OVER','Enjoy the rest in the full game,','scheduled for release March 20, 2003.'])]:
  scale=4;im=title.resize((2560,1920),Image.Resampling.LANCZOS)
  panel=Image.new('RGBA',im.size);dr=ImageDraw.Draw(panel)
  dr.rectangle((0,299*scale,640*scale,378*scale),fill=(255,255,255,222))
  dr.line((0,299*scale,640*scale,299*scale),fill='white',width=scale)
  for i,line in enumerate(lines):
   font=ImageFont.truetype('C:/Windows/Fonts/arialbi.ttf' if line=='GAME OVER' else 'C:/Windows/Fonts/arialbd.ttf',(21 if line=='GAME OVER' else 17)*scale)
   box=dr.textbbox((0,0),line,font=font);assert box[2]-box[0]<=600*scale
   dr.text(((640*scale-(box[2]-box[0]))/2-box[0],(301+i*20)*scale-box[1]),line,font=font,fill='black')
  footer='Hikaru no Go 3 Development Team';font=ImageFont.truetype('C:/Windows/Fonts/arialbi.ttf',10*scale)
  box=dr.textbbox((0,0),footer,font=font);dr.text((620*scale-(box[2]-box[0])-box[0],365*scale-box[1]),footer,font=font,fill='black')
  im.alpha_composite(panel);out[name]=im.resize(title.size,Image.Resampling.LANCZOS)
 return out
