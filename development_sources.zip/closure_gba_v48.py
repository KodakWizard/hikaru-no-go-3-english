"""Two confirmed pointer-referenced GBA messages; fixed raw segment sizes."""
from qa_research_v10 import current_files
from gba_lz_v34 import decode
TEXT={0xd46ac:('Communication error.','\u901a\u4fe1\u30a8\u30e9\u30fc\u304c\u767a\u751f\u3057\u307e\u3057\u305f\u3002'),
      0xd609c:('Your results so far.','\u3042\u306a\u305f\u306e\u3053\u308c\u307e\u3067\u306e\u6210\u7e3e\u3067\u3059\u3002')}

def prepare(base):
 f,_,fs=current_files(base);rom=bytearray();parts=[]
 for i in range(45):
  path=f'gba/dacs/magnet/btlmenu_dacs_{i}'+('_LZ.bin' if i<40 else '.bin');off,n,_=fs[path]
  f.seek(off);raw=f.read(n);data=decode(raw) if i<40 else raw
  parts.append((path,off,len(rom),len(data),raw));rom.extend(data)
 f.close();before=bytes(rom);rows=[]
 for at,(en,jp) in TEXT.items():
  old=jp.encode('cp932');new=en.encode('cp932');assert len(new)<=len(old)
  assert before[at:at+len(old)+1]==old+b'\0'
  pointer=(0x09f00000+at).to_bytes(4,'little');refs=[p for p in range(0,len(before)-3,4) if before[p:p+4]==pointer];assert refs
  rom[at:at+len(new)+1]=new+b'\0';rows.append(dict(offset=hex(at),english=en,japanese=jp,pointer_references=refs,capacity=len(old),end=at+len(new)+1))
 cursor=0
 for row in sorted(rows,key=lambda r:int(r['offset'],16)):
  at=int(row['offset'],16);assert before[cursor:at]==rom[cursor:at];cursor=row['end']
 assert before[cursor:]==rom[cursor:]
 blobs=[]
 for path,off,start,n,raw in parts:
  data=bytes(rom[start:start+n])
  if data==before[start:start+n]:continue
  assert '_LZ.' not in path and len(data)==len(raw)
  blobs.append((off,data))
 assert len(blobs)==1
 return blobs,dict(visible_messages=rows,unchanged_addresses_and_sizes=True,all_other_gba_decoded_bytes_exact=True,changed_file=parts[43][0])
