"""Remaining visible credits/system/story text; no guessed given-name readings."""
from pathlib import Path

GROUPS=[
 ('https://patents.google.com/patent/JP2014195706A/en',[(0x277ba0,'Yamaguchi K','Ken Yamaguchi')]),
 ('https://www.mobygames.com/game/67734/yu-gi-oh-nightmare-troubadour/credits/nintendo-ds/',[(0x277c28,'Nishizawa J','Jun Nishizawa')]),
 ('https://www.mobygames.com/person/484899/koji-horie/credits/',[(0x277c68,'Horie KOG','Horie KOG; credited alias, no given-name expansion')]),
 ('https://www.mobygames.com/game/224155/yu-gi-oh-7-trials-to-glory-world-championship-tournament-2005/',[
  (0x277c78,'Ochiai Y.','Yutaka Ochiai'),(0x277d88,'Sudo Keisuke','Keisuke Sudo'),
  (0x2780dc,'Takahashi M.','Masana Takahashi'),(0x27811c,'Terashi D.','Daisuke Terashi'),
  (0x27815c,'Kitaue K.','Kazumi Kitaue'),(0x27816c,'Yamada M.','Masaki Yamada'),(0x27817c,'Nakayama K.','Katsuhiro Nakayama')]),
 ('https://www.mobygames.com/game/138098/mahoromatic-moetto-kirakira-maid-san/credits/ps2/',[(0x277d2c,'Yamatani Rie','Rie Yamatani')]),
 ('https://raido.moe/staff/ps1/ps1_hikaru_no_go_2.html',[(0x277dfc,'Sato','Family name only; given-name reading unverified')]),
 ('https://www.konami.com/ir/en/stockbond/stockholderinfo/generalmeeting/48/syosyu.pdf',[(0x277e68,'Furukawa S.','Shinichi Furukawa')]),
 ('https://www.mobygames.com/game/14912/yu-gi-oh-the-falsebound-kingdom/credits/gamecube/',[
  (0x277e78,'Akiyama H.','Hiroshi Akiyama'),(0x277e98,'Ezawa Akiko','Akiko Ezawa')]),
 ('https://www.mobygames.com/person/260984/yuko-tamada/credits/',[(0x277e88,'Tamada Yuko','Yuko Tamada')]),
 ('https://www.pairgo.or.jp/amateur/26th/players/index_e.htm',[(0x277eb8,'Ise Teruyuki','Teruyuki Ise')]),
 ('https://www.mobygames.com/game/8940/yu-gi-oh-the-eternal-duelist-soul/credits/gameboy-advance/',[
  (0x27812c,'Shimizu S.','Seiichi Shimizu'),(0x2781ec,'Shimomura S','Satoshi Shimomura')]),
 ('https://www.mobygames.com/game/16255/cy-girls/credits/ps2/',[(0x2781a0,'Ogawa Mie','Mie Ogawa')]),
]
TEXT={at:display for url,rows in GROUPS for at,display,full in rows}
TEXT.update({
 0x277b00:'Staff',
 0x251948:'Main Room',
 0x258ec0:'Wow, $2!\u2193I remember this place!',
 0x278290:'(C)Y.Hotta/HMC/T.Obata/Noel/Shueisha/TV Tokyo/Dentsu/Pierrot',
})
VERIFICATION=[dict(offset=hex(at),display=display,reading=full,source=url) for url,rows in GROUPS for at,display,full in rows]
READING_LIMITS=['Horie KOG retains the credited alias; no given name inferred or identification with Koji Horie asserted.','Sato is family-name only; the given name remains unverified and is not romanized.']
b=(Path(__file__).parent/'translation_work/main.dol').read_bytes()
EXPECTED={at:b[at:b.index(0,at)].decode('cp932') for at in TEXT}
AUDIT=[]
