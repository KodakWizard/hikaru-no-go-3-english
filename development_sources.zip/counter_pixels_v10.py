from qa_research_v10 import *
b=(WORK/'decoded/2D/bbg.bin').read_bytes();im,_=texture(b,dict(resources(b))['bbg11_0.D4'])
for frame in [4,5,6,7]:
 print('frame',frame)
 for y in [0,4,8,12,16,20,24,25,26,27,28,29,30]:print(y,[im.getpixel((x,frame*56+y)) for x in [0,5,10,70,74,77]])
