"""Verified staff readings only. Initials preserve original storage capacity.

Full names and verification sources are retained here for review.
Unverified names deliberately remain in Japanese; collectible packaging is exempt.
"""
GROUPS = [
 ('https://www.mobygames.com/game/12719/yu-gi-oh-the-dawn-of-destiny/credits/xbox/', [
  (0x277b5c, 'Matsuda E.', 'Eisuke Matsuda'),
  (0x277bac, 'Matsuda Y.', 'Yuhei Matsuda'),
  (0x278210, 'Yoshioka M.', 'Motoyuki Yoshioka'),
 ]),
 ('https://kyoto-report.wikidot.com/yoshi-s-crafted-world', [
  (0x277b80, 'Yagi Koichi', 'Koichi Yagi'),
  (0x277c34, 'Umada T.', 'Takeharu Umada'),
 ]),
 ('https://patents.google.com/patent/JP2003047769A/ja', [
  (0x277c08, 'Uchida H.', 'Hideto Uchida'),
 ]),
 ('https://patents.google.com/patent/JP2004041561A/ja', [
  (0x277bec, 'Yamamoto K.', 'Kenji Yamamoto'),
  (0x277c58, 'Takeuchi M.', 'Mayumi Takeuchi'),
 ]),
 ('https://www.mobygames.com/person/215808/taketoshi-inagaki/', [
  (0x277c94, 'Inagaki T.', 'Taketoshi Inagaki'),
 ]),
 ('https://inspion.co.jp/staff/kazuhiko-inaba/', [
  (0x277d64, 'Inaba Kazuhiko', 'Kazuhiko Inaba'),
 ]),
 ('https://www.mobygames.com/person/484899/koji-horie/credits/', [
  (0x2781bc, 'Horie Koji', 'Koji Horie'),
 ]),
 ('https://www.mobygames.com/person/260980/toshihisa-furusawa/credits/', [
  (0x277cec, 'Furusawa T.', 'Toshihisa Furusawa'),
 ]),
 ('https://www.bunka.go.jp/j-mediaarts-festival/award/profile/torishima-kazuhiko/index.html', [
  (0x2780ac, 'Torishima K.', 'Kazuhiko Torishima'),
 ]),
 ('https://imsf.co.jp/members/ibaraki/', [
  (0x2780ec, 'Ibaraki M.', 'Masahiko Ibaraki'),
 ]),
]
TEXT = {at: display for source, rows in GROUPS for at, display, full in rows}
VERIFICATION = [dict(offset=hex(at), display=display, full_name=full, source=source)
                for source, rows in GROUPS for at, display, full in rows]
