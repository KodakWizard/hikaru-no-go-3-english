"""Additional verified staff readings; no inferred given-name readings."""
GROUPS = [
 ('https://www.mobygames.com/person/195670/yasuhisa-ito/', [
  (0x277cfc,'Ito Yasuhisa','Yasuhisa Ito'),
 ]),
 ('https://www.vgmpf.com/Wiki/index.php/Waichiro_Ozaki', [
  (0x277d0c,'Ozaki Waichiro','Waichiro Ozaki'),
 ]),
 ('https://www.mobygames.com/person/188296/noriaki-okamura/credits/', [
  (0x277dc0,'Okamura Noriaki','Noriaki Okamura'),
 ]),
 ('https://www.mobygames.com/person/203917/toshimasa-takahashi/', [
  (0x2780bc,'Takahashi T.','Toshimasa Takahashi'),
 ]),
 ('https://kyoto-report.wikidot.com/jump-ultimate-stars', [
  (0x2780cc,'Yoshida Koji','Koji Yoshida'),
 ]),
 ('https://www.mobygames.com/game/29202/rurouni-kenshin-ishin-gekitohen/credits/playstation/?autoplatform=true', [
  (0x2780fc,'Yoshikura H.','Hideo Yoshikura'),
  (0x27810c,'Nomura T.','Takeshi Nomura'),
 ]),
]
TEXT={at:display for url,rows in GROUPS for at,display,full in rows}
VERIFICATION=[dict(offset=hex(at),display=display,full_name=full,source=url)
              for url,rows in GROUPS for at,display,full in rows]
