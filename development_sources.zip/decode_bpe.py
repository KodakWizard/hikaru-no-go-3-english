from pathlib import Path
import struct

def decode(data):
    target=int.from_bytes(data[:4],'big'); pos=4; out=bytearray()
    while pos<len(data) and len(out)<target:
        left=list(range(256)); right=[0]*256; c=0
        while c<256:
            count=data[pos]; pos+=1
            if count>127:
                c+=count-127; count=0
            if c>=256: break
            for _ in range(count+1):
                left[c]=data[pos]; pos+=1
                if c!=left[c]: right[c]=data[pos]; pos+=1
                c+=1
        n=int.from_bytes(data[pos:pos+4],'big'); pos+=4
        expansions=0
        for v in data[pos:pos+n]:
            stack=[v]
            while stack:
                x=stack.pop()
                expansions+=1
                if expansions>target*4: raise ValueError(('cycle/bad format',pos,n))
                if left[x]==x: out.append(x)
                else: stack.extend((right[x],left[x]))
                if len(out)>target: raise ValueError('overflow')
        pos+=n
    if len(out)!=target: raise ValueError((len(out),target,pos,len(data)))
    return bytes(out)

if __name__=='__main__':
    for p in Path('translation_work/extracted').rglob('*.bpe'):
        try:
            b=decode(p.read_bytes()); q=Path('translation_work/decoded')/p.relative_to('translation_work/extracted');q.parent.mkdir(parents=True,exist_ok=True);q.with_suffix('.bin').write_bytes(b)
            print(p,len(b),b[:32].hex(' '))
        except Exception as e: print(p,'ERROR',e)
