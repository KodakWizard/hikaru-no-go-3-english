from pathlib import Path
import sys,struct
sys.path.insert(0,str(Path('translation_work/python_libs').resolve()))
from capstone import Cs,CS_ARCH_PPC,CS_MODE_32,CS_MODE_BIG_ENDIAN
b=Path('translation_work/main.dol').read_bytes(); md=Cs(CS_ARCH_PPC,CS_MODE_32|CS_MODE_BIG_ENDIAN); md.skipdata=True
out=[]
for i in range(7):
 o=struct.unpack_from('>I',b,i*4)[0];a=struct.unpack_from('>I',b,0x48+i*4)[0];n=struct.unpack_from('>I',b,0x90+i*4)[0]
 if n:
  for ins in md.disasm(b[o:o+n],a):out.append(f'{ins.address:08x} {o+ins.address-a:08x} {ins.mnemonic} {ins.op_str}')
Path('translation_work/disassembly.txt').write_text('\n'.join(out))
