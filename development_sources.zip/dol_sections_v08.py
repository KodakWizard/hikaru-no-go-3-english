﻿from pathlib import Path
import struct
b=Path('translation_work/main.dol').read_bytes()
print('BSS',*[hex(x) for x in struct.unpack_from('>II',b,0xd8)])
for i in range(18):
 o=struct.unpack_from('>I',b,i*4)[0];a=struct.unpack_from('>I',b,0x48+i*4)[0];n=struct.unpack_from('>I',b,0x90+i*4)[0]
 if n:print(i,hex(o),hex(a),hex(n))
