from drill_translation_v14 import TEXT,add
add(126,'''
3-26: Continue Black's top-side invasion.
The ladder favours Black, so wedge at Black 1.
After White 2 and 4, Black 5 to 7 take △ in shicho.
White normally blocks from above at 2.
Black lives solidly by 11, then aims at the cut at A.
White 2 answers. This fails.
White 2 connects against Black 1.
Black is cramped at the top and White is thick outside.
White 2 cuts Black 1's outward hane. It overplays.
Surviving at the top is also difficult.
Black 1's attachment is weak. White 2 and 4 are good.
Moving toward the corner lets White 4 and 6 damage Black.
White 2 answers Black 1 and refutes it.
White 2 answers Black 1's attachment and grows strong.
''')
add(127,'''
3-27: Continue Black's top-side invasion.
The ladder is bad for Black. Play 1 to 7 to seek life.
Black can also escape at A, giving survival chances.
Black 1's wedge is troubled by White 2 and 4.
Even if Black 9 surrounds, White 10 escapes capture.
That leaves Black struggling.
White 2 answers. This fails.
White 2 cuts Black 1's outward hane. It overplays.
Surviving at the top is also difficult.
Black 1's attachment is weak. White 2 and 4 are good.
Moving toward the corner lets White 4 and 6 damage Black.
White 2 answers Black 1 and refutes it.
White 2 answers Black 1's attachment and grows strong.
''')
add(128,'''
3-28: Continue after White 8.
Black 1 makes contact; 3 attaches diagonally and connects.
If White 4 resists by descending, Black 5 cuts.
Black wins the semeai along the top.
White 2 makes contact. Black's plan fails.
Black 1 is tesuji, but damages the upper-right corner.
White 2 cuts Black 1. It is unreasonable.
''')
add(129,'''
3-29: Where should Black invade?
Black 1 is vital against a large keima framework.
White can only block at 2 and 4. Black 5 links along the top.
Black 1's attachment is invasion tesuji.
By White 6, Black reduces the area greatly in sente.
White 2 answers. It achieves little.
Black 1 is a clever move, but...
White 2 and 4 answer in gote, making Black lose value.
Black 1 is clever but does not go quite far enough.
White 2 answers Black 1, leaving Black worse.
Black in the corner cannot live.
White 2 answers Black 1. It achieves little.
White 2 answers Black 1.
''')
add(130,'''
3-30: Where should Black invade?
Black 1 invades low in the middle. White 2 and 4 seal in...
But Black 5 descends, then 7 attaches and links along the top.
If White attaches at 2, Black 3 to 5 connect easily.
White 2 answers. It achieves little.
Black 1 hits one vital point, but is a little too low.
White 2 and 4 press down, limiting its effect.
After Black 1, White 2 damages Black's corner.
Black 1 does not go deep enough.
White 2 answers Black 1. It achieves little.
''')
add(131,'''
3-31: Where should Black invade?
Black 1 invades at the vital point.
White 2's kosumi, Black 3's shoulder hit: joseki to 13.
White loses territory and has insecure eye shape too.
White 2 answers. It achieves little.
White 2 to 6 stop Black 1 linking along the top.
Black cannot connect to the right.
White 2 answers Black 1. It achieves little.
''')
add(132,'''
3-32: Invade White's top area at A, B or C.
Black 1 invades low. If White 2 stops the link...
Trade Black 3 for White 4, then leap onto the top at 5.
White 6 and 8 resist too hard. Black escapes by 13.
White 2 is the normal reply to Black 1.
By White 10, Black reduces greatly and is satisfied.
White 2 attaches against Black 1's invasion.
Even if Black lives, White can force A and enter at B.
Black has not gained much.
White 2 answers Black 1's high invasion and spoils it.
''')
add(133,'''
3-33: Continue Black's 3-3 invasion.
Black 1's kosumi lives solidly.
If White 2 blocks, Black 3 to 5 hane and connect well.
Do not make ko. Connect at Black 7.
If White presses at 8...
Black 9 blocks and can break White's enclosure.
White 2 answers. Black is worse.
Black 1's crawl fails in this position.
White 2 blocks perfectly. Black can do no better than ko.
An immediate Black 1 hane lets White 4 atari for ko.
Black 1 is clever, but White 2 descends calmly.
Black lives too small. There is a better result available.
Black 1's descent cannot live.
White 2 answers Black 1, leaving Black worse.
''')
add(134,'''
3-34: Invade the keima enclosure at 3-3.
Black 1 and 3 hane and connect, accepting ko.
Black 1 and 3 let White 4 and 6 shrink the space and kill.
White 2 answers. Black is worse.
Hane-connecting this side at 1 and 3 loses to White 4.
White 2 answers Black 1, leaving Black worse.
''')
add(135,'''
3-35: Invade the large keima at 3-3.
Black 1 cuts, then 3 and 5 hane and connect.
White must defend at 6 and 8. Black lives in sente.
White 2 descends. Black cannot live.
A simple hane-tsugi lets White 4 connect. Black lives in gote.
Black 1 connects, but White 2 descends and kills.
Black 1 connects diagonally, but White 2 hanes and kills.
Black 1's descent leads to ko.
Black 1's kosumi lets White 2 descend and kill.
White 2 descends after Black 1. Black cannot live.
White 2 shrinks Black's area. Black cannot live.
White 2 cuts Black 1. Black cannot live.
White 2 captures Black 1. A large loss.
White 2 connects after Black 1. A large loss.
''')
add(136,'''
3-36: Fuseki: which extension, A to D?
With the enclosure marked △...
Extending toward A is big; toward B is small.
Black 1 combines valuable extensions for both sides.
It is considered the biggest move in this position.
That Black 1 is also big, but a more valuable move exists.
''')
add(137,'''
3-37: Fuseki: which extension, A to D?
From the enclosure marked △...
Extensions on both sides make a double-wing formation.
It is an ideal framework in fuseki.
Extending on the left urgently prevents White's wings.
That Black 1 is also big, but a more valuable move exists.
''')
add(138,'''
3-38: Fuseki: which extension, A to D?
A move with a special follow-up aim is big.
If White ignores Black 1, Black 3 can invade.
That threat makes Black 1's extension valuable.
That Black 1 is also big, but a more valuable move exists.
''')
add(139,'''
3-39: Fuseki: which extension, A to D?
A subtle difference: Black's upper-right shape is high.
Black 1 extends while defending firmly, so it is big.
If White 2 approaches Black's fourth-line enclosure...
Threats at A and B remain for later.
That Black 1 is also big, but a more valuable move exists.
''')
add(140,'''
3-40: Fuseki: which point, A to D?
Black's right-side moyo meets White's bottom moyo.
Black 1 is the junction between these frameworks.
It is a very big point in fuseki.
Compare this sequence...
With this one, and you will see how large it is.
That Black 1 is also big, but a more valuable move exists.
''')
add(141,'''
3-41: Fuseki: which point, A to D?
Black 1 attaches diagonally, attacking the two Whites.
Black has the advantage.
Urgent moves for a group's base come before big extensions.
White should have slid at 1 to secure a base.
That Black 1 is also big, but a more valuable move exists.
''')
add(142,'''
3-42: Fuseki: which point, A to D?
Black 1 and 3 settle the group firmly.
It may look small, but it is very important.
Urgent moves for a group's base come before territory.
White 1 and 3 would weaken Black in the upper left.
That Black 1 is also big, but a more valuable move exists.
''')
add(143,'''
3-43: Deny White eyes and capture.
Black 1 offers a large sacrifice.
After the capture, Black 3 plays inside.
Even if White defends at 4, this is one eye.
Black 5 makes the corner eye false. White cannot live.
White 2 capturing this way secures two eyes and lives.
''')
add(144,'''
3-44: Deny White eyes and capture.
Black 1 wedges.
If White 2 captures, Black 3 catches △ in oiotoshi.
Saving the three top Blacks leaves White no room to live.
If White 2 answers Black 1, Black 3 connects.
Even if White 4 takes the top Blacks, it is nakade.
White 2 defends. This fails.
Starting with Black 1's atari lets White 4 take the top.
Black 5's connection and White 6's life are miai. White lives.
White 2 captures Black 1 and lives in bent four.
Reducing White in order from Black 1 does not make nakade.
Black 1 is clever, but White 2's connection defends well.
White 4 answers Black 3. Four points give White life.
''')
add(145,'''
3-45: Deny White eyes and capture.
Black 1 makes a square shape and offers it for capture.
Even after White 2 captures, this is only one eye.
Black 3 makes the right eye false.
Even if White 4 and 6 aim for a corner eye...
Black 7 prevents the eye.
White 2 captures and lives.
Black 1 and 3 reduce the left to one eye, but...
Black ends in gote. White 4 answers and lives.
''')
add(146,'''
3-46: Deny White eyes and capture.
Black 1's attachment deprives White of eye shape.
Answer White 2 at Black 3: one eye on the left in sente.
Black 5's snapback is decisive.
White 2 lives.
Black 1 targets White's defect, but White 2 answers.
When Black 3 captures here, White 4 lives.
''')
add(147,'''
3-47: Deny White eyes and capture.
Calmly connect at the base with Black 1.
It is the only way to rescue Black inside White.
Whatever White does, Black can connect.
White cannot live.
White 2 connects and lives.
White 2 blocks Black 1's move.
White 2 blocks Black 1's kosumi.
White 2 blocks Black 1's descent.
Even if Black 3 cuts, Black loses the semeai.
Black 1 lacks thought. White 2 and 4 stop it and live big.
Cutting directly at Black 1 lets White 2 atari and capture.
White 2 connects after Black 1 and lives.
Black 1's hane is poor.
Black 3 is good, but White 4 and 6 make oiotoshi.
White 2 blocks Black 1 and makes an eye on each side.
''')
add(148,'''
3-48: Make two eyes for Black to live.
Black 1 is vital for eyes. White 2 must capture.
Black 3 prevents White connecting at A: no five-point nakade.
This is called oshitsubushi, or a squeeze.
White 2 captures Black.
White 2 leaves nakade even after capture. No two eyes.
Black on the left is captured. There is too little space.
''')
add(149,'''
3-49: Make two eyes for Black to live.
Black 1's jump takes the vital 2-1 point.
White 2, Black 3 connects: one eye on each side.
This way, Black cannot live.
Black 1 takes one White. White 2 and 4 make nakade and kill.
Black 1 is a 2-1 point, but White 2's placement kills.
White 2 takes the vital eye point after Black 1.
Even if Black 5 captures, A is a false eye.
Black 1 is good, but White 2 starts an attack.
By White 6, the shape looks like seki, but...
Bent four in the corner is dead by rule.
Black 1's expansion is possible, but White 2 is vital.
Even if Black 3 expands, it becomes five-point nakade.
''')
add(150,'''
3-50: Find a move against White's corner.
Start moving with Black 1.
White 2 blocks; Black 3 hanes for ko. Correct.
White 2 connects.
White 2 connects against Black 1's kosumi.
White captures Black in the corner at 6 and 8.
White 2 connects and captures Black in the corner.
The top eye also remains intact, so White lives.
White 2 connects and takes Black in the corner.
White 4 is good. Recapturing at 6 makes a top eye and lives.
White 2 captures Black 1.
''')
add(101,'''
3-01: Exploit White's weakness to capture.
Black 1's wedge is vital. Black 3 to 7 prevent escape.
White 2 prevents the capture.
''')
add(102,'''
3-02: Exploit White's weakness to capture.
Black 1's diagonal attachment strikes White's weakness.
Black 5 captures White by snapback.
White 2 answers and prevents the capture.
White 2 answers Black 1. White cannot be captured.
''')
add(103,'''
3-03: Exploit White's weakness to capture.
Black 1 attacks White's weakness.
After repeated ataris, Black 5 gives an inescapable atari.
White 2 is forced, but Black 3 gives double atari.
White 2 connects. White cannot be captured.
Black 1's cut has the right aim, but White 2 connects.
You cannot capture White in the corner either.
White 2 captures. That is all.
''')
add(104,'''
3-04: Exploit White's weakness to capture.
Black 1 is tesuji.
White 2 takes one stone. Black 3 to 5 win the semeai.
If White answers Black 1 here at 2, connect at Black 3.
Black wins the semeai and captures four White stones.
After White 2, Black cannot capture White.
White 2 captures and Black cannot take White.
''')
add(105,'''
3-05: Exploit White's weakness to capture.
Black 1: in a symmetric shape, play in the centre.
Even trying to flee at White 2 or 6, White cannot escape.
White 2 captures Black.
After Black 1, White 2 captures Black.
''')
add(106,'''
3-06: Corner joseki. Black's next move?
Black 1 defends the corner. White extends; play settles.
Black 1 leaves A weak. White extends; play settles.
Black 1 is a little weak. White extends; play settles.
Do not let White 2 press Black low.
Black 1 overplays. White 2 cuts.
Black 1 does little useful work.
Black 1's framework is too thin.
Black 1 plays too thinly.
Black 3 is about the only reply to White 2, but poor.
Black 1 does little. White 2 and 4 develop widely.
Black 1 and 3 are premature and strengthen White.
''')
add(107,'''
3-07: Corner joseki. Black's next move?
Black 1 slides underneath to secure a base.
An old-fashioned move, but Black gets a base.
White 2 deprives Black of a base.
Black 1 strengthens White.
White 2's kosumi damages Black in the corner.
This strengthens White on the side.
This strengthens White in the corner.
White 2 cramps Black in the corner.
Black 1's cap overplays. White 2 and 4 refute it.
Black 1's attachment overplays. White 2 captures.
After Black 1, White 2 deprives Black of a base.
''')
add(108,'''
3-08: Corner joseki. Black's next move?
Black 1 attaches. By 5, the top and right divide fairly.
Black 1 fights boldly. By 7, the central fight decides.
White 2 extends at the vital point.
Black 1 is crude. By White 8, White controls both sides.
Black 1 and 3 weaken the top.
White 2 hanes against Black 1.
This fight is very difficult. I do not recommend it.
White 2 answers Black 1 with a good result.
White 2 pushes out, leaving Black worse.
White 2 extends, leaving Black worse.
White 2 answers Black 1.
Atari at A will force a reply later, but the shape is poor.
Black 1 is clever, but White 2 extends at the vital point.
''')
add(109,'''
3-09: Corner joseki. Black's next move?
Black 1 must head out to the centre. Through 9 is joseki.
White 2 answers and Black is worse.
Black's development toward the centre is weak.
Playing Black 1 first lets White 8 attack the top at 7.
White 2 answers Black 1, leaving Black worse.
Black 1 is timid and strengthens White.
''')
add(110,'''
3-10: Corner joseki. Black's next move?
Black 1's hane is vital. By 9, the top and right divide.
White 2 extends at the vital point. Black is worse.
Black 1 overplays a little. White 2 counterattacks.
Trading Black 1 for White 2 gains nothing.
White 2 answers Black 1, leaving Black worse.
''')
add(111,'''
3-11: Black to exploit White's weakness.
Black 1 is tesuji. Black 5's snapback finishes it.
White 2 defends. You missed the chance.
Black 1 is good technique, but leads to ko by White 4.
Black has little besides the ko threat at 5.
Black cannot win the ko or gain anything.
White 2 answers Black 1 and spoils the plan.
A weakness remains, but Black 1 fails to exploit it.
''')
add(112,'''
3-12: Black to exploit White's weakness.
Black 1's wedge cuts White apart.
If White answers at 2, Black 3 connects.
White 2 defends. You missed the chance.
Black 1 is close, but fails.
When Black 3 wedges, White 4 to 6 capture Black.
Black 5 at A makes a yose-ko, but still fails.
White 2 answers Black 1 and refutes it.
White 2 answers Black 1 and spoils the plan.
A weakness remains, but Black 1 fails to exploit it.
''')
add(113,'''
3-13: Black to exploit White's weakness.
Black 1 is tesuji. If White 2 takes, 3 to 5 make oiotoshi.
White 2 defends. You missed the chance.
Black 1 has the right aim but needs setup. White 2 and 4 refute.
White 2 answers Black 1 and spoils the plan.
A weakness remains, but Black 1 fails to exploit it.
''')
add(114,'''
3-14: Black to exploit White's weakness.
Black 1 aims at snapback on both sides.
White 2, Black 3: four Whites on the right die by snapback.
If White 2 defends here, Black 3 to 5 start ko.
White 2 defends. You missed the chance.
White 2 defends against Black 1.
Even after Black 3, White 4 lives in the corner.
White 2 answers Black 1 and refutes it.
''')
add(115,'''
3-15: Black to exploit White's weakness.
Black 1 targets weaknesses on both sides.
If White answers at 2, Black 3 kills the upper right.
If White 2 defends this corner, Black 3 to 5 make oiotoshi.
White 2 defends. You missed the chance.
White 2 defends the top after Black 1.
White also wins the semeai on the bottom.
White 2 answers Black 1 and spoils the plan.
A weakness remains, but Black 1 fails to exploit it.
''')
add(116,'''
3-16: Reduce White's top territory.
Black 1's placement is vital.
If White 2 connects, Black 3 escapes through this gap.
If White resists, Black wins a large semeai by 9.
White 2 is the normal answer to Black 1.
Black 3 and 5 swallow the lone corner White.
White 2 defends. You missed the chance.
If Black 1 pushes out, White 2 answers.
Black 3 is vital, but White 4 answers.
White 6 is good. Black loses the semeai.
Black 1's wedge is a vital point, but White 2 refutes it.
White 2 answers Black 1. It achieves little.
White 2 answers Black 1, leaving Black worse.
''')
add(117,'''
3-17: Reduce White's top territory.
Black 1's kosumi is endgame tesuji.
White normally gives way at 4. Black reduces in sente.
If White 4 blocks like this...
Black 5 threatens to start a large ko.
White 2 defends against Black.
White 2 answers Black 1 well. It achieves little.
White 2 answers Black 1. It achieves little.
White 2 answers Black 1, leaving Black worse.
''')
add(118,'''
3-18: Reduce White's top territory.
Boldly jump in at Black 1. White 2 and 4 take two, but...
Black 5 recaptures and penetrates deep inside White's area.
White 2 blocks. This fails.
Black 1 is good, but a more profitable move exists.
White 2 answers Black 1. It achieves little.
White 2 answers Black 1, leaving Black worse.
White 2 answers Black 1 and spoils the plan.
Ways to reduce remain, but Black 1 fails.
''')
add(119,'''
3-19: Reduce White's top territory.
Black 1's placement is vital.
White normally answers from 2 to 12. A big reduction in sente.
White 2 defends. This fails.
Black 1 is good, but a more profitable move exists.
Black 1 is promising, but a more profitable move exists.
White 2 answers Black 1. It achieves little.
White 2 answers Black 1, leaving Black worse.
''')
add(120,'''
3-20: Find a move inside White's top area.
Black 1's tenacious hane makes ko.
If White 2 connects, Black 3 connects and kills the corner.
White 2 captures, leaving Black no foothold.
White 2 answers Black 1 and spoils the plan.
Black 3's tesuji still remains, but...
Winning the ko gains a little less this way.
White 2 answers Black 1, leaving Black worse.
''')
add(121,'''
3-21: Answer White 1 and 3.
Simply extend at Black 1.
If White 2 starts crawling on the second line, Black is happy.
White 2 caps and captures Black.
White 2 breaks through Black 1. Black is worse.
White on the third line is acceptable. Be more severe.
White 2 and 4 capture Black 1 in shicho.
''')
add(122,'''
3-22: Answer White's cuts at 1 and 3.
Black 1's atari forces a reply, capturing White's key stones.
Black 3's atari forces a reply, capturing White's key stones.
White 2 answers. Black's plan fails.
Black 1 is clever, but White 2 is a good reply.
Black cannot capture White.
White 2 answers. Even chasing with 3 and 5 cannot capture.
White 2 answers Black 1, leaving Black worse.
''')
add(123,'''
3-23: Answer White 1 and 3.
Black 1 gets out through this gap.
If White 2 blocks, Black 3 can cut White apart.
White 2 captures. You missed the chance.
Moving Black 1 directly does not work.
White 2 connects. You missed the chance.
Black 3 is also captured by White 4.
''')
add(124,'''
3-24: Punish White 1's overextension.
Black 1 attaches sharply. White 2 loses the corner by 7.
The White stones at the top also cannot live.
White 2's diagonal attachment is the normal reply.
Black cuts off the top White stones in sente.
Black 1 and 3 are tesuji, cutting off White at the top.
But through Black 9, Black finishes in gote.
White 2 answers. Do not expect a large gain.
White 2 blocks Black 1 and prevents escape.
White 2 answers Black 1.
Black 3 and 5 do not work.
Black 1 goes too deep. White 2 refutes it.
''')
add(125,'''
3-25: Punish White 2's outward hane.
First, cut with Black 1.
Even after White 2 and 4, Black 5 turns: A and B are miai.
White cannot handle both threats.
White 2 connects, splitting Black. Black is worse.
White 2 connects after Black 1. No link along the top.
''')
