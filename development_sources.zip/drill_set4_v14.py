from drill_translation_v14 import TEXT,add
add(151,'''
4-01: Black to choose A-D.
4-01: Black: A-D? Д Joseki
Black 1 pincers from the top.
This also brings Black △ into play.
Black becomes solid, but White grows strong too.
Leaving Black △ isolated at upper left is bad.
Black 1 and 3 aim to attack White, but...
Here, White 4 extends and cannot be attacked.
Instead, Black △ at the upper left becomes weak.
Black 1 is safe, but White 2 extends along the top.
Black △ at the upper left becomes weak.
''')
add(152,'''
4-02: Black to choose A-C.
4-02: Black: A-C? Д Joseki
Black 1 to 3 cap White.
The joseki extensions at White 4 and 6 are cramped here.
The result favours Black.
Black 1 at 3-3 gives White a good left-side moyo.
After the joseki to White 6, Black 7 takes a big point...
But △ loses value and White is satisfied too.
Black 1's double approach through 7 is popular joseki.
Black's direction is not bad, but...
Black ends in gote, so White 8 takes a big point.
''')
add(153,'''
4-03: Black to choose A-C.
4-03: Black: A-C? Д Joseki
Black 1 blocks White and builds thickness at the top.
Next, Black takes a big point at A, B or C.
Blocking the right at Black 1 is tempting, but too wide.
White 6 splits the side, reducing Black's thickness.
Black 1 is not joseki in this position.
White 8 slides underneath. Black is too generous.
Even if Black 7 blocks here, White 8's hane is severe.
''')
add(154,'''
4-04: Black to choose A-C.
4-04: Black: A-C? Д Joseki
Black's upper-left shape is solid and low. The top is small.
Black 1 heads toward the open right side.
You aimed at the attach and pullback joseki.
Black would indeed be happy with this sequence...
But White will play the avalanche at 2 and 4.
Black at upper right overlaps △, giving a poor result.
Black 1's pincer is not a problem in itself.
But in this joseki, Black's thickness overlaps △.
''')
add(155,'''
4-05: Black to choose A-C.
4-05: Black: A-C? Д Joseki
With the upper-right enclosure as support...
Black 1 and 3 should start an active fight.
Black 1 and 3 play peacefully.
Not bad enough to fail outright, but lacking spirit.
Black 1 and 3 lose locally.
Splitting the left side is not especially urgent either.
''')
add(156,'''
4-06: Punish White's bad move.
Black's top is solid, so Black 1 and 3 can push and cut.
White 2 connects. You missed the chance.
White 2 answers Black 1, leaving Black worse.
A weakness remains, but Black 1 fails to exploit it.
Black 1 and 3 are still small moves.
Even cutting at Black 3, White 6 and 8 live solidly.
Black has lost value.
White 2 answers Black 1, leaving Black worse.
''')
add(157,'''
4-07: Punish White's bad move.
First, Black 1 seals White into the corner.
White should have defended the corner; that was big.
White 2 answers. Black is worse.
Advancing Black 1 this far lets White 2 break through.
Black 1 is good, but White 2 to 6 develop on the right.
White 2 answers Black 1, leaving Black worse.
''')
add(158,'''
4-08: Punish White's bad move here.
Black 1 cuts from below.
White 4's shicho does not work, so White struggles.
White 2 answers. Black is worse.
Black 1 is normal joseki, but misses the chance.
White 2 answers Black 1, leaving Black worse.
''')
add(159,'''
4-09: Exploit White's weak move.
Black 1 threatens the corner in sente.
If White 2 defends it, Black 3 revives the top Blacks.
If White 2 defends here instead...
Black 3 descends. Points 4 and 5 are miai: Black's corner.
Start at Black 1, then Black 3 forces a reply.
If White 4, Black 5 revives the top Blacks.
If White 4, Black 5 takes the upper-right corner.
White 2 answers. Black is worse.
White 2 answers Black 1. That is all.
White 2 answers Black 1.
Black gets the corner, but is cut off from the centre.
White 2 answers Black 1, leaving Black worse.
''')
add(160,'''
4-10: Punish White's overplay.
Black 1 and 3 start moving at the top.
White 4 and 6 capture the top, but...
With Black 5 in place, Black 7 cuts and takes the right.
Some positions may call for prioritising the top.
Then start at Black 1 and 3 on the right.
Black can capture the top at 5 and 7.
Locally, however, capturing the right is bigger.
White 2 answers. Black is worse.
Black 1 is good shape. It is not bad, but...
By Black 11, White also gets territory. A missed chance.
Black 1 is timid.
By White 2 to 6, Black's corner and centre are weak.
White 2 answers Black 1, leaving Black worse.
''')
add(161,'''
4-11: Yose A-C? No captures; komi 6.5.
Black 1's kosumi is big, sente for either side.
Black leads 8 on board; wins by 1.5 after komi.
Black 1 was the smallest yose.
The board is even. White wins by 6.5.
Black 1 is big, but it is gote yose.
Black leads 5 on board. White wins by 1.5.
''')
add(162,'''
4-12: Yose A-C? No captures; komi 6.5.
Taking four Whites also saves three Blacks. Biggest move.
Black leads 7 on board; wins by 0.5 after komi.
White 2 takes three Blacks and saves four Whites.
Black leads 5 on board. White wins by 1.5.
White 2 takes three Blacks and saves four Whites.
Black leads 5 on board. White wins by 1.5.
''')
add(163,'''
4-13: Yose A-C? No captures; komi 6.5.
Black plays where White would have sente.
This is reverse-sente yose, worth more than usual.
Leave the right and bottom as miai.
Black leads 7 on board; wins by 0.5 after komi.
If White guards the bottom instead, the result is the same.
White 2 is sente against Black's upper-left life.
White gets both the top and bottom.
White wins the half-point ko and connects.
Black leads 3 on board. White wins by 3.5.
''')
add(164,'''
4-14: Black's next middle-game move?
Black 1's cut is severe.
White now has two weak groups inside Black's influence.
White 2 defends. You missed the chance.
Black 1's broad attack is possible, but misses the chance.
White 2 answers Black 1's peep in good shape.
White 2 connects. Black 1 is bad, strengthening White.
This lone White stone is small.
White 4 builds a framework. You missed the chance.
White 2 builds a framework. You missed the chance.
White 2 answers Black 1. Black 1 is not urgent yet.
White 2 answers Black 1, leaving Black worse.
White 2 defends Black 1. You missed the chance.
''')
add(165,'''
4-15: This joseki is wrong here. Punish it.
Black 1 starts ko. Normally Black has no threats, but...
Here, Black 3 is a ko threat in the upper left.
White must compromise at 6. Black 7's ponnuki is enough.
White 2 takes the ko first.
Black 1 is joseki, but misses the chance.
Black 1 concedes the initiative.
Black 3 and 5 capture, but a more valuable move exists.
Starting a large ko at Black 1...
Lets White 6 connect. Black runs out of ko threats.
White 6 blocks. Black runs out of ko threats.
White 6 extends. Black runs out of ko threats.
White 2 removes Black's ko threats after Black 1.
White 2 makes Black 1 lose value. Not good.
White 2 answers Black 1, leaving Black worse.
White 2 answers Black 1.
It creates a ko threat, but that is not needed here.
White 2 takes the ko first after Black 1.
''')
add(166,'''
4-16: Find Black's decisive chance.
Black 1's cut is decisive.
White 2 and 4 are forced.
By Black 5, half of White is cut off and captured.
If White prioritises connecting at 2 and 4...
Black 5 reinforces. White's large group has no eyes.
White 2 defends. You missed a big chance.
White 2 cuts Black 1. You missed the chance.
White 2 defends Black 1. You missed the chance.
''')
add(167,'''
4-17: Black: is A or B bigger?
White cannot block Black 1. A seven-point sente yose.
Compared with White blocking at △, the difference is 7.
Black 1 takes three Whites, reducing White's area by 3.
Three new Black points make the total value 6.
But it is gote, so Black loses considerable value.
''')
add(168,'''
4-18: Black: is A or B bigger?
If Black 1 connects, □ becomes Black territory.
White 1 captures, leaving a five-point follow-up at A on △.
Black 2 may defend: each side has a 2.5-point share.
White 1 takes one Black and makes 3.5 points of territory.
Thus the total swing is 7.5 points.
Black 1 defends and makes one Black point at □.
White 1 takes three Blacks and makes two points: total 5.
Thus the total swing is 6 points.
''')
add(169,'''
4-19: Black: is A or B bigger?
Black 1 cuts and captures three Whites.
Three new Black points make a total of 6.
If White connects at 1...
White: 3 points and 1 Black prisoner, total 4.
Thus Black 1 is worth a ten-point swing.
Black 1 takes four Whites and makes four Black points.
This move is worth 8 points in total.
''')
add(170,'''
4-20: Black: is A or B bigger?
Black 1 cuts and takes three Whites.
Three points after capture give Black a total of 6.
If White connects at 1...
White gets six points plus three Blacks: total 9.
Thus Black 1 is worth a fifteen-point swing.
If Black 1 captures the corner...
Six White prisoners plus seven points make 13 for Black.
If White defends at 1, White gets one point at □.
Thus Black 1 is worth a fourteen-point swing.
''')
add(171,'''
4-21: Black: is A or B bigger?
Defending at Black 1 is bigger. Without it...
White can enter as far as 1.
Black would lose a large amount of territory.
This point is smaller. Even without defending now...
White can enter only as far as 1.
''')
add(172,'''
4-22: Semeai: Black's next move?
Black 1's cut is tesuji, extending Black's liberties.
Because of Black 1, White must detour at 6.
By Black 9, Black wins by one liberty.
White 2 captures Black.
White 2 stops Black gaining liberties. Black loses by one.
''')
add(173,'''
4-23: Semeai: Black's next move?
Black 1's wedge reduces White's liberties.
Sacrifice Black 1. Black 7 is another good move.
Black wins by one liberty.
After White 2, Black cannot win the semeai.
Attacking at Black 1 and 3 lets White 4 win by one.
Black 1 is vital, but White 2 prevents a semeai win.
''')
add(174,'''
4-24: Semeai: Black's next move?
Black 1 is vital for extending Black's liberties.
Now Black wins the semeai by one liberty.
After White 2, White wins the semeai.
If Black 1 simply attacks White...
White 2's throw-in is good. Black loses by one.
Black 1 is a bad move.
White wins the semeai even without White 2 and 4.
White wins the semeai even without White 2.
''')
add(175,'''
4-25: Semeai: Black's next move?
Black 1 is the vital semeai point.
Because it is a corner, White must detour at 6.
Black wins by one liberty.
White 2 answers and White wins the semeai.
Simply attacking at Black 1 lets White 2 make ko.
White 2 answers Black 1's attack and wins the semeai.
''')
add(176,'''
4-26: Semeai: Black's next move?
Black 1's kosumi is semeai tesuji.
White must detour at 4, so Black wins by one move.
White 2 captures Black.
Simply giving atari at Black 1 lets White 2 connect and win.
Black must also detour at 3, losing by one move.
Attacking outside first follows the basic rule, but...
White 2 attacks normally and wins the semeai.
White 2 takes Black 1, increasing White's liberties.
Black 1 is tesuji, but White 2 captures and refutes it.
Even if Black 3 and 5 attack, White 6 saves all of White.
Black 1 is a clever tesuji.
White can play 2 to 4 and make seki...
Or play White 4, taking Black but losing half of White.
White chooses according to the situation.
Either way, Black has failed.
White 2 beats Black 1 in the semeai.
''')
add(177,'''
4-27: Semeai: Black's next move?
Black 1 must enter this far.
Answer White 2 and 4 by pulling back at 3 and 5; force 6.
Black wins by one move through 11.
White 2 makes Black lose the semeai.
Black 1 misses the attack on the main group.
Black cannot avoid detouring at 3 and loses by one move.
White 2 prevents Black 1 from living.
After Black 1, Black cannot win the semeai either.
Black 1 is too direct.
White 4 forces a reply. White already wins the semeai.
''')
add(178,'''
4-28: Semeai: Black's next move?
Making an eye at Black 1 is good here.
One eye against none means White 2, 4, 6 and 8...
Must take a long detour to capture Black.
Black captures White by 11.
After White 2, Black cannot win the semeai.
White 2 attacks to prevent Black 1 making an eye.
Black loses the semeai by a wide margin.
''')
add(179,'''
4-29: Exploit White's weakness for profit.
Black 1's throw-in is tesuji.
Black 3 makes oiotoshi and breaks White's lower left.
White 2 captures. Black missed the chance.
Black 1's attack is too simple.
White 2 connects and captures Black first.
White 2 answers Black 1. Nothing happens.
A weakness remains, but Black 1 fails to exploit it.
Black 1 removes the chance to exploit White's defect.
''')
add(180,'''
4-30: Exploit White's weakness for profit.
Black 1's throw-in is vital.
If White 2 captures here, it is not snapback, but...
Black 3 takes one stone, starting ko over the upper left.
White 2 captures. You missed the chance.
White 2 answers Black 1. Nothing happens.
A weakness remains, but Black 1 fails to exploit it.
''')
add(181,'''
4-31: Exploit White's weakness for profit.
First, Black 1 fills a liberty firmly.
This can lead White into oiotoshi.
If White 2 connects to prevent oiotoshi, Black 3 escapes.
White cannot cut at 4.
White 2 defends. You missed the chance.
White 2's connection answers Black 1's throw-in.
Playing Black 1 first lets White escape by 4.
Playing Black 1 first lets White 4 connect and escape.
White 2 takes one Black. Black cannot capture White.
White 2 answers Black 1. Nothing happens.
A weakness remains, but Black 1 fails to exploit it.
''')
add(182,'''
4-32: Exploit White's weakness for profit.
Black 1 cuts in sente, then hanes at 3.
White 4 is tesuji, but neither A nor B works.
White must detour at 6.
Black wins by one move.
White 2 defends. You missed the chance.
Black 1's atari removes White's weakness.
White 2 takes Black 1 and removes the chance to exploit.
White 2 answers Black 1 and spoils the plan.
White 2 answers Black 1 and lives.
Black 1 removes an eye, but White 2 connects underneath.
A weakness remains, but Black 1 fails to exploit it.
''')
add(183,'''
4-33: Exploit White's defect for big profit.
Black 1's kosumi can capture three Whites on the bottom.
White's large right group has no eyes either. Great success.
White 2 answers. You missed a big chance.
Good work spotting that Black 1 can take three Whites...
But White 2 and 4 live on the right.
White 2 answers Black 1 and spoils the plan.
A weakness remains, but Black 1 fails to exploit it.
''')
add(184,'''
4-34: Exploit White's defect for big profit.
Black 1 blocks White in.
Wait for White 2, then throw in at Black 3.
This kills all of White along the bottom.
White 2 answers. You missed the chance.
Attacking from the corner at Black 1 is close, but fails.
White 2 and 4 let the main bottom group just live.
White 2 answers Black 1 and spoils the plan.
White 2 answers Black 1.
Black must return at 3, so there is no effective move here.
White 2 captures Black 1.
A weakness remains, but Black 1 fails to exploit it.
White 2 answers and removes the chance to exploit the defect.
''')
add(185,'''
4-35: Exploit White's weakness for profit.
Black 1's atari makes the geta at 3 work.
Black greatly reduces White's central territory.
White 2 answers. You missed the chance.
White 2 answers Black 1. Nothing happens.
A weakness remains, but Black 1 fails to exploit it.
White 2 removes the chance to exploit White's weakness.
White 2 escapes after Black 1.
''')
add(186,'''
4-36: Exploit White's weakness for profit.
Spotting Black 1's atari is the key.
White cannot connect against the atari, but...
If White 2 captures, Black 3 captures half of White.
If White 2 plays here, Black 3 takes the left half.
White 2 answers. You missed the chance.
''')
add(187,'''
4-37: Take White; save upper-right Black.
Ugly shape, but push at Black 1.
After White 2 extends, Black 3's cap is tesuji.
If White 4 crawls, Black 5's throw-in captures by 9.
If White 4 jumps, Black 5 and 7 attack for oiotoshi.
White 2 escapes.
Black 1's cap lets White 2 jump out.
White cannot be captured in this shape.
Playing Black 1 first fails.
Even if Black 3 caps, it cannot trap White.
White 2 evades Black 1's attachment and escapes.
White 2 blocks Black 1's peep. White cannot be taken.
White 2 and 4 escape.
Black 1 is a promising tesuji.
White 2 and 4 resist. Black 5, 7 and 9 can make ko.
But ko is not good enough for Black.
White 2 escapes from Black 1.
White 2 captures Black 1. Black cannot take White.
''')
add(188,'''
4-38: Take White; save Black at the top.
Black 1 makes two ladders miai.
If White 2 protects the top...
Black 3 captures the central White in shicho.
If White 2 escapes through the centre...
Black 3 captures White at the top.
White 2 captures the three Black stones at the top.
Starting with Black 1's atari lets White 2 escape.
White 4 also forces an atari reply. Black cannot capture.
White 2 extends against Black 1's crawl.
Black 3 puts △ in atari, so this is not shicho.
White 2 answers Black 1 and captures the top Blacks first.
White 2 answers Black 1. Nothing happens.
A capturing tesuji remains, but Black 1 fails.
Black 1's cap cannot trap White.
White 2 escapes centrally from Black 1's kosumi.
White 2 escapes centrally from Black 1's atari.
Even if Black 3 attacks the top, Black is captured first.
White 2 answers Black 1 and spoils the plan.
''')
add(189,'''
4-39: Answer White 1's cut.
Black 1's connection is tesuji.
White 2 captures Black in the corner, but...
Black 3 descends: the stone-tower squeeze captures White.
Black 7's throw-in attacks. Black wins by one move.
White 2 captures. This fails.
Black 1 and 3's squeeze is clever, but...
White 8's hane gains liberties. Black loses by one move.
White 2 answers Black 1. Black has reduced its own liberties.
''')
add(190,'''
4-40: Win the semeai; take corner White.
Black 1 is the weasel's-belly attachment tesuji.
White 2 connects. Black 3 links and wins by one move.
White 2's hane prevents Black winning the semeai.
Black 1 attacks, but must take one stone at 3 after White 2.
Then Black loses the semeai.
Black 1's placement is tesuji, but can only get ko.
Black 1's hane attacks hard, but White 2 defends stubbornly.
Black 1's descent is good, but White 2's jump is strong.
White wins the semeai.
White 2 attacks Black 1 and wins the semeai.
Black 1 reduces Black's own liberties.
''')
add(191,'''
4-41: Take top White; save central Black.
Black 1 is vital. Answer White 2 by lining up at 3.
This is the raccoon's-belly drum tesuji.
Even if White 4 resists, sacrifice two Blacks through 11.
White has only two moves left. Black wins by one.
If White 2 connects after Black 1...
Black 3 attacks one step at a time and wins by one move.
White 2 leaves White four moves. Black cannot win.
Black 1's block is natural, but White 2's hane forces.
Two forcing hanes gain one liberty, as the saying goes.
Black 3 attacks, but by White 8, White wins by one.
Black 3 after White 2 makes ko, but still fails.
Black 1 is sharp, but White 2 and 4 capture.
Against Black 7's tesuji, White 8 can push once in sente.
White wins the semeai by one move.
Black 1's attachment is clever.
White 2 hanes, then starts the semeai at 4.
Black 5 and 7 can fight for ko, but that is not enough.
Directly attacking at Black 1 can get no better than ko.
''')
add(192,'''
4-42: Exploit White's shape and crush it.
Black 1's cut is severe.
White can only push out this way at 2 and 4.
Black 5 to 7 chase White.
This loose-ladder tesuji captures White by Black 13.
White 2 defends. You missed the chance.
Black 1 connects, but White 2 to 4 win the semeai.
Even using the stone-tower squeeze at 5 and 7 is too slow.
Black 1 and 3 are safe, but need more thought.
White 2 and 4 answer Black 1's attack and win the semeai.
''')
add(193,'''
4-43: Save the two top Black stones.
Black 1 starts chasing in shicho.
At White 8, Black 5 is in atari, but...
Ignore it: Black 9 lets White 10 capture.
Black 11 pushes from behind. White is still in atari.
Black 13 changes direction, continuing shicho to capture.
White 2 captures Black.
Starting with Black 1's atari cannot capture White.
Black 3 can repair the shape, but...
A more profitable move exists.
Black 1's geta lets White 2 capture Black first.
Better shape, but a more profitable move exists.
Black 1 attacks this White, but loses the semeai by 4.
Black 3 still has a capturing tesuji, but Black 1 fails.
White 2 extends centrally after Black 1. Black is worse.
Even if Black 3 and 5 attack, White 6 cuts.
Even saving the top Blacks leaves Black in poor shape.
''')
add(194,'''
4-44: Attack White and prevent life.
Black 1 removes White's central eye.
White 2 gives atari, but Black 3 takes two Whites.
White 4 is good, catching Black in snapback, but...
Capture anyway at Black 5. White 6 recaptures, but...
Black 7 cuts underneath. White △ cannot escape.
Now White cannot make even one eye in the corner.
White cannot live.
White 2 captures. You missed the chance.
Black 1 takes two Whites. White 2 gets a centre eye.
Points 3 and 4 are miai. White lives.
Removing the top eye lets White 2 get a central eye.
Even if Black 3 captures White...
White recaptures by snapback and lives.
''')
add(195,'''
4-45: Attack White and prevent life.
Black 1's placement is vital.
White 2 resists best. Black 3 makes this eye false.
White 4 and point 5 are miai: no eye here.
If White 2 defends here, Black 3 ataris four Whites.
White's eye at A is destroyed, so White fails.
White 2 lives.
''')
add(196,'''
4-46: Attack White and prevent life.
Black 1's throw-in creates a shortage of White liberties.
If White 2 captures, Black 3 cuts. White cannot touch Black.
White 2 takes the vital point and lives.
Simply attacking at Black 1 lets White 2 take life's key point.
Black 1's cut needs preparation. White 2 lives.
Black 1 attacks straightforwardly.
White 2 answers for ko, but that is not enough for Black.
''')
add(197,'''
4-47: Find the right attack on White.
Black 1's throw-in is the correct tesuji.
If White 2 captures, Black 3 pushes out.
If White 4 and 6 cut off Black on the right...
Black 7 makes the top eye false.
White 2 resists Black 1 well. Ko is the correct result.
White 2 lives.
Simply removing this eye lets White 2 and 4 make one right.
Even if Black 5 takes, White 6 makes a top eye too.
''')
add(198,'''
4-48: Attack White and prevent life.
Ignore the two Blacks in atari. Black 1 is vital.
Let White 2 capture, then block at Black 3.
If White 4 secures a right eye, Black 5 cuts with atari left.
Black can capture White by 7.
If White 4 defends against Black 3, throw in at 5.
The corner is not seki. White must take three Blacks.
That makes three-point nakade: one White eye.
White 2 lives.
Cutting directly at Black 1 lets White 2 capture and live.
White 2 and 4 catch Black 1 in oiotoshi.
White 2 answers Black 1's move.
White has a central eye now and is alive.
''')
add(199,'''
4-49: Make Black at the top live.
Black 1's placement is vital for life.
White 2 connects. Black 3 captures in sente for a top eye.
Black 5 captures for a second eye and lives.
If White 2 removes Black's central eye...
Black 3 cuts and 5 makes an eye in the corner.
Black lives this way too.
White 2 answers. You missed the chance to live.
Securing the centre at Black 1 lets White 2 connect.
Even if Black 3 plays inside, White 4 connects and kills.
Black 1 captures, but White 2 removes the centre eye.
Even if Black 3 plays inside, White 4 answers.
A is a false eye, and there is no corner eye.
White 2 answers Black 1 and removes Black's way to live.
Black 1 serves no purpose.
White 2 is good and removes Black's way to live.
White 2 connects the top after Black 1. Black cannot live.
''')
add(200,'''
4-50: Make Black at the top live.
Ignore both ataris. Descending at Black 1 is the only life.
Lose four Blacks left, then Black 3 cuts underneath.
This is ishi-no-shita, under the stones. It makes a left eye.
Black 5 does the same on the right for a second eye and life.
White 2 captures. Black cannot live.
Taking on the left at Black 1 makes one eye. White 2 captures.
White 2 captures after Black 1. You missed the chance to live.
''')
