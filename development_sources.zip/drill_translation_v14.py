"""Problem sets 2-4: one-line headers and indexed spoken feedback."""
TEXT={}
def add(k,s):TEXT[k]=s.strip().splitlines()
add(51,'''
2-01: Answer White's invasion.
Answer from this side with Black 1.
Answer White 2 by defending here at Black 3.
Even if White 4 cuts, Black 5 gets out safely.
White 2 breaks through. This is bad for Black.
Blocking at Black 1 lets White extend at 2.
A and B become miai. Black is in trouble.
''')
add(52,'''
2-02: Break through White's enclosure.
Black 1 and 3 punish White's overplay and break out.
White 2 connects and seals Black in.
''')
add(53,'''
2-03: Punish White's triple hane.
Black 1 is double atari. A central ponnuki succeeds.
White 2 gives double atari. Black has failed.
Trading Black 1 for White 2 lets White's overplay work.
White 2 defends against Black 1.
Black needs 3, so White 4 catches Black in shicho.
White's overplay has worked.
Black 1 is too timid. White 2 defends successfully.
''')
add(54,'''
2-04: Break through to the centre.
Black 1 and 3 are good cutting moves.
If White defends at 4, Black 5 and 7 escape.
White 2 blocks. This is bad for Black.
A possible move, but White 2 prevents a breakout.
White 2 prevents escape in this direction.
It is also hard to reach the centre.
''')
add(55,'''
2-05: Punish White's overplay and escape.
Black 1 and 3 break through this way.
White 2 answers. Black cannot reach the centre.
Trying Black 1 and 3 risks a cut at White 4.
White 2 blocks Black 1.
Black 3 remains, but White 4 and 6 make escape hard.
White 2 cuts. Black 3, White 4: Black is trapped.
Black 3 here is possible, but White 4 gets a ponnuki.
This fails.
White 2 answers Black 1.
''')
add(56,'''
2-06: Protect Black's top-side territory.
Black 1's atari is vital preparation.
If White 2 connects, Black 3 catches a stone and defends.
White 2 answers and breaks through the top.
White 2 answers and lives along the top.
Simply catching at Black 1 lets White 2 and 4 break out.
Connecting at Black 1 lets White 2 live inside Black's area.
Black 1 is poor technique. White 2 makes A and B miai.
''')
add(57,'''
2-07: Answer White's attempted cut.
Black 1 gives way. White 2, Black 3: Black connects.
After White 2, Black cannot connect.
''')
add(58,'''
2-08: Exploit the kosumi; connect Black.
Black 1's hane is the key. The top is connected.
White 2 answers and prevents the connection.
''')
add(59,'''
2-09: Punish the cut and connect Black.
Cut at Black 1, then take these White stones at 3.
White 2 connects. Black cannot join up.
''')
add(60,'''
2-10: Save the two Black stones on top.
Black 1's cut exploits White's weakness.
If White escapes at 2, Black 3 captures.
If White 2 connects, Black at the top cannot be saved.
''')
add(61,'''
2-11: Exploit White 1's weakness.
Black 1 has a chance to push through.
By Black 5, White is captured at its base.
White 2 answers. You missed the chance.
''')
add(62,'''
2-12: Counter White's overextended move.
Black 1 hanes out. By 7, White's corner is reduced.
White 2 answers your move.
''')
add(63,'''
2-13: Counterattack White's block.
There is no need to overthink it.
Cut with Black 1, then catch one stone at 3.
If White 2 connects, Black cannot succeed.
''')
add(64,'''
2-14: Save Black from White's cut.
Black 1's bulge forces a reply in sente.
White 2 is forced. Black 3 catches a stone and connects.
White 2 prevents Black from escaping.
Catching at Black 1 is premature. White 2 and 4 break out.
Connecting at Black 1 lets White 2 cut at the base.
White 2 connects. Black 3 and White 4 are miai: no link.
''')
add(65,'''
2-15: Punish White's double hane.
Black 1 and 3 cut White. White △ is damaged.
White 2 pulls back. You missed the chance.
Black 1 is solid, but White 2 retreats safely.
Black 1 and 3 are severe, but White 4 and 6 counter.
Black 1 blocks hard, but White can counter at 2 and 4.
''')
add(66,'''
2-16: Save the three Black stones on top.
Black 1 connects underneath. White 2, then Black 3 to 5.
White 2 answers and prevents the connection.
White 2 and 4 attach and cut. Black cannot connect.
White 2 and 4 turn this into ko.
''')
add(67,'''
2-17: Join Black's top and corner groups.
Black 1's keima is the tesuji.
If White 2 makes contact, give way at Black 3.
By Black 7, Black is connected.
White 2 prevents Black from connecting.
Black 1 and 3 are too direct. White 4 and 6 cut.
Black 1 needs more thought. White 2 cuts.
Black 1 has good shape, but White 2 cuts.
White 2 answers Black 1. You cannot cut here.
''')
add(68,'''
2-18: Connect the top Black to the centre.
Black 1's wedge is tesuji. Answer White 2 at 3.
White 4 is forced. Black 5 connects.
White 2 cuts. Black at the top cannot live.
Black 1 allows White 2 to cut. The top Black dies.
''')
add(69,'''
2-19: Save the surrounded Black stones.
Start at Black 1, sacrificing the two top stones.
Black 5 connects to the outside.
White 2 answers. Black cannot be saved.
White 2 resists. Black 5 and White 6 are miai: no link.
Black 1 has good shape, but cannot connect by White 4.
Black 1 is sharp tesuji, but White 2 answers.
White 4 answers Black 3. Points 5 and 6 are miai: no link.
''')
add(70,'''
2-20: Rescue Black at the top.
Black 1's contact move is good.
White 2 is forced. Black 3 connects underneath.
White 2 defends. You missed the chance.
Cutting directly at Black 1 lets White evade at 2.
White 2 answers Black 1.
''')
add(71,'''
2-21: One-space pincer joseki. Next move?
Black 1 extends; 3 seals White in and builds thickness.
White 2 is bad for Black.
Black 1's kosumi cannot fully stop White 2.
Black 1 attaches, but White 2 and 4 leave wall defects.
White 2 gets out in answer to Black 1.
''')
add(72,'''
2-22: One-space pincer joseki. Next move?
Black 1's extension is vital. White 6 settles things.
White 2 hanes against Black.
Black 1's hane is wrong. White 2 and 4 cut badly.
Even if Black 5 and 7 resist, White 10 crushes Black.
Black 1 and 3's hane-tsugi is sometimes possible...
But it is usually not urgent.
White 2 jumps. Black's shape is a little weak.
''')
add(73,'''
2-23: Star-point approach. Black next?
Black 1 is a little narrow, but offers solid play.
A high keima framework. This is joseki.
A calm two-space extension. This is joseki.
White 2 pincers Black.
Black 1 is still small. White 2 pincers.
Even if White 2 blocks, Black 1 is not very good.
Black 1 only strengthens White.
Black 1 is too solid. White 2 pincers.
Black 1 is interesting, but White 2's pincer is cramped.
A large keima extension does not settle Black well.
A framework on the second line is too low.
This is an unnatural framework. Black is worse.
''')
add(74,'''
2-24: Attacking joseki. Black's next move?
Black 1 must defend this corner.
Answer White 2 by continuing the attack at Black 3.
Black 1 attacks severely.
Answer White 2 by continuing the attack at Black 3.
Black 1 is unusual, but the attack is promising.
White 2's attachment helps White settle.
White 2 jumping out is also bad for Black.
Black 1 and 3's hane-tsugi only strengthens White.
Black 1 is passive. White settles easily by 8.
Black 1 leaves A and B weak. The attack lacks force.
White 2 gets out in answer to Black 1.
Black 1 has many defects and gives White ways to settle.
White 2 extends. Black 1 has strengthened White.
''')
add(75,'''
2-25: Tsuke-nobi joseki. Black next?
Black 1 stops a corner invasion. Defending at 3 is joseki.
Black 3 could instead develop widely on the right.
White 2 aims at A.
White 2 sliding underneath is also bad for Black.
Black 1's cut fails. White 2 and 4 capture it.
Black 1 is a bad move.
When Black 3 blocks, White 4 and 6 push out and cut.
Black 1 is timid. Black's shape is weak.
Black 1 leaves too many weaknesses.
Black 1 is unusual and leaves a weak shape.
Black 1 is too thin. White can aim at A or B.
White 2 enters the corner after Black 1.
White 2 connects and grows strong. A bad move.
''')
add(76,'''
2-26: Answer the 3-3 invasion joseki.
Black 1's extension is vital. By 5, good thickness in gote.
White 2's hane is bad for Black.
Black 1's block is unreasonable.
White 2 and 4 cut both defects, splitting Black apart.
Black 1 and 3 are big, but White 4 takes top influence.
White 2 captures Black 1's cut.
White 2 connects and spoils Black's plan.
Black 1 advances, but White 2 and 4 leave weaknesses.
Black 1 is slack. White 2 develops along the top.
Black 1's extension is big, but White 2 takes the vital point.
''')
add(77,'''
2-27: After the double hane, Black next?
Black 1 captures: corner territory traded for a ponnuki.
White 2 takes the key point.
Black 1 and 3 lose corner territory and strengthen White.
Black 1 is indecisive. White 2 answers and Black fails.
''')
add(78,'''
2-28: One-space pincer joseki. Next move?
Crawl once at Black 1, then jump at 3.
Later, Black can aim to wedge at A.
White 2's block is bad for Black.
Jumping at Black 1 loses three stones by White 8.
Black 1 is low. White 2 presses down from above.
After Black 1 and 3 this way, White 4's block is big.
The 3-3 invasion at A also remains in the corner.
White 2 answers Black 1.
Black 1 is premature. White 2 to 4 block it.
Black 1's cut is unreasonable.
White 2 defends and captures the cutting stone by 6.
Black 1's attachment is unreasonable.
White 2 defends. By 6, White has grown strong.
White 2 answers Black 1's peep. It is not very good.
Black 1 is a useful probe, but White 2 may resist.
Black will probably connect underneath at 3.
''')
add(79,'''
2-29: Answer White's attach-and-pull-back.
Black 1 descends. White extends to 2 or A in joseki.
White 2 hanes against Black.
A solid, simple defence can be useful...
But normally it is a little generous in territory.
Useful for defence, but normally too generous.
Black 1 is indecisive. White 2 extends.
Black 1's hane fails. White 4 and 6 break through.
White 2 answers Black 1, only strengthening White.
''')
add(80,'''
2-30: Pincer joseki. Answer White 6.
Black 1 catches one stone. This is joseki.
White 2's atari is bad for Black.
Black 1 is careless. White 2 breaks through and crushes.
White 2 answers Black 1.
Black cannot block at 3.
Black 1's outward hane is unreasonable.
White 2 cuts. Black 3's atari meets double atari at 4.
White 2 invades at 3-3. Black's result is below joseki.
''')
add(81,'''
2-31: Exploit White's weakness and cut.
Black 1 is vital. If White 2 connects, cut at 3 and 5.
White 2 connects White's groups.
White 4 answers Black 3.
White 2 evades Black 1 and connects by 4.
White 2 captures Black 1. That is all.
''')
add(82,'''
2-32: Exploit White's weakness and cut.
Black 1 is tesuji. White 2 connects, but Black 3 cuts.
White 2 defends and connects White.
''')
add(83,'''
2-33: Save Black's key stones to cut White.
Start moving with Black 1.
After White 2, cut at Black 3 and escape with 5 and 7.
White 2 prevents Black's escape.
Black 1 runs into White 2's crane's-nest tesuji and dies.
Trying to escape at Black 1 is captured by White 2.
''')
add(84,'''
2-34: Exploit White's weakness and cut.
Sacrifice Black 1's cut, then separate White at 3 and 5.
White 2 connects.
Black 1's outward hane gives White time to cut at 2.
White connects by 4.
Black 1's cut fails. White connects by 4.
''')
add(85,'''
2-35: Exploit White's weakness and cut.
Black 1's attachment followed by 3 is tesuji.
White 4 and Black 5 are miai: the top is cut off.
White 2 connects.
Black 1 looks vital, but White 2 connects the main group.
Black 7 takes a stone, but you can gain more.
White 2 connects in answer to Black 1.
''')
add(86,'''
2-36: Destroy White's eyes to kill.
Black 1 offers a large sacrifice.
Answer White 2 with Black 3's throw-in: a false eye.
Answer White 4 at Black 5. White has just one eye.
White 2 captures and lives.
White 2 makes an eye here after Black 1.
White 4 answers Black 3 and has an eye on the right too.
''')
add(87,'''
2-37: Destroy White's eyes to kill.
Black 1's hane and 3's throw-in make a top false eye.
Allowing White 2 lets White live.
Starting with Black 1's throw-in leads to ko by 5.
Black 1 needs more thought. White 2 and 4 simply live.
Even if Black 1 pushes out, White 2 gets a top eye.
White 4 answers Black 3 and gets a central eye too.
''')
add(88,'''
2-38: Destroy White's eyes to kill.
Black 1's attachment is the vital point.
A is a false eye, so White has just one eye.
White 2 lives.
Black 1's attack takes an unnecessary detour.
White 2 defends, leading to ko.
Attacking here with Black 1 fails.
The centre is already a false eye. White 2 lives.
''')
add(89,'''
2-39: Destroy White's eyes to kill.
First, strike the vital point at Black 1.
White 2, Black 3's throw-in: a false eye leaves one eye.
White 2 lives.
Black 1 makes a central false eye, but...
White 2 answers and lives entirely along the top.
Black 1 needs more thought. White 2 lives easily.
''')
add(90,'''
2-40: Destroy White's eyes to kill.
Black 1 enters and makes the right eye false.
The left side has only one eye as it stands.
White 2 answers and lives.
''')
add(91,'''
2-41: Exploit White's weakness to kill.
Cut with Black 1.
White 2 connects. Black 3 descends; the two Blacks are safe.
Black can take White on the right, so White is dead.
White 2 defends and lives.
''')
add(92,'''
2-42: Exploit White's weakness to kill.
Black 1 is the vital point.
White 2 connects. Sacrifice Black 3 for three-point nakade.
White 2 lives.
''')
add(93,'''
2-43: Make Black live.
Black 1 gives atari against the lone White from this side.
White 2 connects. Black 3 captures for a true eye.
White 2 moves. Capturing White at the top makes a false eye.
Black 1's double atari lets White move at 2.
Even capturing White, the top eye is false.
After Black 1, White 2 prevents an eye at the top.
''')
add(94,'''
2-44: Make Black live.
Black 1 is vital. White 2 captures four stones, but...
Black 3 recaptures. The main group lives with two eyes.
White 2 extends and Black cannot live.
Even capturing at Black 1, White 2 extends and kills.
Black is dead even without White 4.
''')
add(95,'''
2-45: Make Black live.
Black 1 protects the top.
White 2, Black 3: make a central eye and live.
If White 4, Black 5 captures. This is not a false eye.
White 2 defends and Black cannot live.
''')
add(96,'''
2-46: Reduce White's top territory.
Black 1 jumps inside.
If White 2 blocks, Black 3 enters the centre.
If White 2 stops the upper route, Black 3 enters the top.
White 2 blocks Black.
Black 1 is tesuji, but White 2 and 4 stop it.
Black 1 is clever, but White 2 and 4 stop it.
White 2 blocks Black 1.
Black 3's pincer attachment does not work.
White 2 answers Black 1 and spoils the plan.
''')
add(97,'''
2-47: Reduce White's top territory.
Black 1's large keima slide reduces in sente by White 8.
Black 1's kosumi reduces greatly in sente by White 6.
White 2 blocks Black.
White 2 can stop Black 1's slide.
You can reduce a little more.
White 2 and 4 stop Black 1's jump completely.
Black 1 is passive.
Aiming at White's defects has no immediate effect.
White 2 protects a large top area.
White 2 answers Black 1 and spoils the plan.
''')
add(98,'''
2-48: Reduce the top, even in gote.
Black can enter as far as 1.
White 2, Black 3 pulls back. Yose at A remains.
White 2 descends against Black.
Black 1 is a large diagonal move.
It can gain sente in some cases, but fails here.
''')
add(99,'''
2-49: Reduce the top, even in gote.
Black 1 is tesuji. After hane at 3, neither A nor B works.
White 2 extends, leaving Black no foothold.
White 2 captures Black 1, leaving no foothold.
Trying to escape at Black 1 does not work.
''')
add(100,'''
2-50: Reduce the top, even in gote.
Black 1 is tesuji.
Answer White 2 at Black 3 and all is well.
White 2 descends against Black.
Black 1 falls short. White 2 extends.
Black 1 cannot escape. White 2 answers.
White 2 captures Black 1.
''')
