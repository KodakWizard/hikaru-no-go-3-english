﻿from pathlib import Path
from textures import resources
for p in Path('translation_work/decoded').rglob('*.bin'):
 try:
  b=p.read_bytes();n=int.from_bytes(b[12:16],'big')
  if n>10000:continue
  names=[s for s,o in resources(b) if s in ('sco10_00.D4','lic00.D4','fai22.D4','brs02_0.D4')]
  if names:print(str(p),names)
 except:pass
