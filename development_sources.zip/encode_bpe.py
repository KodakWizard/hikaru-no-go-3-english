"""Block BPE encoder using unused byte codes; independent decoder roundtrip."""
from collections import Counter
from decode_bpe import decode

def encode(data, block_size=4096):
 out=bytearray(len(data).to_bytes(4,'big'))
 for start in range(0,len(data),block_size):
  original=data[start:start+block_size];packed=original
  left=list(range(256));right=[0]*256
  free=[c for c in range(256) if c not in set(original)]
  for code in free[:64]:
   if len(packed)<4:break
   pairs=Counter(zip(packed,packed[1:]));pair,count=pairs.most_common(1)[0]
   if count<4:break
   a,b=pair;new=packed.replace(bytes((a,b)),bytes((code,)))
   if len(packed)-len(new)<3:break
   left[code]=a;right[code]=b;packed=new
  table=bytearray()
  for lo in (0,128):
   table.append(127)
   for c in range(lo,lo+128):
    table.append(left[c])
    if left[c]!=c:table.append(right[c])
  if len(table)+len(packed)>=4+len(original):
   table=bytearray([254,127,254,255]);packed=original
  out.extend(table);out.extend(len(packed).to_bytes(4,'big'));out.extend(packed)
 assert decode(out)==data
 return bytes(out)

if __name__=='__main__':
 import random
 rng=random.Random(2718)
 cases=[b'',b'A',b'A'*20000,bytes(range(256))*40,bytes(rng.randrange(256) for _ in range(20000)),(b'abcd'*5000)+b'\x00'*20000]
 for b in cases:
  c=encode(b);assert decode(c)==b
  print(len(b),len(c))
