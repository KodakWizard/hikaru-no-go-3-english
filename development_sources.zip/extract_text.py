"""Export Japanese string candidates with byte offsets for translation work."""
from pathlib import Path
import re,json,csv
root=Path('translation_work');rows=[]
pattern=re.compile(rb'(?:[\x81-\x9f\xe0-\xef][\x40-\x7e\x80-\xfc]|[\x20-\x7e\x0a\x0d]){2,}')
files=[root/'main.dol']+list((root/'extracted/script').rglob('*.gcs'))
for p in files:
 b=p.read_bytes()
 for m in pattern.finditer(b):
  if p.name=='main.dol' and m.start()<0x22d420:continue
  raw=m.group()
  try:s=raw.decode('cp932')
  except UnicodeDecodeError:continue
  if sum('\u3040'<=c<='\u30ff' for c in s)<2:continue
  if len(s)>1000:continue
  # Candidate extraction only: machine code/operands can mimic Shift-JIS.
  rows.append(dict(file=str(p.relative_to(root)).replace('\\','/'),offset=f'{m.start():08X}',byte_length=len(raw),japanese=s,english='',raw_hex=raw.hex(),status='candidate; review context'))
out=root/'text';out.mkdir(exist_ok=True)
with (out/'japanese_candidates.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(out/'japanese_candidates.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
print('Candidates:',len(rows),'Files:',len(set(r['file'] for r in rows)))
print('Script candidates:',sum(r['file'].startswith('extracted/script') for r in rows))
