﻿from pathlib import Path
import json
from textures import resources,texture
from PIL import Image
root=Path('.');latest=root/'English_Menu_v09';r=json.loads((latest/'build_report.json').read_text(encoding='utf8'));meta=json.loads(Path('translation_work/disc_metadata.json').read_text())
translations={}
for d,k in [('English_Menu_POC','text_changes'),('English_Story_v02','dialogue'),('English_Story_v03','edits'),('English_Menu_v04','text'),('English_Menu_v05','text'),('English_Interface_v08','text_checks'),('English_Menu_v09','edits')]:
 report=json.loads((root/d/'build_report.json').read_text(encoding='utf8'))
 for e in report[k]:
  off=e.get('offset',e.get('dol_offset'));off=int(off,16) if isinstance(off,str) else off;translations[off]=e['english']
with (latest/'Hikaru no Go 3 - English Menu v09.iso').open('rb') as f:
 f.seek(meta['dol_offset']);dol=f.read(Path('translation_work/main.dol').stat().st_size)
for o,en in translations.items():assert dol[o:dol.index(0,o)]==en.encode('cp932'),hex(o)
new=sum(e['offset'] not in set(x['offset'] for x in []) for e in [])
ledger_path=Path('translation_work/COVERAGE.json');ledger=json.loads(ledger_path.read_text(encoding='utf8'));ledger['latest_build']='English_Menu_v09';ledger['dol']['translated_occurrences']=len(translations);ledger['dol']['verification']='Unique translation offsets from all build reports read back from v0.9 ISO; includes empty generated honorific suffixes.';ledger['runtime']['v09']='Pending user Dolphin test: copyright, GBA port/menu labels, and card prompts.';ledger['menu_v09']={'text_updates':r['text_edits'],'graphic_updates':r['graphic_edits'],'card_templates_corrected':r['card_regression']['fixed_template_count'],'card_regression_cases':r['card_regression']['slot_and_data_type_tests'],'title_logo_preserved':True,'full_game_complete':False};ledger_path.write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf8')
p=Path('translation_work/COMPLETION_PLAN.md');s=p.read_text(encoding='utf8');s+='\n## v0.9 menu/card pass\n\nUser prefers the v0.8.1 illustrated title. v0.9 preserves that logo, translates the separate copyright overlay and additional menu/GBA assets, and corrects the in-place card-format bug (29 templates / 232 model cases). See its README for Dolphin checks. Composite score glyph atlases and the broader script/dialogue work remain outstanding.\n';p.write_text(s,encoding='utf8')
print('Unique executable translation offsets verified:',len(translations));print('Card cases',r['card_regression']['slot_and_data_type_tests'],'BPS reconstruction',r['patch']['bps_verified']);print('ISO SHA256',r['output_sha256'])
