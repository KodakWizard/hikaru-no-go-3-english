﻿from pathlib import Path
p=Path('ui_translation_v08.py');s=p.read_text(encoding='utf8').replace("'Main Hall'","'MainHall'").replace("'Insei Test'","'Insei Exam'").replace("'Haze School'","'Haze Jr.'").replace('"Let\'s have a good game."',"'Have a good game.'").replace('"All right,↓I\'ll take Black."','"Okay,↓I\'ll take Black."')
s=s.replace("'Insei Exam'","'Insei'");p.write_text(s,encoding='utf8')
