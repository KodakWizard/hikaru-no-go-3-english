﻿from pathlib import Path
p=Path('menu_translation_v09.py');s=p.read_text(encoding='utf8')
changes={'The selected controller is not connected.':'Selected controller is disconnected.','Play a two-on-two match.':'Play a 2-on-2 match.','Excellent!':'Superb!','Play 3-Choice Go with Sai.':'3-Choice Go vs. Sai.',"Set the opponent's level.":"Set opponent level.",'Play Go with Sai.':'Play with Sai.','Choose the stones, board and background.':'Choose stones, board and background.','Choose the GBA controller port.':'Choose the GBA port.','Match results and play time.':'Results and play time.'}
for a,b in changes.items():s=s.replace(a,b)
p.write_text(s,encoding='utf8')
