"""Half-texel inset for the outlined CFont ASCII path only; no font resizing."""
import json,struct
from pathlib import Path
from name_display_v08 import branch
def patch(dol,original,blocked):
 caves=json.loads(Path('translation_work/ui_v08/name_caves.json').read_text());used=set(blocked);words={};ranges=[]
 def allocate(size):
  for lo,hi in caves:
   for at in range((lo+3)&~3,hi-size+1,4):
    if any(a in used for a in range(at,at+size,4)) or dol[at:at+size]!=bytes(size):continue
    assert all((a+0x80003000).to_bytes(4,'big') not in original[0x22d420:] for a in range(at,at+size,4))
    used.update(range(at,at+size,4));ranges.append((at,at+size));return at+0x80003000
  raise AssertionError('No unused verified translated-string tail')
 const=allocate(8);struct.pack_into('>ff',dol,const-0x80003000,0.5/192,0.5/384)
 def d(op,rt,ra,imm):return op<<26|rt<<21|ra<<16|(imm&65535)
 nodes=[d(32,12,1,0x24),d(15,11,0,0x800a),d(24,11,11,0x26e4),0x7c0c5800,'gate',d(15,11,0,(const+0x8000)>>16),d(48,5,11,const&65535),d(48,6,11,(const+4)&65535)]
 fields=[(0x48,6,1),(0x50,6,1),(0x58,6,-1),(0x60,6,-1),(0x54,5,1),(0x64,5,1),(0x4c,5,-1),(0x5c,5,-1)]
 for off,fr,sign in fields:nodes.extend([d(48,0,6,off),(59<<26)|(fr<<11)|((21 if sign>0 else 20)<<1),d(52,0,6,off)])
 nodes.append('tail');addresses=[allocate(12 if n=='gate' else 4 if n=='tail' else 8) for n in nodes]
 for i,(at,node) in enumerate(zip(addresses,nodes)):
  if node=='gate':words[at]=0x41820008;words[at+4]=branch(at+4,0x8021d03c);words[at+8]=branch(at+8,addresses[i+1])
  elif node=='tail':words[at]=branch(at,0x8021d03c)
  else:words[at]=node;words[at+4]=branch(at+4,addresses[i+1])
 for at,w in words.items():struct.pack_into('>I',dol,at-0x80003000,w)
 hook=0x800a4108;at=hook-0x80018ba0+0x2620;assert int.from_bytes(dol[at:at+4],'big')==branch(hook,0x8021d03c,True);struct.pack_into('>I',dol,at,branch(hook,addresses[0],True))
 # Run the actual helper words against all 256 glyph-grid positions for both
 # caller paths, with single-precision arithmetic and original memcpy ABI.
 count=0
 for caller in (0x800a26e4,0x800a1d68):
  for y in range(16):
   for x in range(16):
    reg=[0]*32;fp=[0.0]*32;reg[1]=0x10000;reg[3:7]=[0x30000,0x40000,2,0x20000];mem={};eq=False;pc=addresses[0]
    def put(a,v):
     for j,c in enumerate(v):mem[a+j]=c
    def get(a):return bytes(mem.get(a+j,0) for j in range(4))
    def f32(v):return struct.unpack('>f',struct.pack('>f',v))[0]
    put(reg[1]+0x24,caller.to_bytes(4,'big'));put(const,struct.pack('>ff',0.5/192,0.5/384));values={0x48:y/16,0x50:y/16,0x58:(y+1)/16,0x60:(y+1)/16,0x54:x/16,0x64:x/16,0x4c:(x+1)/16,0x5c:(x+1)/16}
    for off,v in values.items():put(reg[6]+off,struct.pack('>f',v))
    for step in range(1000):
     if pc==0x8021d03c:break
     w=words[pc];op=w>>26;rt=w>>21&31;ra=w>>16&31;rb=w>>11&31;imm=w&65535;imm=imm-65536 if imm&32768 else imm;nxt=pc+4
     if op==32:reg[rt]=int.from_bytes(get(reg[ra]+imm),'big')
     elif op==15:reg[rt]=(imm<<16)&0xffffffff
     elif op==24:reg[ra]=reg[rt]|(w&65535)
     elif w==0x7c0c5800:eq=reg[12]==reg[11]
     elif op==48:fp[rt]=struct.unpack('>f',get(reg[ra]+imm))[0]
     elif op==52:put(reg[ra]+imm,struct.pack('>f',fp[rt]))
     elif op==59:fp[rt]=f32(fp[ra]+fp[rb] if ((w>>1)&31)==21 else fp[ra]-fp[rb])
     elif op==16:
      assert w==0x41820008
      if eq:nxt=pc+8
     elif op==18:
      delta=w&0x3fffffc;delta=delta-(1<<26) if delta&(1<<25) else delta;nxt=pc+delta
     else:raise AssertionError(hex(w))
     pc=nxt
    else:raise AssertionError('Helper did not tail-call memcpy')
    assert reg[3:7]==[0x30000,0x40000,2,0x20000] and reg[1]==0x10000
    for off,fr,sign in fields:
     expect=values[off]
     if caller==0x800a26e4:expect=f32(expect+sign*f32(0.5/(192 if fr==5 else 384)))
     assert struct.unpack('>f',get(reg[6]+off))[0]==expect
    count+=1
 return dict(hook=hex(hook),entry=hex(addresses[0]),caller_guard='Saved LR must equal 0x800a26e4 (outlined CFont setter)',ascii_only=True,dialogue_caller_excluded='0x800a1d68',font_assets_unchanged=True,half_texel_inset=[0.5/192,0.5/384],ppc_grid_tests=count,reclaimed_words=[hex(a) for lo,hi in ranges for a in range(lo,hi,4)],ranges=ranges,words={hex(a):hex(w) for a,w in words.items()},status='Sampling bleed mitigation; Dolphin comparison required')
