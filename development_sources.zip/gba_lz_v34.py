"""Native GBA 0x10 LZ decoder/encoder; no runtime code changes."""
from collections import defaultdict,deque

def decode(b):
    assert b[0]==0x10
    n=int.from_bytes(b[1:4],'little');out=bytearray();p=4
    while len(out)<n:
        flags=b[p];p+=1
        for bit in range(7,-1,-1):
            if len(out)>=n:break
            if flags&(1<<bit):
                a,z=b[p:p+2];p+=2;length=(a>>4)+3;distance=((a&15)<<8|z)+1
                assert distance<=len(out) and len(out)+length<=n
                for _ in range(length):out.append(out[-distance])
            else:out.append(b[p]);p+=1
    return bytes(out)

def encode(b):
    b=bytes(b)
    out=bytearray(b'\x10'+len(b).to_bytes(3,'little'));p=0;seen=defaultdict(deque)
    while p<len(b):
        flag_at=len(out);out.append(0);flags=0
        for bit in range(7,-1,-1):
            if p>=len(b):break
            best=0;back=0;key=b[p:p+3];q=seen[key]
            while q and q[0]<p-4096:q.popleft()
            for at in reversed(q):
                n=3
                while n<min(18,len(b)-p) and b[at+n]==b[p+n]:n+=1
                if n>best:best=n;back=p-at
                if n==18:break
            if len(key)<3:best=0
            consumed=best if best>=3 else 1
            if best>=3:
                flags|=1<<bit;v=(best-3)<<12|(back-1);out.extend(v.to_bytes(2,'big'))
            else:out.append(b[p])
            for at in range(p,p+consumed):seen[b[at:at+3]].append(at)
            p+=consumed
        out[flag_at]=flags
    out.extend(b'\0'*((-len(out))%4))
    assert decode(out)==b
    return bytes(out)

def encode_optimal(b):
    """Shortest stream, including one flag byte per eight tokens."""
    b=bytes(b);n=len(b);seen=defaultdict(deque);matches=[]
    for p in range(n):
        key=b[p:p+3];q=seen[key]
        while q and q[0]<p-4096:q.popleft()
        best=0;back=0
        if len(key)==3:
            for at in reversed(q):
                length=3
                while length<min(18,n-p) and b[at+length]==b[p+length]:length+=1
                if length>best:best=length;back=p-at
                if length==18:break
        matches.append((best,back));q.append(p)
    costs=[[0]*8 for _ in range(n+1)];choices=[[1]*8 for _ in range(n)]
    for p in range(n-1,-1,-1):
        length,_=matches[p]
        for phase in range(8):
            nxt=(phase+1)%8;cost=1+costs[p+1][nxt];choice=1
            for size in range(3,length+1):
                v=2+costs[p+size][nxt]
                if v<cost:cost=v;choice=size
            costs[p][phase]=cost+(phase==0);choices[p][phase]=choice
    out=bytearray(b'\x10'+n.to_bytes(3,'little'));p=0
    while p<n:
        flag_at=len(out);out.append(0);flags=0
        for phase in range(8):
            if p>=n:break
            size=choices[p][phase]
            if size==1:out.append(b[p])
            else:
                flags|=1<<(7-phase);back=matches[p][1]
                out.extend(((size-3)<<12|(back-1)).to_bytes(2,'big'))
            p+=size
        out[flag_at]=flags
    assert len(out)-4==costs[0][0]
    out.extend(b'\0'*((-len(out))%4));assert decode(out)==b
    return bytes(out)
