"""Apply reviewed GameCube exercise wording to the corresponding GBA feedback."""
from pathlib import Path
import ast,json,re,hashlib
from gba_lz_v34 import decode,encode_optimal
from qa_research_v10 import current_files
from dialogue_polish_v50 import SCRIPT_REVISIONS
from check_dialogue_v50 import wrap
R=Path(__file__).parent;W=R/'translation_work'
norm=lambda s:re.sub(r'\s+',' ',s.replace('\u2193',' ')).strip()

# Load the already verified native pool and independent LZ functions without
# importing the old builder (which would start a historical build).
tree=ast.parse((R/'build_gba_books_v35.py').read_text(encoding='utf8'))
functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('replace_pool','independent_decode')]
exec(compile(ast.Module(body=functions,type_ignores=[]),'v35_verified_pool_helpers','exec'),globals())

def prepare(base):
 sr=json.loads((W/'dialogue_v50/script_unique.json').read_text(encoding='utf8'))
 mapping={(norm(sr[i]['japanese']),norm(sr[i]['english'])):wrap(s,22) for i,s in SCRIPT_REVISIONS.items() if not re.match(r'\d-\d\d:',sr[i]['english'])}
 manifest=json.loads((R/'gba_books_manifest_v35.json').read_text(encoding='utf8'))
 previous=W/'dialogue_v50/gba_prepared/manifest.json'
 cached=json.loads(previous.read_text(encoding='utf8')) if previous.exists() else {}
 preferred_cache={r['book']:tuple(r['placement_strategy']) for r in cached.get('reports',[])}
 f,fst,files=current_files(base);blobs=[];reports=[];changes=[]
 common_paths=[f'gba/dacs/tutocmn/tutorial1_dacs_0_{i}_LZ.bin' for i in range(40)]
 def read(path):
  off,size,_=files[path];f.seek(off);return f.read(size)
 common=b''.join(decode((W/'extracted'/p).read_bytes()) for p in common_paths)
 live_common=b''.join(decode(read(p)) for p in common_paths)
 for book,rr in manifest.items():
  paths=sorted([p for p in files if p.startswith(f'gba/dacs/tutorial{book}_dacs/')],key=lambda p:int(p.split('_')[-2]))
  originals={p:(W/'extracted'/p).read_bytes() for p in paths}
  current={p:read(p) for p in paths}
  decoded={p:decode(originals[p]) for p in paths}
  original=common+b''.join(decoded[p] for p in paths)
  live=live_common+b''.join(decode(current[p]) for p in paths)
  rows=[];book_changes=[]
  for row in rr:
   if row['offset']<len(common):continue
   row=dict(row)
   pp=int.from_bytes(live[row['references'][0]:row['references'][0]+4],'little')-0x09f00000
   before=live[pp:live.index(0,pp)].decode('cp932')
   assert before==row['english']
   new=mapping.get((norm(row['japanese']),norm(before))) if not row['header'] else None
   if new and new!=before:
    row['english']=new
    book_changes.append(dict(area='GBA exercise feedback',book=book,offset=hex(row['offset']),japanese=row['japanese'],before=before,after=new))
   rows.append(row)
  if not book_changes:continue
  preferred={'1':('suffix',True,0),'2':('lex',False,0),'3':('lex',False,8),'4':('lex',False,30),'5':('lex',False,0)}[book]
  preferred=preferred_cache.get(book,preferred)
  strategies=[preferred,('lex',True,0),('suffix',True,0),('length',True,0)]+[('lex',False,i) for i in range(65)]
  for strategy in dict.fromkeys(strategies):
   try:new,report=replace_pool(original,rows,strategy)
   except AssertionError as exc:
    if exc.args and isinstance(exc.args[0],tuple) and exc.args[0][0]=='Cannot fit text in verified original pools':continue
    raise
   cursor=len(common);packed={};excess=0
   for path in paths:
    n=len(decoded[path]);part=new[cursor:cursor+n];cursor+=n
    stream=encode_optimal(part);excess+=max(0,len(stream)-len(current[path]))
    packed[path]=(stream,part)
   print('GBA book',book,'strategy',strategy,'excess',excess,flush=True)
   if not excess:break
  else:raise AssertionError(('GBA revised feedback cannot fit native segments',book))
  # Only verified text-pool storage and its exact direct pointer words may vary.
  allowed=sorted(report['text_pools']+[[p,p+4] for row in rows for p in row['references']])
  def unchanged_outside(a,b):
   cursor=len(common)
   for lo,hi in allowed:
    assert a[cursor:lo]==b[cursor:lo];cursor=max(cursor,hi)
   assert a[cursor:]==b[cursor:]
  unchanged_outside(original,live);unchanged_outside(original,new)
  for path,(stream,part) in packed.items():
   blob=stream+b'\0'*(len(current[path])-len(stream))
   assert decode(blob)==independent_decode(blob)==part
   if part!=decode(current[path]):blobs.append((files[path][0],blob,path,part))
  changes.extend(book_changes)
  reports.append(dict(book=book,revised_entries=len(book_changes),placement_strategy=strategy,native_sizes_preserved=True,only_verified_text_pools_and_pointer_words_changed=True))
 f.close()
 return blobs,reports,changes

if __name__=='__main__':
 blobs,reports,changes=prepare(R/'English_QA_v49/Hikaru no Go 3 - English QA v49.iso')
 print(len(changes),'GBA feedback occurrences;',len(blobs),'segments')
 out=W/'dialogue_v50/gba_prepared';out.mkdir(exist_ok=True)
 manifest=[]
 for i,(off,blob,path,part) in enumerate(blobs):
  (out/f'{i}.bin').write_bytes(blob);(out/f'{i}.decoded').write_bytes(part)
  manifest.append(dict(offset=off,path=path,file=f'{i}.bin',decoded=f'{i}.decoded'))
 revision_hash=hashlib.sha256(json.dumps(SCRIPT_REVISIONS,sort_keys=True,ensure_ascii=True).encode()).hexdigest()
 (out/'manifest.json').write_text(json.dumps(dict(blobs=manifest,reports=reports,changes=changes,revision_hash=revision_hash),ensure_ascii=False,indent=2),encoding='utf8')
