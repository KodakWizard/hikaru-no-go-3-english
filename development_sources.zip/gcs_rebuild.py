"""Rebuild verified GCS text tails, updating only proven string operands."""
import struct,re
from gcs_text import text_tail
from check_tutorial_v07 import wrap

STRING_OPS={0x87,0xa6,0x103}

def rebuild(data,translations,format_text=True,coordinate_operands=False):
 base,start,rows=text_tail(data);assert len(rows)==len(translations)
 starts={r['offset']-base:r for r in rows};refs=[]
 for at in range(base,start,4):
  v=int.from_bytes(data[at:at+4],'big')
  if start-base<=v<len(data)-base:
   op=int.from_bytes(data[at-4:at],'big')
   # Drill instructions 0x19/0x1e carry packed board coordinates. Four
   # observed operands collide numerically with the tail address range.
   # Even an exact string-offset collision must remain an unchanged move.
   if coordinate_operands and op in (0x19,0x1e) and 0<(v>>8)<=19 and 0<(v&255)<=19:continue
   assert v in starts,('unrecognised text-pool address',hex(at),hex(v))
   assert op in STRING_OPS,('unknown string opcode',hex(op))
   refs.append((at,v))
 out=bytearray(data[:start]);remap={};report=[]
 for i,(row,en) in enumerate(zip(rows,translations)):
  if format_text:
   en=wrap(en);assert len(en.split('\n'))<=3,(i,'too many lines',en)
   # Original tutorial strings use LF only. CR renders as a visible dot.
   assert '\r' not in en
   assert sorted(re.findall(r'\$\d|%[sd]',en))==sorted(re.findall(r'\$\d|%[sd]',row['japanese']))
   # Preserve the custom controller glyph present in exercise headings.
   assert en.count('⑪')==row['japanese'].count('⑪')
  remap[row['offset']-base]=len(out)-base
  raw=en.encode('cp932');out.extend(raw+b'\0');out.extend(b'\xcd'*((-len(out))%4))
  report.append(dict(index=i,old_offset=row['offset'],new_offset=base+remap[row['offset']-base],japanese=row['japanese'],english=en,references=row['references']))
 for at,v in refs:struct.pack_into('>I',out,at,remap[v])
 changed={p for at,v in refs for p in range(at,at+4)}
 assert all(a==b for i,(a,b) in enumerate(zip(data[:start],out[:start])) if i not in changed)
 for at,v in refs:
  p=base+int.from_bytes(out[at:at+4],'big');row=starts[v];en=report[rows.index(row)]['english']
  assert out[p:out.index(0,p)].decode('cp932')==en
 return bytes(out),report

def verify_original_roundtrip(data,coordinate_operands=False):
 _,_,rows=text_tail(data)
 rebuilt,report=rebuild(data,[r['japanese'] for r in rows],False,coordinate_operands)
 assert rebuilt==data,'Original GCS must reconstruct byte-for-byte'
