"""Validated text-tail extraction for GCS files with an A6 heading instruction."""
from pathlib import Path
import struct,re

def text_tail(data):
 base=int.from_bytes(data[:4],'big');assert 0<base<len(data) and base%4==0
 candidates=[]
 for at in range(base,min(len(data)-8,base+1024),4):
  if data[at:at+4]!=b'\0\0\0\xa6':continue
  rel=int.from_bytes(data[at+4:at+8],'big');p=base+rel
  if not (base<p<len(data)):continue
  end=data.find(b'\0',p)
  if end<0:continue
  try:s=data[p:end].decode('cp932')
  except UnicodeDecodeError:continue
  if any('\u3040'<=c<='\u9fff' for c in s):candidates.append((p,at+4))
 if not candidates:raise ValueError('No validated A6 heading pointer')
 start,heading_ref=min(candidates);rows=[];p=start
 while p<len(data):
  while p<len(data) and data[p] in (0,0xcd):p+=1
  if p>=len(data):break
  end=data.index(0,p);raw=data[p:end];s=raw.decode('cp932')
  refs=[at for at in range(base,start,4) if int.from_bytes(data[at:at+4],'big')==p-base]
  rows.append(dict(offset=p,end=end,japanese=s,references=refs));p=end+1
 assert rows and rows[0]['offset']==start and heading_ref in rows[0]['references']
 return base,start,rows

if __name__=='__main__':
 import json
 root=Path('translation_work/extracted/script/tutorial');out=Path('translation_work/text/tutorial_verified');out.mkdir(exist_ok=True)
 for p in sorted(root.glob('tuto*.gcs')):
  try:
   base,start,rows=text_tail(p.read_bytes());(out/(p.stem+'.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
   print(p.name,len(rows),'unreferenced',sum(not r['references'] for r in rows))
  except Exception as e:print(p.name,'UNSUPPORTED',e)
