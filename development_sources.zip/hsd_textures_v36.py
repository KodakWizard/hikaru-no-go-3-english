"""Read native model texture descriptors; CMPR byte order preserves GX blocks."""
import struct,io
from PIL import Image
from textures import texture

def descriptors(b):
    total,ds,nr=struct.unpack_from('>III',b)
    assert total==len(b)
    found={}
    for i in range(nr):
        r=int.from_bytes(b[32+ds+4*i:36+ds+4*i],'big');at=32+r
        if at+24>32+ds:continue
        ptr,w,h,fmt,mip=struct.unpack_from('>IHHII',b,at)
        if fmt not in (0,1,2,3,4,5,6,8,9,10,14) or not(8<=w<=1024 and 8<=h<=1024 and w%4==h%4==0) or mip not in (0,1) or ptr>=ds:continue
        size=((w+7)//8)*((h+7)//8)*32 if fmt==14 else ((w+3)//4)*((h+3)//4)*64 if fmt==6 else None
        if size is not None:assert ptr+size<=ds
        key=(ptr+32,w,h,fmt)
        found.setdefault(key,[]).append(at)
    return [dict(start=s,width=w,height=h,format=f,descriptors=v) for (s,w,h,f),v in found.items()]

def rgb565(v):return ((v>>11)*255//31,((v>>5)&63)*255//63,(v&31)*255//31,255)

def decode_cmpr(data,w,h):
    im=Image.new('RGBA',(w,h));pix=im.load();p=0
    for by in range(0,h,8):
        for bx in range(0,w,8):
            for dy,dx in ((0,0),(0,4),(4,0),(4,4)):
                a,z=struct.unpack_from('>HH',data,p);indices=data[p+4:p+8];p+=8
                c0,c1=rgb565(a),rgb565(z)
                if a>z:colors=[c0,c1,tuple((2*c0[k]+c1[k])//3 for k in range(4)),tuple((c0[k]+2*c1[k])//3 for k in range(4))]
                else:colors=[c0,c1,tuple((c0[k]+c1[k])//2 for k in range(4)),(0,0,0,0)]
                for y in range(4):
                    for x in range(4):
                        if bx+dx+x<w and by+dy+y<h:pix[bx+dx+x,by+dy+y]=colors[(indices[y]>>(6-x*2))&3]
    return im

def decode_texture(b,d):
    s,w,h,f=d['start'],d['width'],d['height'],d['format']
    if f==14:return decode_cmpr(b[s:s+w*h//2],w,h)
    if f in (8,9,10):raise ValueError('Palette descriptor required')
    hdr=bytearray(64);struct.pack_into('>HHHHI',hdr,32,f,w,h,0,32)
    if f==6:n=((w+3)//4)*((h+3)//4)*64
    elif f in (3,4,5):n=((w+3)//4)*((h+3)//4)*32
    elif f in (1,2):n=((w+7)//8)*((h+3)//4)*32
    else:n=((w+7)//8)*((h+7)//8)*32
    return texture(bytes(hdr)+b[s:s+n],0)[0]

def encode_cmpr(im):
    """Encode BC1 through Pillow, then reorder endpoints/indices into GX tiles."""
    w,h=im.size;assert w%8==h%8==0
    buf=io.BytesIO();im.convert('RGBA').save(buf,format='DDS',pixel_format='DXT1');dds=buf.getvalue()
    assert dds[:4]==b'DDS ' and dds[84:88]==b'DXT1'
    raw=dds[128:];assert len(raw)==w*h//2
    out=bytearray()
    for by in range(0,h,8):
        for bx in range(0,w,8):
            for dy,dx in ((0,0),(0,4),(4,0),(4,4)):
                p=(((by+dy)//4)*(w//4)+(bx+dx)//4)*8;block=raw[p:p+8]
                out.extend(block[:2][::-1]+block[2:4][::-1])
                out.extend(sum(((v>>(2*x))&3)<<(6-2*x) for x in range(4)) for v in block[4:])
    return bytes(out)
