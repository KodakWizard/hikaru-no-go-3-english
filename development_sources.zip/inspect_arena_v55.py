from pathlib import Path
b=Path('translation_work/main.dol').read_bytes()
for val in [0x80429d98,0x80419d92,0x80429da0,0x81800000]:
 needle=val.to_bytes(4,'big');hits=[];start=0
 while (pos:=b.find(needle,start))>=0:hits.append(hex(pos));start=pos+1
 print(hex(val),hits)
