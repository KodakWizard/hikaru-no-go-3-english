"""Recheck v50 visible-string candidates and native artwork against v49."""
from pathlib import Path
import json, struct, hashlib, re
from qa_research_v10 import current_files
from decode_bpe import decode
from textures import resources,texture
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;W=R/'translation_work/runtime_qa_v51'
f,_,files=current_files(R/'English_Dialogue_v50/Hikaru no Go 3 - English Dialogue v50.iso')
g,_,prev=current_files(R/'English_QA_v49/Hikaru no Go 3 - English QA v49.iso')
art=[];tiles=[]
for path,(off,size,_) in files.items():
    if not path.endswith('.bpe'):continue
    f.seek(off);data=f.read(size);o,n,_=prev[path];g.seek(o);old=g.read(n)
    assert data==old,path
    art.append({'path':path,'stored_bytes':size,'sha256':hashlib.sha256(data).hexdigest(),'exact_v49':True})
    if path not in ('2D/bbg.bpe','2D/win.bpe','title/title.bpe','2D/jfend.bpe'):continue
    dec=decode(data)
    for name,at in resources(dec):
        if not name.endswith('.D4'):continue
        if not (name.startswith(('win43','tit','jfend')) or name.startswith(('bbg13','bbg14','bbg01'))):continue
        im,desc=texture(dec,at);im.thumbnail((390,195))
        tile=Image.new('RGB',(410,225),'#607080');ImageDraw.Draw(tile).text((5,5),path+' '+name,fill='white')
        tile.paste(im,((410-im.width)//2,25),im);tiles.append(tile)
for pg in range((len(tiles)+11)//12):
    batch=tiles[pg*12:(pg+1)*12];sheet=Image.new('RGB',(1230,225*((len(batch)+2)//3)),'#303840')
    for i,tile in enumerate(batch):sheet.paste(tile,((i%3)*410,(i//3)*225))
    sheet.save(W/f'current_art_{pg}.png')
meta=json.loads((R/'translation_work/disc_metadata.json').read_text());f.seek(meta['dol_offset']);dol=f.read((R/'translation_work/main.dol').stat().st_size)
original=(R/'translation_work/main.dol').read_bytes()
sections=[]
for i in range(7):
    off=int.from_bytes(original[i*4:i*4+4],'big');size=int.from_bytes(original[0x90+i*4:0x94+i*4],'big')
    if size:assert dol[off:off+size]==original[off:off+size],i
    sections.append({'section':i,'offset':off,'size':size,'exact_original':True})
candidates=json.loads((R/'translation_work/closure_v48/dol_pointer_candidates.json').read_text(encoding='utf8'))
remaining=[]
for row in candidates:
    p=int(row['offset'],16);end=dol.find(b'\0',p)
    try:s=dol[p:end].decode('cp932')
    except UnicodeDecodeError:continue
    if re.search('[\u3040-\u30ff\u4e00-\u9fff]',s):remaining.append(dict(row,current=s))
(W/'artwork_checks.json').write_text(json.dumps({'archives':art,'native_code':sections,'contact_sheets':(len(tiles)+11)//12},indent=2),encoding='utf8')
(W/'remaining_dol.json').write_text(json.dumps(remaining,ensure_ascii=False,indent=2),encoding='utf8')
(W/'remaining_dol.txt').write_text('\n'.join(str(r['offset'])+' '+repr(r['current']) for r in remaining),encoding='utf8')
print(len(art),'BPE archives exact v49;',len(tiles),'selected graphic previews;',len(remaining),'remaining prior DOL candidates')
f.close();g.close()
