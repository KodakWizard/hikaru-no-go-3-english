from pathlib import Path
import struct,json

ROOT=Path(__file__).resolve().parent
ISO=next(ROOT.glob('*.iso'))
OUT=ROOT/'translation_work'
OUT.mkdir(exist_ok=True)
with ISO.open('rb') as f:
    header=f.read(0x440)
    dol,fst,size=struct.unpack_from('>III',header,0x420)
    print('Disc ID:',header[:6].decode('ascii'),'Title:',header[0x20:0x400].split(b'\0')[0])
    f.seek(fst); table=f.read(size)
    count=struct.unpack_from('>I',table,8)[0]
    strings=table[count*12:]
    stack=[('',count)]; entries=[]
    for i in range(1,count):
        while i>=stack[-1][1]: stack.pop()
        nameword,offset,length=struct.unpack_from('>III',table,i*12)
        n=nameword&0xffffff
        name=strings[n:].split(b'\0')[0].decode('shift_jis',errors='replace')
        path=stack[-1][0]+name
        if nameword>>24: stack.append((path+'/',length))
        else: entries.append(dict(path=path,offset=offset,size=length))
    (OUT/'inventory.json').write_text(json.dumps(entries,indent=2,ensure_ascii=False),encoding='utf8')
    (OUT/'inventory.tsv').write_text('path\toffset\tsize\n'+''.join(f"{e['path']}\t{e['offset']:08X}\t{e['size']}\n" for e in entries),encoding='utf8')
    for e in entries:
        p=OUT/'extracted'/e['path']; p.parent.mkdir(parents=True,exist_ok=True)
        f.seek(e['offset']); p.write_bytes(f.read(e['size']))
    f.seek(dol); dh=f.read(0x100)
    offsets=struct.unpack_from('>18I',dh,0); sizes=struct.unpack_from('>18I',dh,0x90)
    ds=max(a+b for a,b in zip(offsets,sizes))
    f.seek(dol); (OUT/'main.dol').write_bytes(f.read(ds))
    (OUT/'disc_metadata.json').write_text(json.dumps(dict(id=header[:6].decode(),dol_offset=dol,fst_offset=fst,fst_size=size),indent=2))
    print('Files:',len(entries),'Extracted bytes:',sum(e['size'] for e in entries))
    for e in entries: print(f"{e['size']:10} {e['path']}")
