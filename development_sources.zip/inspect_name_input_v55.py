from pathlib import Path
import struct
b=Path('translation_work/main.dol').read_bytes()
for lo,hi in [(0x251200,0x251780)]:
 for off in range(lo,hi,16):
  raw=b[off:off+16]
  print(hex(off),raw.hex(' '),raw.decode('cp932','replace'))
for s in ['ＡＢＣ','ａｂｃ','Ａ','名前']:
 needle=s.encode('cp932'); pos=0; hits=[]
 while True:
  pos=b.find(needle,pos)
  if pos<0: break
  if s!='Ａ' or 0x250000<pos<0x252000:hits.append(hex(pos))
  pos+=len(needle)
 print(repr(s),hits[:75])
for target in [0x2512e0,0x251484,0x2514cc,0x2516b0]:
 for i in range(18):
  off,addr,size=(int.from_bytes(b[x+4*i:x+4*i+4],'big') for x in [0,0x48,0x90])
  if off<=target<off+size:ram=addr+target-off;break
 needle=ram.to_bytes(4,'big');pos=0;hits=[]
 while True:
  pos=b.find(needle,pos)
  if pos<0:break
  hits.append(hex(pos));pos+=4
 print('pointer',hex(target),hex(ram),hits)
