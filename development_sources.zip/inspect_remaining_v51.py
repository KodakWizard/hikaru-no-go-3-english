from pathlib import Path
import struct, sys
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'translation_work/python_libs'))
from capstone import Cs, CS_ARCH_ARM, CS_MODE_THUMB
W=R/'translation_work/runtime_qa_v51';b=(W/'current_match.gba').read_bytes()
md=Cs(CS_ARCH_ARM,CS_MODE_THUMB);md.skipdata=True
out=[]
for lo,hi in [(0xd7f20,0xd7f60),(0xd80c0,0xd8180),(0xad744,0xad7e0),(0x2c8c0,0x2c960),(0x27cb0,0x27d30)]:
    out.append(f'\nRANGE {lo:x}..{hi:x}')
    # The high ranges are data/bytecode tables, never native instructions.
    if lo<0x40000:
        for ins in md.disasm(b[lo:hi],0x09f00000+lo):out.append(f'{ins.address:08x} {ins.mnemonic} {ins.op_str}')
    out.append('WORDS '+ ' '.join(f'{i:x}:{int.from_bytes(b[i:i+4],"little"):08x}' for i in range(lo,hi,4)))
for path in ['script/mission/mission.gcs','script/tutorial/tutorial.gcs']:
    d=(R/'translation_work/extracted'/path).read_bytes()
    out.append(f'\nDISPATCHER {path} {len(d)} bytes, base {int.from_bytes(d[:4],"big"):x}')
    # Valid CP932 runs in original binary; raw candidates are not visibility proof.
    for p in range(0,len(d)):
        if d[p] not in range(0x81,0xa0) and d[p] not in range(0xe0,0xfd):continue
        if p and d[p-1]!=0:continue
        e=d.find(b'\0',p)
        if e<0:continue
        try:s=d[p:e].decode('cp932')
        except UnicodeDecodeError:continue
        out.append(f'{p:x} {s!r}')
    out.append('Raw byte survey is not proof of branch coverage.')
(W/'remaining_code.txt').write_text('\n'.join(out),encoding='utf8')
print('\n'.join(out))
