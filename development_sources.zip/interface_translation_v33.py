"""Visible residual assessment, kifu, controller and cast-credit strings.

Cast pairs checked against TV Tokyo's official Hikaru cast listing:
https://www.tv-tokyo.co.jp/anime/hikaru2001/news/specialstaff.html
Creators: https://www.viz.com/hikaru-no-go
Initials retain identity when the original fixed slot cannot hold a full name.
Unverified developer-name readings and debug/encoding tables are left alone.
"""
TEXT = {
0x247fd4:'Cancel the current\ndownload to the\nJoy Carry cartridge?',
0x254510:'%sPort 1%s',0x254520:'%sPort 2%s',
0x254530:'%sPort 3%s',0x254540:'%sPort 4%s',
0x277ae8:'Hikaru Go 3',
0x277b0c:'Hotta Yumi',0x277b1c:'Obata T.',
0x277da4:'Hikaru Go: Insei Battle',
0x277e1c:'Roppongi Monitoring',
0x277ed4:'Shindo Hikaru',0x277ee4:'Kawakami Tomoko',
0x277ef4:'Toya Akira',0x277f04:'Kobayashi S.',
0x277f14:'Fujisaki A.',0x277f24:'Kakazu Yumi',
0x277f34:'Waya Y.',0x277f40:'Takagi Reiko',
0x277f50:'Isumi S.',0x277f60:'Suzumura K.',
0x277f70:'Ochi K.',0x277f7c:'Matsuoka Yoko',
0x277f8c:'Nase Asumi',0x277f9c:'Enomoto A.',
0x277fac:'Mitani Y.',0x277fb8:'Asakawa Yu',
0x277fc4:'Tsutsui K.',0x277fd0:'Tsumura Makoto',
0x277fe0:'Kaga Tetsuo',0x277fec:'Ito Kentaro',
0x277ffc:'Kuwabara',0x27800c:'Naya Rokuro',
0x27801c:'Toya Koyo',0x278028:'Tsuda Eizo',
0x278038:'Ogata Seiji',0x278044:'Fujiwara K.',
0x278054:'Kurata A.',0x278060:'Iwata Mitsuo',
0x278070:'Fujiwara S.',0x27807c:'Chiba Susumu',
0x27813c:'Konami Game Software',
0x278230:'KCE Japan (EAST)',
0x2bb0f4:'Correct.',0x2bb100:'Almost right.',0x2bb110:'Failed.',
0x2c4f30:'Toya Akira',0x2c4f3c:'Zama Oza',
0x2c52f0:'Kuwabara',0x2c52fc:'Ogata S.',
0x2c56b0:'Hong S',0x2c56bc:'Hikaru',
0x2c5a70:'Hikaru',0x2c5a7c:'Waya Y.',
0x2c5e30:'Hikaru',0x2c5e3c:'Gokiso Pro',
0x2c61f0:'Ogata S.',0x2c61fc:'Toya K.',
0x2c6970:'Hikaru',0x2c697c:'Kurata',
0x2d8168:'Play',0x2d86d0:'Off',0x2d8750:'None',
0x2dad90:'Jigo',0x2dada0:'Pass',0x2dadec:'Orig',0x2dadf4:'Art',
}
# These packed tables are intentionally not four-byte aligned. Each entry has
# its own original null-terminated slot; no pointers or lengths are changed.
for n in range(11):
    TEXT[0x2bb11c+11*n]=f'{n} points.' if n!=1 else '1 point.'
for n in range(11,20):
    TEXT[0x27741c+(n-11)*10]=str(n)
MISSION_SCORES={0x4e0+12*n:(f'{n} points.' if n!=1 else '1 point.') for n in range(11)}
