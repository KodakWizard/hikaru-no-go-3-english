"""Screenshot-confirmed residual file-list and Classics labels.

0x2505f8 follows a pointer table rather than a null: exact Japanese text and
the direct pointer at 0x2d45c0 are checked by the builder.
The two custom glyph constants 8750/874f select White/Black (font04 cells
8/7 on row 2). Replace the visible constants, never the shared font bitmap.
Surnames keep the original six/eight-byte player-name storage limits.
"""
TEXT={
 0x2505f8:'No files found.',
 0x2c6d30:'Yokoya',
 0x2c6d3c:'Osawa',
 0x2d97b4:'W',
 0x2d97b8:'B',
}
