from pathlib import Path
from PIL import Image,ImageDraw
from textures import resources,texture
out=Path('translation_work/lesson_menu');out.mkdir(exist_ok=True)
b=Path('translation_work/decoded/2D/fai.bin').read_bytes();items=[]
for name,o in resources(b):
 if name.endswith('.D4'):
  im,_=texture(b,o);im.save(out/(name+'.png'));items.append((name,im))
for pg in range((len(items)+35)//36):
 part=items[pg*36:pg*36+36];sheet=Image.new('RGB',(1200,95*((len(part)+2)//3)),'#304050');dr=ImageDraw.Draw(sheet)
 for i,(name,im) in enumerate(part):
  im=im.copy();im.thumbnail((390,65));x=i%3*400;y=i//3*95;dr.text((x+4,y+2),name,fill='white');sheet.paste(im,(x+4,y+25),im)
 sheet.save(out/f'page{pg+1}.png')
