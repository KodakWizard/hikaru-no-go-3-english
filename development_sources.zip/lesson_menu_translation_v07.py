LABELS={
'fai10_0.D4':'Go Course 1','fai10_1.D4':'Go Course 2','fai10_2.D4':'Go Course 3',
'fai11_0.D4':'Problems 1','fai11_1.D4':'Problems 2','fai11_2.D4':'Problems 3',
'fai11_3.D4':'Problems 4','fai11_4.D4':'Problems 5',
'fai12_0.D4':'Slot A','fai12_1.D4':'Slot B',
'fai13_0.D4':'Suspended','fai13_1.D4':'Kifu Data','fai13_2.D4':'Classics',
'fai15_0.D4':'Download','fai15_1.D4':'Slot A','fai15_2.D4':'Slot B',
'fai15_3.D4':'Load','fai15_4.D4':'Save','fai15_5.D4':'Move','fai15_6.D4':'Delete',
}
