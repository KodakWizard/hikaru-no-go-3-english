﻿from pathlib import Path
from gcs_text import text_tail
from check_tutorial_v07 import wrap
from tutorial_translation_v07 import LESSONS
b=Path('translation_work/extracted/script/tutorial/tuto1_01.gcs').read_bytes();_,_,r=text_tail(b)
for i in range(6):print(i,repr(r[i]['japanese']),repr(wrap(LESSONS['tuto1_01'][i])),[len(x) for x in wrap(LESSONS['tuto1_01'][i]).split('\n')])
print('CRLF',b.count(b'\r\n'),'LF',b.count(b'\n'),'arrows',b.count('↓'.encode('cp932')))
