"""Move static table headings to a dedicated row above runtime values."""
from PIL import Image,ImageDraw,ImageFont
from textures import resources,texture
from menu_art_v09 import put
from load_translation_v091 import HEADER_BOXES,VALUE_ANCHORS

def render_tables(b):
 lookup=dict(resources(b));arts={};checks=[]
 for i in [20,22,23,24,25,26,27,28]:
  n=f'fai{i}.D4';im=texture(b,lookup[n])[0].copy();before=im.copy();bg=im.getpixel((130,50))
  im.paste(bg,(2,28,598,70))
  fields=['Name','Skill','Rank','Games','Wins','Losses','Draws'] if i in (20,22) else ['Games','Wins','Losses','Draws'] if i==28 else ['Correct Answers']
  for label in fields:
   box=HEADER_BOXES.get(label,(400,28,598,40));budget=put(im,box,label,10,background=bg)
   assert budget['ink_height']<=10
   # Static headings end by y=40; dynamic glyphs occupy the separate lower row.
   assert box[3]<=40
   checks.append(dict(asset=n,label=label,box=list(box),font_size=budget['font_size'],ink_height=budget['ink_height'],value_region_y=[40,73],no_heading_value_overlap=True))
  assert im.crop((0,0,600,28)).tobytes()==before.crop((0,0,600,28)).tobytes()
  arts[n]=im
 return arts,checks

def layout_preview(im):
 """Illustrative native-size composition using recovered anchors, not Dolphin."""
 canvas=im.copy();draw=ImageDraw.Draw(canvas);font=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',24)
 samples={'Name':'Doki','Skill':'20 kyu','Rank':'15','Games':'999','Wins':'999','Losses':'999','Draws':'999'}
 cells={'Name':5,'Skill':6,'Rank':2,'Games':3,'Wins':3,'Losses':3,'Draws':3}
 bounds=[]
 for label,text in samples.items():
  x=VALUE_ANCHORS[label];reserved=(x,40,x+cells[label]*16,73)
  assert reserved[2]<=600;bounds.append((label,reserved))
  # Match the game's fixed 16px ASCII advance for the conservative fit preview.
  for j,c in enumerate(text):draw.text((x+j*16,40),c,font=font,fill='white',stroke_width=1,stroke_fill='black')
 for i,(a,ra) in enumerate(bounds):
  for b,rb in bounds[i+1:]:assert ra[2]<=rb[0] or rb[2]<=ra[0],(a,b)
 return canvas,bounds
