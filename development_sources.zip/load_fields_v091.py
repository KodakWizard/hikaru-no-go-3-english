﻿from pathlib import Path
import struct
b=Path('translation_work/main.dol').read_bytes()
for at in [0x250720,0x250bcc,0x250bd8,0x2d977c,0x2d990c,0x2d9914]:print(hex(at),repr(b[at:at+28]),repr(b[at:b.index(0,at)].decode('cp932')))
# Original small-data text near player data formatting.
out=[];a=0x2d96b0
while a<0x2d9a00:
 z=b.index(0,a)
 try:s=b[a:z].decode('cp932')
 except:s=''
 if s and all(c.isprintable() for c in s):out.append(hex(a)+' '+repr(s))
 a=z+1
Path('translation_work/load_v091_strings.txt').write_text('\n'.join(out),encoding='utf8')
