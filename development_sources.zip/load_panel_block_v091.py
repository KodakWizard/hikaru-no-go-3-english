﻿from pathlib import Path
b=Path('translation_work/main.dol').read_bytes();print(repr(b[0x250970:0x250bf0].decode('cp932','replace')))
