"""Load-list grade/rank/time strings and explicitly bounded small-data slots."""
TEXT={
0x250720:'Rank %2d',
0x250bcc:'1 dan',
0x250bd8:'%2d kyu',
0x2d977c:'Time',
0x2d990c:'1 dan',
0x2d9914:'%d kyu',
}
# These two original short CP932 constants occupy separate eight-byte aligned
# slots. Only verified zero padding before the next constant may be reclaimed.
ALIGNED_SLOTS={0x2d990c:0x2d9914,0x2d9914:0x2d991c}

# Child anchor positions recovered from the player-info constructor:
# 0x8016d838..0x8016d94c. Their parent image is centred on native x=300.
# Games/wins/losses/draws are printed with %3d and a 16px ASCII advance.
VALUE_ANCHORS={'Name':16,'Skill':190,'Rank':294,'Games':332,'Wins':397,'Losses':462,'Draws':527}
HEADER_BOXES={
'Name':(14,28,146,40),'Skill':(174,28,286,40),'Rank':(286,28,330,40),
'Games':(330,28,395,40),'Wins':(395,28,460,40),'Losses':(460,28,525,40),'Draws':(525,28,598,40),
}
