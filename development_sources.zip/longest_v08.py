﻿from pathlib import Path
import json
r=json.loads(Path('translation_work/text/japanese_candidates.json').read_text(encoding='utf8'))
for e in sorted([e for e in r if e['file']=='main.dol'],key=lambda e:e['byte_length'],reverse=True)[:12]:print(e['offset'],e['byte_length'],repr(e['japanese']))
