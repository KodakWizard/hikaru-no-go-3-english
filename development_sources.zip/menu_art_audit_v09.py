﻿from pathlib import Path
from PIL import Image,ImageDraw
from textures import resources,texture
from menu_translation_v04 import LABELS
from lesson_menu_translation_v07 import LABELS as FAI
from ui_translation_v08 import LABELS as UI
out=Path('translation_work/menu_v09');out.mkdir(exist_ok=True)
for src in ['2D/win','2D/rec','2D/ite','2D/brs','2D/fai','2D/scs']:
 p=Path('translation_work/decoded/'+src+'.bin')
 if not p.exists():continue
 b=p.read_bytes();done=set(LABELS.get(src,{}))|set(UI.get(src,{}))|(set(FAI) if src=='2D/fai' else set());items=[]
 for n,o in resources(b):
  if not n.endswith('.D4') or n in done:continue
  try:im,_=texture(b,o)
  except:continue
  if im.width<40 or im.height>150:continue
  items.append((n,im))
 print(src,len(items))
 for start in range(0,len(items),60):
  rows=items[start:start+60];sheet=Image.new('RGB',(1200,110*((len(rows)+2)//3)),'#405060');dr=ImageDraw.Draw(sheet)
  for i,(n,im) in enumerate(rows):
   im=im.copy();im.thumbnail((390,82));x=i%3*400;y=i//3*110;dr.text((x,y),n,fill='white');sheet.paste(im,(x,y+22),im)
  sheet.save(out/(src.replace('/','_')+str(start)+'.png'))
