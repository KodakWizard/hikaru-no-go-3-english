"""Render native UI labels and preserve icons/table geometry in composite assets."""
from PIL import Image,ImageDraw
from smooth_art import render_label
from textures import resources,texture
from ui_translation_v08 import LABELS as PREVIOUS_SCO

def put(im,box,text,size=15,fill=(255,255,255,255),background=None,outline=1):
 x,y,r,b=box
 if background is None:background=im.getpixel((r-1,b-1))
 canvas=Image.new('RGBA',(r-x,b-y),background)
 art,budget=render_label(canvas,text,max_size=size,margin=1,text_colour=fill,outline_width=outline)
 im.paste(art,(x,y));return budget

def extra_assets(src,b):
 lookup=dict(resources(b));result={}
 def get(n):return texture(b,lookup[n])[0].copy()
 if src=='2D/win':
  # Some settings reuse copies of sco labels inside win.bpe.
  for n,t in PREVIOUS_SCO['2D/sco'].items():
   if n in lookup:
    im=get(n);result[n]=(render_label(im,t,max_size=min(22,im.height-6),margin=3)[0],t)
 if src=='2D/scs':
  names=['Fujisaki Akari','Tsutsui Kimihiro','Mitani Yuki','Kaga Tetsuo','Nase Asumi','Waya Yoshitaka','Ochi Kosuke','Isumi Shinichiro','Shindo Hikaru','Toya Akira','Kurata Atsushi','Kuwabara Honinbo','Ogata Seiji','Toya Koyo','Fujiwara Sai','Fujisaki Akari']
  for i,t in enumerate(names):
   n=f'scs07_{i:02d}.D4';im=get(n);left=im.crop((0,0,25,24)).tobytes();put(im,(25,0,136,24),t,13,background=(0,0,0,255));assert im.crop((0,0,25,24)).tobytes()==left;result[n]=(im,t)
 if src=='2D/fai':
  for i in range(20,30):
   n=f'fai{i}.D4';im=get(n);tag='Player Data' if i in (20,28,29) else 'Joy Carry'
   put(im,(4,2,141,23),tag,14,fill=(255,163,0,255),background=(0,0,0,255),outline=0)
   if i==21:put(im,(160,2,497,25),'No cartridge inserted.',17,fill=(0,0,0,255),background=im.getpixel((490,12)),outline=0)
   elif i==22:put(im,(160,2,497,25),'Portable Goban',17,fill=(0,0,0,255),background=im.getpixel((490,12)),outline=0)
   elif 23<=i<=27:
    put(im,(160,2,497,25),f'Go Problems Vol. {i-22}',17,fill=(0,0,0,255),background=im.getpixel((490,12)),outline=0)
    put(im,(400,32,598,69),'Correct Answers',15,background=im.getpixel((395,50)))
   if i in (20,22,28):
    bg=im.getpixel((130,50));im.paste(bg,(135,32,598,69))
    fields=[(150,195,'Skill'),(230,310,'Rank')] if i in (20,22) else []
    fields += [(360,416,'Games'),(430,480,'Wins'),(493,545,'Losses'),(556,598,'Draws')]
    for x,r,t in fields:put(im,(x,37,r,67),t,14,background=bg)
   result[n]=(im,tag+(' / Go Problems' if 23<=i<=27 else ''))
 if src=='2D/rec':
  im=get('rec02_0.D4');bg=im.getpixel((300,60));put(im,(22,35,244,62),'Standard Matches',19,background=bg);put(im,(22,73,275,102),'Survival Matches',19,background=bg);result['rec02_0.D4']=(im,'Standard Matches / Survival Matches')
  im=get('rec02_1.D4');bg=im.getpixel((330,60));put(im,(3,2,330,27),'Play Time',19,background=bg);put(im,(3,27,330,53),'GBA Matches',19,background=bg);result['rec02_1.D4']=(im,'Play Time / GBA Matches')
  im=get('rec04.D4');put(im,(509,0,640,25),'Rank Test',16,background=(0,0,0,255),outline=0);result['rec04.D4']=(im,'Rank Test')
 return result

def copyright_overlay(b):
 lookup=dict(resources(b));im=texture(b,lookup['lic00.D4'])[0].copy()
 # The game's separate copyright overlay can cover the title backgrounds.
 # Preserve the English KONAMI line and original alpha/background outside row 1.
 bg=im.getpixel((0,0));box=(35,207,605,235)
 text='© Yumi Hotta · HMC · Takeshi Obata · Noel / Shueisha · TV Tokyo · Dentsu · Studio Pierrot'
 put(im,box,text,13,background=bg,outline=0)
 return im
