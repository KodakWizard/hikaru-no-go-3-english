﻿from pathlib import Path
import json
r=json.loads(Path('translation_work/text/japanese_candidates.json').read_text(encoding='utf8'));out=[]
for lo,hi in [(0x24a000,0x24c000),(0x251500,0x251950),(0x251c00,0x252e00),(0x258000,0x258c00)]:
 for e in r:
  if e['file']=='main.dol' and lo<=int(e['offset'],16)<hi:out.append(e['offset']+' '+repr(e['japanese']))
Path('translation_work/menu_pass_v09_full.txt').write_text('\n'.join(out),encoding='utf8')
