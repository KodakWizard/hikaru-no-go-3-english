from PIL import Image,ImageDraw
from pathlib import Path
from textures import resources,texture
out=Path('translation_work/menu_research');out.mkdir(exist_ok=True)
for src,lo,hi in [('2D/sco',0,64),('2D/sco',64,128),('2D/sco',128,202),('2D/roo',0,50),('2D/scs',0,80)]:
 b=Path('translation_work/decoded/'+src+'.bin').read_bytes()
 res=[(n,o) for n,o in resources(b) if n.endswith('.D4')][lo:hi]
 sheet=Image.new('RGB',(1200,95*((len(res)+2)//3)),'#304050');dr=ImageDraw.Draw(sheet)
 for i,(name,o) in enumerate(res):
  im,desc=texture(b,o);im.save(out/(name+'.png'));im.thumbnail((390,64))
  x=(i%3)*400;y=(i//3)*95;dr.text((x+5,y+2),name,fill='white');sheet.paste(im,(x+5,y+25),im)
 sheet.save(out/(src.split('/')[-1]+str(lo)+'.png'))
