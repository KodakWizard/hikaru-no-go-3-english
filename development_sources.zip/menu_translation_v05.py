TEXT={
0x24bde0:'Set controller rumble.',
0x24be00:'Set sound mode.',
0x230ad8:'The %s card contains\n%s.',
0x230b04:'From the %s card, delete\n%s?',
0x230b3c:'On the %s card, create\n%s?',
0x230b6c:'%s: created %s.',
0x230b94:'%s: could not create\n%s.',
0x2d4d70:'Yes',0x2d4d78:'No',
0x2d8144:'Yes',0x2d814c:'No',
0x2da118:'Yes',0x2da120:'No',
}
