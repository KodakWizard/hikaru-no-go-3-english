"""Broader menu/GBA pass and memory-card in-place formatting corrections."""
CARD_FIXES={
0x22dafc:'%s: checking card.\nKeep card inserted and power on.',
0x22fc90:'%s card: no more files\ncan be created.',0x22fcc8:'%s card: not enough\nfree blocks.',0x22fda4:'%s card is damaged\nand cannot be used.',0x22fddc:'%s device is not\na memory card.',
0x22ffd4:'%s card has corrupted data\nand must be formatted.',0x23007c:'%s: no memory card.',
0x2301e4:'%s card has corrupted\n%s. Delete it?',0x230220:'%s: deleting corrupted saves.\nDo not remove card or turn off power.',
0x230290:'%s card: corrupted\nsaves deleted.',0x2302e4:'%s card has no\n%s.\nCreate new data?',
0x230398:'%s: please change the card.',0x2303e8:'%s card already has\n%s.\nOverwrite this data?',
0x23042c:'%s card has no system data.\nStory progress will not be reflected\nin system data from now on.',
0x230540:'%s card: auto-save failed.',0x230574:'%s: loading card.\nDo not remove card or turn off power.',0x2305d4:'%s card: loaded.',
0x23060c:'%s card has corrupted\n%s. Delete it?',0x230748:'%s card has no save data.\nCreate new data?',0x230794:'%s: game data already exists.\nOverwrite it?',0x2307cc:'%s card: saved.',0x2307f8:'%s: saving to card.\nDo not remove card or turn off power.',
0x230ad8:'%s card contains\n%s.',0x230b04:'%s card:\nDelete %s?',0x230b3c:'%s card:\nCreate %s?',
0x230c18:'%s card: formatted.',0x230c44:'%s card: could not format.',0x230c70:'%s: formatting card.\nDo not remove card or turn off power.',0x230ccc:'%s device is not\na memory card.',
}
TEXT={
0x22f9a0:'Suspended / kifu data',0x22fa64:'Story / kifu data',
0x22f9b8:'%s card has %d free blocks.\n%s needs at least\n1 file and 2 free blocks\nfor each data type.',
0x22fa90:'%s card has %d free blocks.\n%s needs at least\n1 file and 2 free blocks.',
0x22fb48:'%s card has %d free blocks.\n%s needs at least\n1 file and 2 free blocks.',
0x22fbec:'%s card has %d free blocks.\n%s needs at least\n1 file and 2 free blocks.',
0x22fe10:'%s needs at least\n1 file and 2 free blocks\nfor each data type.',0x22fe84:'%s needs at least\n1 file and 2 free blocks.',0x22fef0:'%s is for Slot A only.\nEach data type needs at least\n1 file and 2 free blocks.',
0x230110:'Story saves: %d\n',0x230130:'Kifu saves: %d\n',0x230150:'Suspended games: %d\n',0x230170:'%s card has corrupted\nHikaru no Go 3 save data.\n%s%s%sDelete all of it?\n',
0x230970:'%s card has insufficient space.\n%s needs 1 file and %d blocks.\nUse the console Memory Card screen\nto manage card contents.',0x230a20:'%s card cannot hold more files.\n%s needs 1 file and %d blocks.\nUse the console Memory Card screen\nto manage card contents.',
0x230cfc:'%s card has insufficient space.\n%s needs 1 file and %d blocks.\nUse the console Memory Card screen\nto manage card contents.',0x230db8:'%s card cannot hold more files.\n%s needs 1 file and %d blocks.\nUse the console Memory Card screen\nto manage card contents.',
0x24a804:'Choose the players for the match.',0x24a82c:'Selected controller is disconnected.',0x24a918:'Rank ?',0x24a924:'Rank %s',0x24a930:'Rank%s',
0x24b060:'Go to Support settings.',0x24b07c:'Go to Options settings.',0x24b0d0:'Start the match.',0x24b0e4:'Finish settings.',0x24b2bc:'Zoom in on the board.',0x24b2d4:'Zoom out on the board.',0x24b2ec:'This option is unavailable.',
0x24b5d0:'Play a 2-on-2 match.',0x24b5e8:'View kifu and classic games.',0x24b60c:'Manage results and effects.',0x24b630:'Set controllers and sound.',0x24b654:'View results and play time.',0x24b67c:'Change player effects.',0x24b6a0:'Change the player name.',
0x24b704:'Set connection effects.',0x24b724:'Set capture effects.',0x24b744:'Set decisive-move effects.',0x24b764:'Set best-move effects.',
0x24b784:'Well played!',0x24b798:'Superb!',0x24b7a4:'Too bad. Try again!',0x24b7c0:'Come on, cheer up!',0x24b7dc:'So close. Every point counts.',0x24b800:'Well done! Your rank went up!',0x24b828:'Oh, your rank went down.',0x24b84c:'Congratulations! Top rank!',0x24b874:'Find out what led to each win or loss.',0x24b8a8:'That was rather a one-sided game.',0x24b8d4:'A tough game. Both sides played well.',0x24b908:'You both fought well.',
0x24bb4c:'3-Choice Go vs. Sai.',0x24bb64:"Set opponent level.",0x24bb7c:'Set your level.',0x24bb94:'Set which move to choose.',0x24bbf0:'Play with Sai.',0x24bc04:"Set Sai's level.",0x24bc28:'Set the effects used in matches.',0x24bcec:'Choose stones, board and background.',0x24bd14:'Choose the Go stones.',0x24bd34:'Choose the Go board.',0x24bd54:'Choose the background.',
0x251594:'Delete this data?',0x251818:'Advice on improving your Go.',
0x251f20:'Insert the Hikaru no Go 3\nJoy Carry cartridge in the GBA.\nHold START and SELECT\nwhile turning on the GBA.',
0x251fd8:'            When the GBA shows\n            the screen at left,\n            connect its GBA cable\nto the GameCube ',
0x252054:'.\nConnect the GBA there.',0x252084:'Connect the GBA and GameCube,\nthen press the A Button.',0x2520d0:'Connecting to the GBA.\nPlease wait.',0x252114:'Preparing the transfer.\nPlease wait.',
0x25215c:'Ready to transfer.\nKeep the GBA switched on.\nDo not remove the cartridge\nor disconnect the GBA cable.',
0x2521fc:'Uploading game data\nfrom the GBA.\nPlease wait.',0x252258:'Updating GBA game data.\nPlease wait.',0x2522a8:'GBA game data updated.',
0x2522e4:'The GBA has game data\nthat can be updated.\nContinuing will erase it.\nContinue the download?',
0x25236c:'Download the Portable Goban?',0x2523ac:'Download Go Problems Vol. 1?',0x2523e8:'Download Go Problems Vol. 2?',0x252424:'Download Go Problems Vol. 3?',0x252460:'Download Go Problems Vol. 4?',0x25249c:'Download Go Problems Vol. 5?',
0x2524d8:'Portable Goban is already\ndownloaded.\nDownload game data only?',
0x25253c:'Go Problems Vol. 1 is already\ndownloaded.\nDownload game data only?',0x25259c:'Go Problems Vol. 2 is already\ndownloaded.\nDownload game data only?',0x2525fc:'Go Problems Vol. 3 is already\ndownloaded.\nDownload game data only?',0x25265c:'Go Problems Vol. 4 is already\ndownloaded.\nDownload game data only?',0x2526bc:'Go Problems Vol. 5 is already\ndownloaded.\nDownload game data only?',
0x25271c:'Portable Goban is already\ndownloaded.',0x252754:'Go Problems Vol. 1 is\nalready downloaded.',0x252788:'Go Problems Vol. 2 is\nalready downloaded.',0x2527bc:'Go Problems Vol. 3 is\nalready downloaded.',0x2527f0:'Go Problems Vol. 4 is\nalready downloaded.',0x252824:'Go Problems Vol. 5 is\nalready downloaded.',
0x252858:'This will erase the GBA\ngame data. Continue?',0x2528a4:'Starting the download.',0x2528c0:'Select Update Data\nto update your game data.',0x2528f8:'The GameCube and GBA\nStory data do not match.\nData cannot be updated.',0x25295c:'The GameCube and GBA\nStory data do not match.\nThe GameCube data\ncannot be updated.',
0x2529d8:'Continuing will overwrite\nthe GBA Story data.\nContinue the download?',0x252a3c:'Updating GBA kifu /\nsuspended game data.\nPlease wait.',0x252a90:'Update the GameCube\nand GBA game data?',0x252af4:'Update the GBA game data?',0x252b3c:'Data update complete.',0x252b58:'Downloading the latest\nresults to the GBA.\nPlease wait.',
0x252bb4:'Erase all data on the\nJoy Carry cartridge?',0x252bfc:'Erasing the Joy Carry\ncartridge. Please wait.',0x252c48:'Joy Carry cartridge erased.',0x252c7c:'Could not connect.\nPut the GBA in Download Mode\nand check the connection.',0x252ce0:'Insert the Hikaru no Go 3\nJoy Carry cartridge\ncorrectly in the GBA.',0x252d58:'Insert the Hikaru no Go 3\nJoy Carry cartridge\nin the GBA.',0x252dcc:'Results update failed.\nCheck the GBA and\nmemory card connections.',
0x258a50:'Choose the GBA port.',0x258a70:'Choose what to download.',0x258a98:'Choose a Go problem collection.',0x258ac0:'Move kifu / suspended game data.',0x258b20:'View kifu and classic games.',0x258b44:'Results and play time.',0x258b60:'Enter your name.',
}

LABELS={'2D/win':{},'2D/brs':{'brs02_0.D4':'Spin','brs02_1.D4':'Move','brs02_2.D4':'Light','brs02_3.D4':'Reset View','brs02_4.D4':'Zoom','brs02_6.D4':'Controls\nON / OFF'},'2D/rec':{'rec03_0.D4':'Character','rec03_2.D4':'Matches','rec03_3.D4':'Suspended'}}
w=LABELS['2D/win']
for prefix,values in [('win22',['Standard Stones','Crystal Stones','Plastic Stones','Marble Stones','Character Stones','Carved Stones','Leaf Stones','One-Colour Go']),('win24',['Legged Board','Crystal Board','Magnetic Board','Tatami Mat','Folding Board','Vermilion Board','Lacquer Board']),('win26',['Tatami','Water','Wood Flooring','Indigo Dye','Scroll','Gold Screen','Silver Hydrangea','Leopard Print','Wooden Desk','Outer Space'])]:
 for i,t in enumerate(values):w[f'{prefix}_{i}.D4']=t
for i in range(15):w[f'win31_{i:02d}.D4']=f'Rank {i+1}'
for i in range(4):w[f'win32_{i}.D4']=f'Move {i+3}'
for i,t in enumerate(['White Tiger','Azure Dragon','Vermilion Bird','Black Tortoise','Flowers','Cyber','Demon']):w[f'sco10_{i:02d}.D4']=t
