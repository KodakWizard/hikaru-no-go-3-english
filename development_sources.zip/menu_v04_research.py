from pathlib import Path
from PIL import Image,ImageDraw
from textures import resources,texture
out=Path('translation_work/menu_v04_research');out.mkdir(exist_ok=True)
for src in ['2D/win','2D/nam','2D/sbg','2D/mba']:
 b=Path('translation_work/decoded/'+src+'.bin').read_bytes();items=[]
 for name,o in resources(b):
  if not name.endswith('.D4'):continue
  im,desc=texture(b,o)
  if src=='2D/win' and not name.startswith(('win0','win1','win2')):continue
  im.save(out/(name+'.png'));items.append((name,im))
 for pg in range((len(items)+35)//36):
  part=items[pg*36:pg*36+36];sheet=Image.new('RGB',(1200,90*((len(part)+2)//3)),'#304050');dr=ImageDraw.Draw(sheet)
  for i,(name,im) in enumerate(part):
   im=im.copy();im.thumbnail((390,60));x=i%3*400;y=i//3*90;dr.text((x+4,y+2),name,fill='white');sheet.paste(im,(x+4,y+25),im)
  sheet.save(out/(src.split('/')[-1]+str(pg)+'.png'))
