﻿from pathlib import Path
import json
m=json.loads(Path('translation_work/disc_metadata.json').read_text());o=Path('translation_work/main.dol').read_bytes()
with Path('English_Course_v07/Hikaru no Go 3 - English Course v07.iso').open('rb') as f:f.seek(m['dol_offset']);b=f.read(len(o))
r=json.loads(Path('translation_work/text/japanese_candidates.json').read_text(encoding='utf8'));ranges=[]
for e in r:
 if e['file']!='main.dol':continue
 a=int(e['offset'],16);end=o.find(b'\0',a);j=b.find(b'\0',a)
 if b[a:j]==o[a:end] or not all(x<128 or x in (0x81,0xab) for x in b[a:j]):continue
 start=(j+4)&~3
 if end-start>=16 and not any(b[start:end]):ranges.append((start,end&~3))
print(len(ranges),sum(y-x for x,y in ranges));print([(hex(x),y-x) for x,y in ranges])
Path('translation_work/ui_v08/name_caves.json').write_text(json.dumps(ranges))
