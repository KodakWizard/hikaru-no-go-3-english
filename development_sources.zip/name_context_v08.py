﻿from pathlib import Path
b=Path('translation_work/main.dol').read_bytes()
for lo,hi in [(0x24c640,0x24c900),(0x279680,0x279800),(0x2c5680,0x2c5700)]:
 print(hex(lo),repr(b[lo:hi].decode('cp932','replace')))
