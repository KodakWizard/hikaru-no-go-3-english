"""Narrow Latin in display copies without changing saved names or the keyboard."""
import json,struct
from pathlib import Path

def branch(src,dst,link=False):
 delta=dst-src
 assert delta%4==0 and -(1<<25)<=delta<(1<<25)
 return 0x48000000|(delta&0x3fffffc)|int(link)

def patch(dol,original):
 nodes=[];labels={}
 def label(s):labels[s]=len(nodes)
 def op(x):nodes.append(('op',x))
 def cond(kind,target):nodes.append((kind,target))
 def jump(target):nodes.append(('b',target))
 def d(opcode,rt,ra,imm):return opcode<<26|rt<<21|ra<<16|(imm&65535)
 def cmp(reg,n):op(d(11,0,reg,n))
 def add(rt,ra,n):op(d(14,rt,ra,n))
 def load(rt,ra,n=0):op(d(34,rt,ra,n))
 def save(rt,ra,n=0):op(d(38,rt,ra,n))
 add(5,3,0)
 label('loop');load(6,4);cmp(6,0);cond('eq','end');cmp(6,0x82);cond('ne','copy')
 load(7,4,1);cmp(7,0x4f);cond('lt','copy');cmp(7,0x58);cond('le','minus31')
 cmp(7,0x60);cond('lt','copy');cmp(7,0x79);cond('le','minus31')
 cmp(7,0x81);cond('lt','copy');cmp(7,0x9a);cond('gt','copy')
 add(6,7,-0x20);jump('narrow')
 label('minus31');add(6,7,-0x1f)
 label('narrow');add(4,4,2);save(6,5);add(5,5,1);jump('loop')
 label('copy');save(6,5);add(4,4,1);add(5,5,1);cmp(6,0x81);cond('lt','loop');cmp(6,0x9f);cond('le','trail');cmp(6,0xe0);cond('lt','loop');cmp(6,0xfc);cond('gt','loop')
 label('trail');load(6,4);cmp(6,0);cond('eq','end');save(6,5);add(4,4,1);add(5,5,1);jump('loop')
 label('end');save(6,5);nodes.append(('ret',0))
 # Use only reclaimed tails of translated constant strings. Never use original
 # zero-filled regions: several contain writable game objects and tables.
 ranges=json.loads(Path('translation_work/ui_v08/name_caves.json').read_text())
 ranges=[(a,b) for a,b in ranges if b<0x230d00]
 addresses=[];ix=0;pos=ranges[0][0]
 for kind,value in nodes:
  size=12 if kind in ('eq','ne','lt','le','gt') else 8 if kind=='op' else 4
  while pos+size>ranges[ix][1]:ix+=1;pos=ranges[ix][0]
  addresses.append(pos+0x80003000);pos+=size
 words={};conditions={'eq':(4,2),'ne':(12,2),'lt':(4,0),'le':(12,1),'gt':(4,1)}
 for i,(kind,value) in enumerate(nodes):
  at=addresses[i];nxt=addresses[i+1] if i+1<len(nodes) else 0
  if kind=='op':words[at]=value;words[at+4]=branch(at+4,nxt)
  elif kind=='b':words[at]=branch(at,addresses[labels[value]])
  elif kind=='ret':words[at]=0x4e800020
  else:
   bo,bi=conditions[kind] # inverse condition skips the true branch
   words[at]=16<<26|bo<<21|bi<<16|8
   words[at+4]=branch(at+4,addresses[labels[value]])
   words[at+8]=branch(at+8,nxt)
 # Reject data pointers into reclaimed ranges; all allocated bytes must still
 # be zero in the cumulative executable.
 for at,w in words.items():
  o=at-0x80003000;assert dol[o:o+4]==bytes(4)
  assert at.to_bytes(4,'big') not in original[0x22d3e0:]
  struct.pack_into('>I',dol,o,w)
 # Normalise copied names for Story dialogue and game-record/display copies.
 hooks=[0x801a3c0c,0x80024b10,0x80025530]
 for at in hooks:
  o=at-0x80018ba0+0x2620
  assert int.from_bytes(dol[o:o+4],'big')==branch(at,0x8021d080,True)
  struct.pack_into('>I',dol,o,branch(at,addresses[0],True))
 # Execute the actual injected instructions in a small PPC integer interpreter.
 def emulate(raw):
  mem={0x100000+i:v for i,v in enumerate(raw+b'\0')};regs=[0]*32;regs[3]=0x200000;regs[4]=0x100000;pc=addresses[0];cr=[False]*4
  for step in range(10000):
   w=words[pc];code=w>>26;rt=w>>21&31;ra=w>>16&31;imm=w&65535;imm=imm-65536 if imm&32768 else imm;nextpc=pc+4
   if w==0x4e800020:break
   if code==14:regs[rt]=(regs[ra] if ra else 0)+imm
   elif code==34:regs[rt]=mem.get(regs[ra]+imm,0)
   elif code==38:mem[regs[ra]+imm]=regs[rt]&255
   elif code==11:cr=[regs[ra]<imm,regs[ra]>imm,regs[ra]==imm,False]
   elif code==18:
    delta=w&0x3fffffc;delta=delta-(1<<26) if delta&(1<<25) else delta;nextpc=pc+delta
   elif code==16:
    bo=w>>21&31;bi=w>>16&31
    if cr[bi]==(bo==12):nextpc=pc+(w&0xfffc)
   else:raise AssertionError(hex(w))
   pc=nextpc
  else:raise AssertionError('normaliser did not terminate')
  assert regs[3]==0x200000
  out=bytearray();p=regs[3]
  while mem.get(p,0):out.append(mem[p]);p+=1
  return bytes(out)
 tests=['Ｄｏｋｉ','ＡＢＣｘｙｚ０１９','Doki','あかり','ＡあＢ','ｶﾀｶﾅＡ','藤崎あかり','']
 for text in tests:
  expected=''.join(chr(ord(c)-0xfee0) if '０'<=c<='９' or 'Ａ'<=c<='Ｚ' or 'ａ'<=c<='ｚ' else c for c in text)
  assert emulate(text.encode('cp932'))==expected.encode('cp932'),text
 return dict(hooks=[hex(x) for x in hooks],entry=hex(addresses[0]),injected_bytes=len(words)*4,reclaimed_words=[hex(x-0x80003000) for x in words],actual_ppc_tests=len(tests),saved_name_data_unchanged=True,scope='Story name substitution and game-record name copies; confirm battle HUD in Dolphin')
