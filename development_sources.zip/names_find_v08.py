﻿from pathlib import Path
b=Path('translation_work/main.dol').read_bytes()
for s in ['藤崎あかり','進藤ヒカル','アゲハマ','終局しても','はじめまして']:
 needle=s.encode('cp932');i=0
 while True:
  i=b.find(needle,i)
  if i<0:break
  print(s,hex(i));i+=len(needle)
