"""Freeze the reviewed final maps as simple data; retain the draft separately."""
from pathlib import Path
import pprint,shutil
from dialogue_polish_v50 import REVISIONS,SCRIPT_REVISIONS
p=Path('dialogue_polish_v50.py')
draft=Path('translation_work/dialogue_v50/editorial_draft.py.txt')
if not draft.exists():shutil.copyfile(p,draft)
text='"""Final reviewed wording, keyed to the immutable v49 audit corpus.\n\n'
text+='Japanese and before/after records accompany the finished v50 build.\n"""\n'
text+='REVISIONS = '+pprint.pformat(REVISIONS,sort_dicts=True,width=100)+'\n\n'
text+='SCRIPT_REVISIONS = '+pprint.pformat(SCRIPT_REVISIONS,sort_dicts=True,width=100)+'\n'
p.write_text(text,encoding='utf8')
