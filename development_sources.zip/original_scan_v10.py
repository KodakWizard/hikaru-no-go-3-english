from qa_research_v10 import *
if __name__=='__main__':
 inv=json.loads((WORK/'inventory.json').read_text(encoding='utf8'));src=open(ROOT/'Hikaru no Go 3 (Japan).iso','rb');items=[]
 for e in inv:
  if not e['path'].endswith('.bpe') or '/bustup/' in e['path']:continue
  src.seek(e['offset']);data=decode(src.read(e['size']))
  for n,o in resources(data):
   if not n.endswith('.D4'):continue
   im,desc=texture(data,o)
   if 'bbg01' in n:print(e['path'],n,desc[:3]);im.save(OUT/('disc_'+n+'.png'))
   if any(x in n.lower() for x in ['load','logo','now']):print('possible load',e['path'],n,desc[:3])
   if e['path'] not in ['2D/win.bpe','2D/fai.bpe','2D/sco.bpe','2D/sbg.bpe','2D/scs.bpe','2D/map.bpe','2D/mjw.bpe','title/title.bpe'] and not e['path'].startswith('font'):
    im.thumbnail((220,100));items.append((e['path']+' '+n,im))
 for pg in range((len(items)+79)//80):
  batch=items[pg*80:(pg+1)*80];sh=Image.new('RGB',(1200,125*((len(batch)+4)//5)),'#405060');d=ImageDraw.Draw(sh)
  for i,(n,im) in enumerate(batch):x=i%5*240;y=i//5*125;d.text((x,y),n,fill='white');sh.paste(im,(x,y+20),im)
  sh.save(OUT/f'other_{pg}.png')
