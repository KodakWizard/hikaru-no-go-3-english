from pathlib import Path
import json,struct
root=Path(__file__).resolve().parent;rel=root/'English_Menu_POC'
src=root/'Hikaru no Go 3 (Japan).iso';dst=rel/'Hikaru no Go 3 - English Menu POC.iso'
report=json.loads((rel/'build_report.json').read_text(encoding='utf8'));meta=json.loads((root/'translation_work/disc_metadata.json').read_text())
ranges=[(meta['dol_offset'],meta['dol_offset']+(root/'translation_work/main.dol').stat().st_size),(meta['fst_offset'],meta['fst_offset']+meta['fst_size']),(report['title_archive_offset'],report['title_archive_offset']+report['title_archive_size'])]
# Verify every other byte matches, and create a standard IPS patch.
patch=bytearray(b'PATCH');differences=0
with src.open('rb') as a,dst.open('rb') as b:
 pos=0
 while True:
  x=a.read(1024*1024);y=b.read(1024*1024)
  if not x:assert not y;break
  assert len(x)==len(y)
  if x!=y:
   i=0
   while i<len(x):
    if x[i]==y[i]:i+=1;continue
    start=i;i+=1
    while i<len(x) and x[i]!=y[i] and i-start<65535:i+=1
    off=pos+start;assert off!=0x454f46 and off<0x1000000
    assert any(s<=off and pos+i<=e for s,e in ranges)
    patch.extend(off.to_bytes(3,'big')+(i-start).to_bytes(2,'big')+y[start:i]);differences+=i-start
  pos+=len(x)
patch.extend(b'EOF');(rel/'Hikaru_no_Go_3_English_Menu_POC.ips').write_bytes(patch)
report['whole_iso_diff_verified']=True;report['changed_bytes']=differences;report['ips_size']=len(patch)
(rel/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('Verified all ISO changes fall within DOL, FST, and relocated title archive. IPS bytes:',len(patch))
