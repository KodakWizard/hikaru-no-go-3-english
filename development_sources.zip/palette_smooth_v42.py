"""Fixed-capacity edge-aware native palettes. No texture/archive resizing."""
import struct
import numpy as np
from collections import Counter
from smooth_art import palette

def vector(c):
 a=np.asarray(c,dtype=np.float64)
 return np.array([a[0]*a[3]/255,a[1]*a[3]/255,a[2]*a[3]/255,a[3]*2**.5])

def word(c,pf):
 r,g,b,a=[int(round(max(0,min(255,x)))) for x in c]
 if pf==0:return (a<<8)|round((r+g+b)/3)
 if pf==1:return (round(r*31/255)<<11)|(round(g*63/255)<<5)|round(b*31/255)
 if a>=250:return 0x8000|(round(r*31/255)<<10)|(round(g*31/255)<<5)|round(b*31/255)
 return (round(a*7/255)<<12)|(round(r/17)<<8)|(round(g/17)<<4)|round(b/17)

def improve(blob,o,im,monochrome):
 fmt=int.from_bytes(blob[o+32:o+34],'big');pf,count=struct.unpack_from('>HH',blob,o+44)
 count=min(count,16) if fmt==8 else count
 oldpal=palette(blob,o,fmt)
 hist=Counter(im.getdata());items=list(hist)
 if monochrome:
  if pf==2 and count>=16:
   colors=[(0,0,0,a*255/7) for a in range(8)]+[(255,255,255,a*255/7) for a in range(8)]
   colors += [(q,q,q,255) for q in np.linspace(0,255,count-16+2)[1:-1]]
  elif pf==2:
   colors=[(0,0,0,a) for a in (0,128,255)]+[(255,255,255,a) for a in (80,170,255)]+[(q,q,q,255) for q in np.linspace(60,195,max(0,count-6))]
  else:colors=[(q,q,q,255) for q in np.linspace(0,255,count)]
 else:
  # Reserve grayscale edge shades; fit remaining colors in premultiplied space.
  reserve=min(12,count//3)
  colors=[(q,q,q,255) for q in np.linspace(0,255,reserve)]
  if pf==2 and count>=32:colors += [(0,0,0,a*255/7) for a in range(7)]
  fixed=len(colors);k=count-fixed
  samples=sorted(hist,key=lambda c:hist[c]**.55,reverse=True)[:4096]
  x=np.array([vector(c) for c in samples]);weights=np.array([hist[c]**.55 for c in samples])
  init=[vector(c) for c in oldpal]
  centers=np.array([vector(c) for c in colors]+init[:k])
  for step in range(10):
   dist=((x[:,None,:]-centers[None,:,:])**2).sum(2);labels=dist.argmin(1)
   for j in range(fixed,count):
    mask=labels==j
    if mask.any():centers[j]=np.average(x[mask],axis=0,weights=weights[mask])
  for v in centers[fixed:]:
   a=v[3]/2**.5
   colors.append(tuple(v[:3]*255/max(a,1))+(a,))
 vals=[word(c,pf) for c in colors];assert len(vals)==count
 candidate=bytearray(blob)
 for j,v in enumerate(vals):struct.pack_into('>H',candidate,o+64+j*2,v)
 # Do not accept a palette whose weighted quantization error exceeds the old one.
 def error(pal):
  x=np.array([vector(c) for c in items]);v=np.array([vector(c) for c in pal]);out=0.
  for start in range(0,len(items),1024):
   d=((x[start:start+1024,None,:]-v[None,:,:])**2).sum(2).min(1)
   out+=sum(float(e)*hist[c] for e,c in zip(d,items[start:start+1024]))
  return out/max(1,sum(hist.values()))
 olderr=error(oldpal);newerr=error(palette(candidate,o,fmt))
 if newerr<=olderr:
  blob[o+64:o+64+count*2]=candidate[o+64:o+64+count*2]
  return dict(accepted=True,old_error=olderr,new_error=newerr,palette_range=[o+64,o+64+count*2])
 return dict(accepted=False,old_error=olderr,new_error=newerr)
