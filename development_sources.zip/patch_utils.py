from pathlib import Path
import hashlib
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()

def package(source,target,output,allowed):
 patch=bytearray(b'PATCH');changed=0
 with source.open('rb') as f,target.open('rb') as g:
  pos=0
  while True:
   a=f.read(1024*1024);b=g.read(1024*1024)
   if not a:assert not b;break
   assert len(a)==len(b)
   if a!=b:
    i=0
    while i<len(a):
     if a[i]==b[i]:i+=1;continue
     s=i;i+=1
     while i<len(a) and a[i]!=b[i] and i-s<65535:i+=1
     at=pos+s;assert at<0x1000000 and at!=0x454f46
     assert any(lo<=at and pos+i<=hi for lo,hi in allowed),(hex(at),'unexpected difference')
     patch.extend(at.to_bytes(3,'big')+(i-s).to_bytes(2,'big')+b[s:i]);changed+=i-s
   pos+=len(a)
 patch.extend(b'EOF');output.write_bytes(patch)
 ops=[];i=5
 while patch[i:i+3]!=b'EOF':
  o=int.from_bytes(patch[i:i+3],'big');n=int.from_bytes(patch[i+3:i+5],'big');assert n
  ops.append((o,patch[i+5:i+5+n]));i+=5+n
 h=hashlib.sha256();ix=0;pos=0
 with source.open('rb') as f:
  while True:
   b=bytearray(f.read(1024*1024))
   if not b:break
   end=pos+len(b)
   while ix<len(ops) and ops[ix][0]<end:
    o,data=ops[ix];lo=max(pos,o);hi=min(end,o+len(data));b[lo-pos:hi-pos]=data[lo-o:hi-o]
    if o+len(data)<=end:ix+=1
    else:break
   h.update(b);pos=end
 target_sha=sha(target);assert h.hexdigest()==target_sha
 return dict(output_sha256=target_sha,ips_reconstructs_target=True,whole_disc_differences_verified=True,changed_bytes=changed)
