﻿from pathlib import Path
b=Path('translation_work/main.dol').read_bytes();out=[]
for lo,hi in [(0x24ac50,0x24b050),(0x24c668,0x24c724)]:
 i=lo
 while i<hi:
  j=b.find(b'\0',i)
  try:s=b[i:j].decode('cp932')
  except:s=''
  if s and all(c.isprintable() or c=='\n' for c in s):out.append(f'{i:x} {s}')
  i=j+1
Path('translation_work/ui_v08/pause_strings.txt').write_text('\n'.join(out),encoding='utf8')
