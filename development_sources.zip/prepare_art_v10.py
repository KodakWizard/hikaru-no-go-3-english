from qa_research_v10 import *
if __name__=='__main__':
 b=decode((WORK/'extracted/2D/agbctrdl.bpe').read_bytes())
 for n,o in resources(b):
  if n in ['cau11.D4','cau12.D4']:
   im,desc=texture(b,o);im.save(OUT/(n+'.png'));print(n,desc[:3])
 b=(WORK/'decoded/2D/bbg.bin').read_bytes()
 for n,o in resources(b):
  if n in ['bbg11_0.D4','bbg11_1.D4']:
   im,_=texture(b,o);im.resize((im.width*4,im.height*4)).save(OUT/(n+'_large.png'));print(n,im.size)
