from pathlib import Path
import json,textwrap,re
from bubble_text_v52 import SHORT
R=Path(__file__).resolve().parent;W=R/'translation_work/qa_v52'

def prepare(before):
    original=(R/'translation_work/main.dol').read_bytes();after=bytearray(before)
    meta=json.loads((R/'translation_work/disc_metadata.json').read_text())
    rows=json.loads((W/'battle_bubble_audit.json').read_text(encoding='utf8'))
    corpus=json.loads((W/'current_corpus.json').read_text(encoding='utf8'))
    starts={int(r['location'],16) for r in corpus if r['area']=='dol'}
    protected=set()
    for folder,key in [('English_Interface_v08','name_display'),('English_Content_v11','hud_names'),('English_Polish_v12','font_uv')]:
        rr=json.loads((R/folder/'build_report.json').read_text(encoding='utf8'))
        protected.update(int(p,16) for p in rr[key]['reclaimed_words'])
    changes=[];writes=[];errors=[];ranges=[];checked=[]
    for row in rows:
        at=int(row['offset'],16);old=before[at:before.index(0,at)].decode('cp932')
        assert old==row['current'],(hex(at),old,row['current'])
        en=SHORT.get(at) or '\u2193'.join(textwrap.wrap(old.replace('\u2193',' '),18,break_long_words=False,break_on_hyphens=False))
        lines=en.split('\u2193');raw=en.encode('cp932')+b'\0'
        assert re.findall(r'\$[0-9]|%[-0-9]*[sd]',old)==re.findall(r'\$[0-9]|%[-0-9]*[sd]',en)
        jp=original[at:original.index(0,at)];assert jp.decode('cp932')==row['japanese']
        original_end=at+len(jp)+1;slot_end=(original_end+3)&~3
        problems=[]
        if len(lines)>3 or max(map(len,lines))>18:problems.append('18x3 layout')
        if at+len(raw)>slot_end:problems.append('storage')
        if any(at<p+4 and p<at+len(raw) for p in protected):problems.append('protected words')
        if problems:
            errors.append(dict(row,new=en,problems=problems,used=len(raw)-1,slot_capacity=slot_end-at-1));continue
        checked.append(dict(offset=hex(at),lines=lines,word_boundary_wrap=at not in SHORT))
        if en==old:continue
        extra=max(0,at+len(raw)-original_end)
        if extra:
            assert original[original_end:at+len(raw)]==before[original_end:at+len(raw)]==bytes(extra),(hex(at),'padding not zero')
            assert not any(original_end<=p<at+len(raw) for p in starts)
            for p in range(original_end,at+len(raw)):
                assert (p+0x80003000).to_bytes(4,'big') not in original[0x220000:]
        after[at:at+len(raw)]=raw;ranges.append((at,at+len(raw)))
        writes.append((meta['dol_offset']+at,raw,'Battle '+hex(at)))
        changes.append(dict(area='Mid-game battle bubble',offset=hex(at),japanese=row['japanese'],before=old,after=en,
                            wording_shortened=at in SHORT,capacity_bytes=len(jp),used_bytes=len(raw)-1,
                            alignment_padding_used=extra,lines=len(lines),maximum_cells=max(map(len,lines))))
    (W/'bubble_fit_errors.json').write_text(json.dumps(errors,ensure_ascii=False,indent=2),encoding='utf8')
    if errors:
        print('\n'.join(f"{r['offset']} {r['problems']} [{r['used']}/{r['slot_capacity']}] {r['new']!r}" for r in errors))
        raise AssertionError(f'{len(errors)} bubble fit issues')
    cursor=0
    for lo,hi in sorted(ranges):assert before[cursor:lo]==after[cursor:lo];cursor=hi
    assert before[cursor:]==after[cursor:]
    assert len(checked)==796
    (W/'battle_bubble_checked.json').write_text(json.dumps(checked,indent=2),encoding='utf8')
    (W/'battle_bubble_changes_prepared.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),encoding='utf8')
    print(len(checked),'battle entries checked;',len(changes),'changed;',sum(r['wording_shortened'] for r in changes),'shortened')
    return bytes(after),writes,changes

if __name__=='__main__':
    from prepare_text_v52 import prepare as punctuation
    before,_,_,_=punctuation(R/'English_QA_v51/Hikaru no Go 3 - English QA v51.iso')
    prepare(before)
