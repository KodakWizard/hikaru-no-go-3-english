"""Reuse verified GameCube exercise translations for all five GBA books.

The GBA headers really are narrow sidebars: wrap at 12 cells, six lines.
Feedback uses the reviewed 22-cell/three-line English wording.
"""
from pathlib import Path
import json,re,unicodedata,textwrap
from qa_research_v10 import current_files
from gcs_text import text_tail
from gba_translation_v34 import TEXT as GBA_MATCH

R=Path(__file__).parent;W=R/'translation_work'
BASE=R/'English_GBA_v34/Hikaru no Go 3 - English GBA v34.iso'

def norm(s):return re.sub(r'[\s\u2193]','',unicodedata.normalize('NFKC',s))

def normalized_english(s,width,lines):
    s=' '.join(s.replace('\u2193',' ').split())
    if width==12:
        s=s.replace('Counterattack','Counter').replace('counterattack','counter')
        s=s.replace('overextension','wide extension')
        s=re.sub(r'(?<=[A-Za-z])-(?=[A-Za-z])',' ',s)
    rows=textwrap.wrap(s,width=width,break_long_words=False,break_on_hyphens=False)
    assert len(rows)<=lines and max(map(len,rows))<=width,(s,rows)
    return '\u2193'.join(rows)

COMMON={
0x93798:'Hikaru',0x937a0:'Hard Life/Death',0x937ac:'Hidden Tesuji',
0x937bc:'Connections',0x937c4:'Captures: Adv.',0x937d0:'Semeai',
0x937dc:'Bigger Yose',0x937f4:'Midgame',0x937fc:'9x9 Yose',
0x93808:'Punish Errors',0x93818:'Joseki Choice',
0x93828:'Urgent Points',0x93840:'Moyo Borders',
0x93858:'Extensions',0x9386c:'Invasions',
0x93878:'Yose: Advanced',0x93888:'Tactics',0x93890:'Komoku Joseki',
0x938a0:'Yose Tesuji',0x938ac:'Life/Death',0x938b4:'Escape',
0x938bc:'Star-Point Joseki',0x938cc:'Fighting',0x938d8:'Life/Death',
0x938e0:'Cutting',0x938e8:'Connecting',0x938f0:'Capturing',
0x938f8:'Basic Life/Death',0x93904:'Basic Cuts',0x93910:'Basic Links',
0x9391c:'Atari/Defence',0x9392c:'Atari/Capture',
0x9393c:'Save complete.',0x93954:'Save failed.',0x93980:'No.%2d',
}
EXTRA={
norm('\u6b63\u89e3\u3067\u3059\u3002'):'Correct.',
norm('\u307b\u307c\u6b63\u89e3\u3067\u3059\u3002'):'Almost right.',
norm('\u5931\u6557\u3067\u3059\u3002'):'Failed.',
norm('\u3053\u306e\u624b\u3067\u3088\u3044\u3067\u3059\u304b\uff1f'):'Play this move?',
}
for n in range(11):
    EXTRA[norm((str(n) if n==10 else chr(0xff10+n))+'\u70b9\u3067\u3059\u3002')]=f'{n} points.' if n!=1 else '1 point.'

def prepare():
    f,_,files=current_files(BASE);lookup={}
    for path,(offset,size,_) in files.items():
        if not path.startswith(('script/drill/dri_','script/mission/mis_')):continue
        original=(W/'extracted'/path).read_bytes();base,_,rows=text_tail(original)
        f.seek(offset);current=f.read(size)
        for row in rows:
            refs=[p for p in row['references'] if int.from_bytes(original[p-4:p],'big') in (0x87,0xa6,0x103)]
            assert refs
            at=base+int.from_bytes(current[refs[0]:refs[0]+4],'big')
            en=current[at:current.index(0,at)].decode('cp932')
            lookup.setdefault(norm(row['japanese']),[]).append((en,path))
    f.close()
    original_match=(W/'gba_audit/btlmenu.gba').read_bytes()
    for at,en in GBA_MATCH.items():
        jp=original_match[at:original_match.index(0,at)].decode('cp932')
        lookup.setdefault(norm(jp),[]).append((en,'gba_translation_v34.py'))
    candidates=json.loads((W/'gba_audit/tutorial_candidates.json').read_text(encoding='utf8'))
    modules={}
    for k,rows in candidates.items():
        rom=(W/f'gba_audit/tutorial{k}.gba').read_bytes();out=[]
        for row in rows:
            at=row['offset'];jp=row['japanese']
            if at==0x93624:continue # Native kanji-number conversion table, not dialogue.
            if at<0xa0000:
                en=COMMON[at];source='gba_books_v35 common labels'
            elif norm(jp) in EXTRA:en=EXTRA[norm(jp)];source='gba_books_v35 feedback'
            else:
                choices=lookup[norm(jp)]
                en,source=min(choices,key=lambda p:len(p[0].encode('cp932')))
            header=bool(re.match(r'[１２３４５1-5][－-]',jp))
            if header:en=normalized_english(en,12,6)
            elif at>=0xa0000:en=normalized_english(en,22,3)
            assert re.findall(r'%[-0-9]*[sd]|\$[0-9]',jp)==re.findall(r'%[-0-9]*[sd]|\$[0-9]',en),(k,hex(at),jp,en)
            refs=sorted({int(p,16) for base,ps in row['refs'] for p in ps if base=='0x9f00000' and int(p,16)%4==0})
            assert refs
            if at>=0xa0000:
                for p in refs:
                    op=int.from_bytes(rom[p-4:p],'little')
                    if k!='5' and jp not in ('\u306f\u3044','\u3044\u3044\u3048'):
                        assert op in (0x54000000,0x63000000),(k,hex(at),hex(p),hex(op))
                    else:assert p>=0xa0000
            out.append(dict(offset=at,japanese=jp,english=en,header=header,source=source,references=refs))
        numbers={int(re.match(r'[1-5]-(\d+)',unicodedata.normalize('NFKC',r['japanese']))[1]) for r in out if r['header']}
        assert numbers==set(range(1,51))
        assert sum(r['header'] for r in out)==(55 if k=='4' else 50)
        modules[k]=out
    (R/'gba_books_manifest_v35.json').write_text(json.dumps(modules,ensure_ascii=False,indent=2),encoding='utf8')
    print('Prepared',sum(len(v) for v in modules.values()),'per-program entries; 250 exercise headers.',flush=True)
    return modules

if __name__=='__main__':prepare()
