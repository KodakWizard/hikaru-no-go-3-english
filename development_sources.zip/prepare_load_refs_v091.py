﻿from pathlib import Path
p=Path('research_cards_v09.py');s=p.read_text(encoding='utf8');s=s[s.index('regs={};hits=[]'):];s=s.replace('(0x80233b3c,0x80230a14,0x80230a20)','(0x80253720,0x80253bcc,0x80253bd8)');Path('research_load_refs_v091.py').write_text('from pathlib import Path\n'+s,encoding='utf8')
