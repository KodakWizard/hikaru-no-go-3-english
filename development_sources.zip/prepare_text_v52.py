from pathlib import Path
import json,re,struct
from punctuation_v52 import SUFFIX,GBA
from check_dialogue_v50 import wrap
from qa_research_v10 import current_files
from gba_lz_v34 import decode,encode_optimal
from gba_polish_v50 import independent_decode

R=Path(__file__).resolve().parent;W=R/'translation_work/qa_v52'
def prepare(base):
    meta=json.loads((R/'translation_work/disc_metadata.json').read_text())
    orig=(R/'translation_work/main.dol').read_bytes()
    with Path(base).open('rb') as f:f.seek(meta['dol_offset']);before=f.read(len(orig))
    dol=bytearray(before);writes=[];changes=[];ranges=[]
    candidates=json.loads((W/'punctuation_candidates.json').read_text(encoding='utf8'))
    corpus=json.loads((W/'current_corpus.json').read_text(encoding='utf8'))
    starts={int(r['location'],16) for r in corpus if r['area']=='dol'}
    protected=set()
    for folder,key in [('English_Interface_v08','name_display'),('English_Content_v11','hud_names'),('English_Polish_v12','font_uv')]:
        report=json.loads((R/folder/'build_report.json').read_text(encoding='utf8'))
        protected.update(int(p,16) for p in report[key]['reclaimed_words'])
    for i,suffix in SUFFIX.items():
        row=candidates[i];assert row['area']=='dol'
        en=wrap(row['current'].replace('\u2193',' ')+suffix)
        assert len(en.split('\u2193'))<=3 and max(map(len,en.split('\u2193')))<=26
        assert re.findall(r'\$[0-9]|%[-0-9]*[sd]',en)==re.findall(r'\$[0-9]|%[-0-9]*[sd]',row['current'])
        raw=en.encode('cp932')+b'\0'
        for loc in row['locations']:
            at=int(loc['location'],16);jp=orig[at:orig.index(0,at)]
            assert before[at:before.index(0,at)].decode('cp932')==row['current']
            assert jp.decode('cp932')==row['japanese']
            original_end=at+len(jp)+1;slot_end=(original_end+3)&~3
            assert at+len(raw)<=slot_end,(hex(at),len(raw),slot_end-at)
            extra=max(0,at+len(raw)-original_end)
            if extra:
                assert orig[original_end:at+len(raw)]==before[original_end:at+len(raw)]==bytes(extra)
                assert not any(original_end<=p<at+len(raw) for p in starts)
                # No data pointer identifies the padding bytes as a live object.
                for p in range(original_end,at+len(raw)):
                    assert (p+0x80003000).to_bytes(4,'big') not in orig[0x220000:]
            assert not any(at<p+4 and p<at+len(raw) for p in protected)
            dol[at:at+len(raw)]=raw;ranges.append((at,at+len(raw)))
            writes.append((meta['dol_offset']+at,raw,'DOL '+hex(at)))
            changes.append(dict(area='GameCube dialogue',offset=hex(at),japanese=row['japanese'],
                                before=row['current'],after=en,alignment_padding_used=extra,
                                capacity_bytes=len(jp),used_bytes=len(raw)-1))
    for i in range(7):
        o=int.from_bytes(orig[i*4:i*4+4],'big');n=int.from_bytes(orig[0x90+i*4:0x94+i*4],'big')
        if n:assert orig[o:o+n]==before[o:o+n]==dol[o:o+n]
    for p in protected:assert before[p:p+4]==dol[p:p+4]
    cursor=0
    for lo,hi in sorted(ranges):assert before[cursor:lo]==dol[cursor:lo];cursor=hi
    assert before[cursor:]==dol[cursor:]

    f,_,files=current_files(base);pieces=[];paths=[]
    for i in range(45):
        path=f'gba/dacs/magnet/btlmenu_dacs_{i}'+('_LZ.bin' if i<40 else '.bin')
        o,n,_=files[path];f.seek(o);stored=f.read(n)
        pieces.append(decode(stored) if i<40 else stored);paths.append((path,o,stored))
    rom=b''.join(pieces);original=(R/'translation_work/gba_audit/btlmenu.gba').read_bytes();new=bytearray(rom)
    allowed=[]
    for at,en in GBA.items():
        jp=original[at:original.index(0,at)].decode('cp932');old=rom[at:rom.index(0,at)].decode('cp932')
        assert en==old+'.'
        assert len(en.encode('cp932'))<=len(jp.encode('cp932'))+3
        ptr=(0x09f00000+at).to_bytes(4,'little')
        refs=[p for p in range(len(original)-3) if original[p:p+4]==ptr]
        assert refs and all(rom[p:p+4]==ptr for p in refs)
        raw=en.encode('cp932')+b'\0';end=at+len(raw);original_end=at+len(jp.encode('cp932'))+1
        assert end<=(original_end+3)&~3
        if end>original_end:
            assert original[original_end:end]==rom[original_end:end]==bytes(end-original_end)
        new[at:end]=raw;allowed.append((at,end))
        changes.append(dict(area='GBA match instruction',offset=hex(at),japanese=jp,before=old,after=en,
                            direct_references=[hex(p) for p in refs],alignment_padding_used=max(0,end-original_end)))
    cursor=0
    for lo,hi in sorted(allowed):assert rom[cursor:lo]==new[cursor:lo];cursor=hi
    assert rom[cursor:]==new[cursor:]
    blobs={};cursor=0
    for i,(part,(path,off,stored)) in enumerate(zip(pieces,paths)):
        result=bytes(new[cursor:cursor+len(part)]);cursor+=len(part)
        if result==part:continue
        assert i<40
        encoded=encode_optimal(result)
        assert len(encoded)<=len(stored),(path,len(encoded),len(stored))
        packed=encoded+bytes(len(stored)-len(encoded))
        assert decode(packed)==independent_decode(packed)==result
        blobs[path]=(off,packed,result)
    f.close()
    return bytes(dol),writes,blobs,changes

if __name__=='__main__':
    dol,writes,blobs,changes=prepare(R/'English_QA_v51/Hikaru no Go 3 - English QA v51.iso')
    (W/'punctuation_changes_prepared.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),encoding='utf8')
    print(len(changes),'punctuation occurrences;',len(blobs),'GBA native segments;',sum(r.get('alignment_padding_used',0)>0 for r in changes),'use verified alignment padding')
