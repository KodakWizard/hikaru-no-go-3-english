﻿from PIL import Image
from title_art_v08 import english_title
english_title(Image.open('translation_work/ui_v08/title_title_tit02.D4.png').convert('RGBA')).save('translation_work/ui_v08/title_english_preview.png')
