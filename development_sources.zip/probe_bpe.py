from pathlib import Path
data=Path('translation_work/extracted/2D/cursor.bpe').read_bytes()
for start in (0,3,4,8):
 for skip in (127,128):
  for endian in ('big','little'):
   try:
    pos=start; out=bytearray()
    while pos<len(data):
     l=list(range(256)); r=[0]*256;c=0
     while c<256:
      n=data[pos];pos+=1
      if n>127:c+=n-skip;n=0
      if c>=256:break
      for _ in range(n+1):
       l[c]=data[pos];pos+=1
       if l[c]!=c:r[c]=data[pos];pos+=1
       c+=1
     n=int.from_bytes(data[pos:pos+2],endian);pos+=2
     if n>len(data)-pos:raise ValueError('block length')
     for v in data[pos:pos+n]:
      st=[v];ops=0
      while st:
       x=st.pop();ops+=1
       if ops>10000 or len(out)>1000000:raise ValueError('cycle')
       if l[x]==x:out.append(x)
       else:st.extend((r[x],l[x]))
     pos+=n
    print('OK',start,skip,endian,len(out),out[:80]);Path(f'translation_work/probe_{start}_{skip}_{endian}.bin').write_bytes(out)
   except Exception as e: print(start,skip,endian,str(e),pos,len(out))
