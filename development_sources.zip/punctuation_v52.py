"""Reviewed sentence endings, excluding labels and continuing dialogue."""
SUFFIX={
0:'...',1:'.',2:'.',3:'!',4:'.',5:'.',6:'.',7:'.',8:'.',9:'.',
10:'.',11:'.',12:'.',13:'.',14:'.',15:'.',16:'.',17:'.',18:'.',19:'.',
20:'.',21:'!',22:'!',23:'.',24:'.',25:'?',26:'.',27:'!',28:'.',
30:'!',31:'.',32:'!',33:'!',
}
# IDs above are immutable reviewed candidates generated from finished v51.
# GBA instructions are addressed separately; menu/status/score labels stay bare.
GBA={0x48d44:'Fill land\u2193with captures.',0x49114:'Choose an option.'}
