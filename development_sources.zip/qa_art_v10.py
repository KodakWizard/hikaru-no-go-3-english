"""Native UI repairs. Preserve counter geometry outside letter regions."""
from PIL import Image,ImageDraw
from collections import Counter
from textures import resources,texture
from smooth_art import render_label
def label(size,text,maxsize=18,colour=(255,255,255,255)):
 return render_label(Image.new('RGBA',size),text,max_size=maxsize,margin=2,title=True,text_colour=colour)[0]
def counters(original):
 lookup=dict(resources(original));out={}
 for side in range(2):
  n=f'bbg01_{side}_1.D4';im,_=texture(original,lookup[n]);art=im.copy();x=0 if side==0 else 44
  # Recover flat bar from untouched pixels at its outer edge, row by row.
  for y in range(0,27):
   colour=im.getpixel((0 if side==0 else 121,y))
   ImageDraw.Draw(art).line((x,y,x+77,y),fill=colour)
  art.alpha_composite(label((74,23),'Captures',12),(x+2,1));out[n]=art
  n=f'bbg11_{side}.D4';im,_=texture(original,lookup[n]);art=im.copy()
  # Four lower 56px animation frames carry the active (orange) label.
  # Their bar/round-counter shape stays untouched; lettering occupies y0..23.
  for frame in range(5,8):
   y=frame*56;x0=0 if side==0 else 44
   for yy in range(0,27):
    pixels=[im.getpixel((x0+xx,y+yy)) for xx in range(76)]
    candidates=[p for p in pixels if p[3]<255]
    colour=Counter(candidates or pixels).most_common(1)[0][0]
    art.paste(colour,(x0,y+yy,x0+76,y+yy+1))
   # Remove the old italic outline overhang above the counter's circle.
   edge=(76,y,80,y+17) if side==0 else (42,y,46,y+17)
   art.paste((0,0,0,0),edge)
   # Match the original horizontal label entrance while keeping the bar.
   strip=Image.new('RGBA',(76,27));strip.alpha_composite(label((72,23),'Captures',12),(2-(7-frame)*30 if side==0 else 2+(7-frame)*30,1))
   art.alpha_composite(strip,(x0,y))
  out[n]=art
 return out
def tabs(current):
 out={};lookup=dict(resources(current))
 for i in range(3):
  n=f'fai10_{i}.D4';im,_=texture(current,lookup[n]);art=Image.new('RGBA',im.size)
  safe=min(100,im.width-16);art.alpha_composite(label((safe,im.height),f'Course {i+1}',17),(2,0));out[n]=art
 return out
def padded_ascii(im):
 # Same 16x16 glyph grid / normalized UVs. One transparent texel gutter
 # prevents bilinear sampling from reaching the next glyph's cell.
 out=Image.new('RGBA',(im.width*2,im.height*2),(255,255,255,0))
 for y in range(16):
  for x in range(16):
   cell=im.crop((x*12,y*24,x*12+12,y*24+24)).resize((22,46),Image.Resampling.LANCZOS)
   out.paste(cell,(x*24+1,y*48+1))
 assert all(out.getpixel((x,y))[3]==0 for y in range(out.height) for x in range(out.width) if x%24 in (0,23) or y%48 in (0,47))
 return out
