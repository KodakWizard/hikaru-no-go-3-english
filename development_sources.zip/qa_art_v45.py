"""Screenshot QA edits inside existing native image layouts."""
from PIL import Image,ImageDraw,ImageFilter
from collections import Counter
from textures import texture,resources
from smooth_art import render_label

def edits(path,b):
 r=dict(resources(b));out={}
 def get(n):return texture(b,r[n])[0].copy()
 if path=='title/title.bpe':
  intro=get('tit00.D4');menu=get('tit02.D4')
  # Both title states now use byte-identical approved logo-region pixels.
  mask=Image.new('L',intro.size)
  ImageDraw.Draw(mask).polygon([(60,50),(130,50),(145,97),(235,97),(263,79),(310,75),(355,90),(384,143),(388,225),(360,237),(56,241),(6,231),(3,197),(29,102)],fill=255)
  mask=mask.filter(ImageFilter.GaussianBlur(2));menu.paste(intro,(0,0),mask)
  blackrows=[y for y in range(300,380) if sum(max(menu.getpixel((x,y))[:3])<20 for x in range(640))>620]
  assert blackrows and blackrows==list(range(min(blackrows),max(blackrows)+1))
  lo,hi=min(blackrows)-1,max(blackrows)+2
  # Restore underlying illustration; carry the menu's grid shading through it.
  for x in range(640):
   a=intro.getpixel((x,lo-2));z=menu.getpixel((x,lo-2))
   ratio=[max(.2,min(1.1,z[k]/max(1,a[k]))) for k in range(3)]
   for y in range(lo,hi):
    c=intro.getpixel((x,y));menu.putpixel((x,y),tuple(round(c[k]*ratio[k]) for k in range(3))+(c[3],))
  assert all(a==z for a,z,m in zip(intro.getdata(),menu.getdata(),mask.getdata()) if m==255)
  out['tit02.D4']=menu
  for n,text in [('tit04.D4','STORY'),('tit05.D4','FREE\nMATCH'),('tit06.D4','STORY'),('tit07.D4','FREE\nMATCH')]:
   before=get(n);ink=(255,170,0,255) if n in ('tit04.D4','tit05.D4') else (200,200,200,255)
   art=Image.new('RGBA',before.size)
   label,_=render_label(Image.new('RGBA',(90,46)),text,max_size=22,margin=4,italic=True,title=True,text_colour=ink)
   art.alpha_composite(label,(40,0));out[n]=art
 if path=='2D/roo.bpe':
  for i,text in enumerate(['Talk','Go Lessons','Play Go','Go Outside','Data','Quit Game']):
   n=f'roo03_{i}.D4';im=get(n)
   out[n]=render_label(im,text,max_size=20,margin=2,text_colour=(0,0,0,255),outline_width=0)[0]
 if path=='2D/agbctrdl.bpe':
  for n,text in [('mjw41_0.D4','Saving'),('mjw42_0.D4','Loading')]:
   im=get(n);box=(8,22,66,51)
   colors=Counter(im.crop(box).getdata());bg=max((c for c in colors if c[3]>0 and max(c[:3])>80),key=colors.get)
   im.paste(bg,box)
   label,_=render_label(Image.new('RGBA',(58,29)),text,max_size=14,margin=1,title=True,text_colour=(0,0,0,255),outline_width=0)
   im.alpha_composite(label,box[:2]);out[n]=im
 if path=='2D/rec.bpe':
  im=get('rec03_0.D4');out['rec03_0.D4']=render_label(Image.new('RGBA',im.size),'Change\nPlayer',max_size=17,margin=2,title=True)[0]
  # Keep border, VS and Rank pixels; re-render only the row captions.
  for n,labels in [('rec02_0.D4',[(24,30,300,35,'Standard Matches'),(24,68,320,38,'Survival Matches')]),
                   ('rec02_1.D4',[(3,2,330,25,'Play Time'),(3,29,330,25,'GBA Matches')])]:
   im=get(n);bg=Counter(im.getdata()).most_common(1)[0][0]
   for x,y,w,h,text in labels:
    im.paste(bg,(x,y,min(im.width-3,x+w),min(im.height,y+h)))
    tile=Image.new('RGBA',(w,h),bg)
    label,_=render_label(tile,text,max_size=17,margin=1,text_colour=(255,255,255,255),outline_width=0)
    im.paste(label,(x,y))
   out[n]=im
 if path=='2D/fai.bpe':
  from load_translation_v091 import HEADER_BOXES
  for index in (20,22,28):
   n=f'fai{index}.D4';im=get(n);bg=im.getpixel((130,50))
   fields=['Name','Skill','Rank','Games','Wins','Losses','Draws'] if index!=28 else ['Games','Wins','Losses','Draws']
   for field in fields:
    box=HEADER_BOXES[field];x,y,right,bottom=box
    tile=Image.new('RGBA',(right-x,bottom-y),bg)
    label,_=render_label(tile,field,max_size=10,margin=0,text_colour=(0,0,0,255),outline_width=0)
    im.paste(label,(x,y))
   out[n]=im
 return out
