"""Native screenshot repairs, preserving the original illustrated chrome."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from textures import texture, resources
from smooth_art import render_label
from decode_bpe import decode

def edits(path,b):
 r=dict(resources(b));out={}
 def get(n):return texture(b,r[n])[0].copy()
 def label(size,text,px=16,white=False,stroke=0,italic=False):
  return render_label(Image.new('RGBA',size),text,max_size=px,margin=0,title=True,italic=italic,text_colour=(255,255,255,255) if white else (0,0,0,255),outline_width=stroke)[0]
 if path=='title/title.bpe':
  # Whole approved illustration, without any masked patches or reconstructed strip.
  out['tit02.D4']=get('tit00.D4')
  for n,text in [('tit04.D4','STORY'),('tit05.D4','FREE MATCH'),('tit06.D4','STORY'),('tit07.D4','FREE MATCH')]:
   im=get(n);ink=(255,170,0,255) if n in ('tit04.D4','tit05.D4') else (200,200,200,255)
   tile=render_label(Image.new('RGBA',(170,46)),text,max_size=24,margin=0,title=True,italic=True,text_colour=ink)[0]
   art=Image.new('RGBA',im.size);art.alpha_composite(tile,(0,0));out[n]=art
 if path=='2D/bbg.bpe':
  original=decode(Path('translation_work/extracted/2D/bbg.bpe').read_bytes());look=dict(resources(original))
  for side in (0,1):
   def fix(im,top=0):
    im=im.copy();bx=0 if side==0 else 44;edge=0 if side==0 else 121;cx=100 if side==0 else 22
    art=label((78,28),'Captures',17,True,2,True)
    # Sample unlettered outer edge of each original animation frame.
    for y in range(28):
     bg=((238,238,238,109) if max(12,top)<=y<=26 else ((8,8,8,255) if y==27 else (0,0,0,0)))
     for x in range(bx,bx+78):
      if (x-cx)**2+(y-24)**2>23**2:im.putpixel((x,y),bg)
    art.paste((0,0,0,0),(0,0,78,top))
    merged=im.copy();merged.alpha_composite(art,(bx,0))
    for y in range(28):
     for x in range(bx,bx+78):
      if (x-cx)**2+(y-24)**2>23**2:im.putpixel((x,y),merged.getpixel((x,y)))
    return im
   n=f'bbg01_{side}_1.D4';out[n]=fix(texture(original,look[n])[0])
   n=f'bbg11_{side}.D4';im=texture(original,look[n])[0];art=im.copy()
   for frame,top in [(5,25),(6,20),(7,0)]:art.paste(fix(im.crop((0,frame*56,122,(frame+1)*56)),top),(0,frame*56))
   assert art.crop((0,0,122,280)).tobytes()==im.crop((0,0,122,280)).tobytes()
   out[n]=art
  for i in range(4):
   n=f'bbg19_{i}.D4';im=get(n);box=(5,46,44,65) if i<2 else (80,46,119,65)
   im.paste((255,213,0,255),box);im.alpha_composite(label((39,19),'Pts',15,italic=True),box[:2]);out[n]=im
  for n,text in [('nig01.D4','Odd'),('nig02.D4','Even')]:
   source=get(n);im=Image.new('RGBA',source.size)
   # The kanji overlap the stones. Use the game's clean black-stone sprite.
   stone=get('bbg03.D4').resize((35,35),Image.Resampling.LANCZOS)
   for at in ([(54,59)] if text=='Odd' else [(35,59),(76,59)]):im.alpha_composite(stone,at)
   tile=Image.new('RGBA',(144*6,62*6));dr=ImageDraw.Draw(tile);font=ImageFont.truetype('C:/Windows/Fonts/arialbi.ttf',48*6)
   box=dr.textbbox((0,0),text,font=font,stroke_width=3*6)
   dr.text(((144*6-(box[2]-box[0]))/2-box[0],(62*6-(box[3]-box[1]))/2-box[1]),text,font=font,fill='black',stroke_width=3*6,stroke_fill='white')
   im.alpha_composite(tile.resize((144,62),Image.Resampling.LANCZOS),(0,0));out[n]=im
  for prefix,text in [('bbg30','Thinking'),('bbg31','Counting')]:
   for i in range(4):
    n=f'{prefix}_{i}.D4';im=get(n);box=(7,36,58,53)
    im.paste((255,255,255,255),box);im.alpha_composite(label((51,17),text,11),box[:2]);out[n]=im
 if path=='2D/agbctrdl.bpe':
  for n,text in [('gba01_0.D4','Downloading'),('gba01_1.D4','Preparing')]:
   im=get(n);box=(24,5,125,20);im.paste(im.getpixel((124,7)),box)
   im.alpha_composite(label((101,15),text,12,italic=True),box[:2]);out[n]=im
 if path=='2D/mjw.bpe':
  for n,text in [('mjw15.D4','s'),('mjw16.D4','min')]:
   im=Image.new('RGBA',get(n).size,'white');im.alpha_composite(label(im.size,text,14));out[n]=im
 return out

