"""Restore the title's board grid as an overlay on the approved illustration."""
from PIL import Image,ImageDraw
from textures import resources,texture

def edits(path,b):
 assert path=='title/title.bpe'
 r=dict(resources(b));im=texture(b,r['tit02.D4'])[0].copy()
 scale=6
 overlay=Image.new('RGBA',(im.width*scale,im.height*scale))
 d=ImageDraw.Draw(overlay)
 for x in range(49,640,90):d.line((x*scale,52*scale,x*scale,378*scale),fill=(0,0,0,100),width=scale)
 for y in range(70,379,85):d.line((0,y*scale,640*scale,y*scale),fill=(0,0,0,100),width=scale)
 # The board is behind the logo, as in the original title artwork.
 protect=Image.new('L',overlay.size)
 points=[(60,50),(130,50),(145,97),(235,97),(263,79),(310,75),(355,90),(384,143),(388,225),(360,237),(56,241),(6,231),(3,197),(29,102)]
 ImageDraw.Draw(protect).polygon([(x*scale,y*scale) for x,y in points],fill=255)
 overlay.paste((0,0,0,0),(0,0),protect)
 overlay=overlay.resize(im.size,Image.Resampling.LANCZOS)
 overlay.paste((0,0,0,0),(0,0,640,52))
 overlay.paste((0,0,0,0),(0,379,640,480))
 im.alpha_composite(overlay)
 return {'tit02.D4':im}
