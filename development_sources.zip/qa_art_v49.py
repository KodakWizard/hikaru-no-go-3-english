"""Native Odd/Even and result-atlas typography corrections."""
from PIL import Image,ImageDraw,ImageFont
from textures import resources,texture

def lettering(size,text,font_size=24,stroke=1.5,italic=False):
 scale=6;w,h=size
 font=ImageFont.truetype('C:/Windows/Fonts/arialbi.ttf' if italic else 'C:/Windows/Fonts/arialbd.ttf',font_size*scale)
 sw=round(stroke*scale);box=font.getbbox(text,stroke_width=sw)
 tw,th=box[2]-box[0],box[3]-box[1]
 tile=Image.new('RGBA',(max(w*scale,tw+12),h*scale));dr=ImageDraw.Draw(tile)
 dr.text(((tile.width-tw)/2-box[0],(h*scale-th)/2-box[1]),text,font=font,fill='black',stroke_width=sw,stroke_fill='white')
 # Keep a common cap height; compress only the short MV suffix to its native cell.
 if tw>(w-2)*scale:
  crop=tile.crop(((tile.width-tw)//2,0,(tile.width+tw)//2,h*scale)).resize(((w-2)*scale,h*scale),Image.Resampling.LANCZOS)
  tile=Image.new('RGBA',(w*scale,h*scale));tile.alpha_composite(crop,(scale,0))
 return tile.resize((w,h),Image.Resampling.LANCZOS)

def edits(path,b):
 r=dict(resources(b));out={}
 if path=='2D/bbg.bpe':
  for n,text in [('nig01.D4','Odd'),('nig02.D4','Even')]:
   im=texture(b,r[n])[0].copy();im.paste((0,0,0,0),(0,0,144,59))
   font=ImageFont.truetype('C:/Windows/Fonts/arialbi.ttf',48*6);box=font.getbbox(text)
   tile=Image.new('RGBA',(144*6,56*6));dr=ImageDraw.Draw(tile)
   dr.text(((144*6-(box[2]-box[0]))/2-box[0],(56*6-(box[3]-box[1]))/2-box[1]),text,font=font,fill='black')
   tile=tile.resize((144,56),Image.Resampling.LANCZOS)
   assert all(c[:3]==(0,0,0) for c in tile.getdata() if c[3])
   im.alpha_composite(tile,(0,0));out[n]=im
 if path=='2D/win.bpe':
  grids={
   'win43_0.D4':(32,38,[str(i) for i in range(10)]),
   'win43_1.D4':(32,38,['MV','']),
   'win43_2.D4':(38,42,['W','B','pt','.5']),
   'win43_3.D4':(38,42,[str(i) for i in range(10)]),
   'win43_4.D4':(68,42,['Win','Loss']),
   'win43_5.D4':(138,42,['Time','Jigo','Resign','Draw']),
  }
  for name,(cw,ch,labels) in grids.items():
   im=Image.new('RGBA',texture(b,r[name])[0].size)
   for i,text in enumerate(labels):
    if text:im.alpha_composite(lettering((cw,ch),text),(i*cw,0))
   out[name]=im
 return out
