"""Deterministic native-size typography repairs; no executable or UV changes."""
from PIL import Image,ImageDraw,ImageFont
from collections import Counter
from textures import texture,resources

SCALE=8
def label(size,text,px=16,fill=(255,255,255,255),stroke=0,edge=(0,0,0,255),italic=False):
    """Area-filter coverage masks separately, avoiding Lanczos fringe rings."""
    w,h=size;s=SCALE
    font=ImageFont.truetype('C:/Windows/Fonts/arialbi.ttf' if italic else 'C:/Windows/Fonts/arialbd.ttf',px*s)
    sw=round(stroke*s);box=font.getbbox(text,stroke_width=sw)
    width,height=box[2]-box[0],box[3]-box[1]
    assert height<=(h-2)*s,(text,height,h)
    cw=max(w*s,width+2*s)
    origin=((cw-width)/2-box[0],(h*s-height)/2-box[1])
    a=Image.new('L',(cw,h*s));ImageDraw.Draw(a).text(origin,text,font=font,fill=255,stroke_width=sw,stroke_fill=255)
    ink=Image.new('L',(cw,h*s));ImageDraw.Draw(ink).text(origin,text,font=font,fill=255)
    if cw!=w*s:
        x=(cw-width)//2
        a=a.crop((x,0,x+width,h*s)).resize(((w-2)*s,h*s),Image.Resampling.BOX)
        ink=ink.crop((x,0,x+width,h*s)).resize(((w-2)*s,h*s),Image.Resampling.BOX)
        aa=Image.new('L',(w*s,h*s));aa.paste(a,(s,0));a=aa
        ii=Image.new('L',(w*s,h*s));ii.paste(ink,(s,0));ink=ii
    a=a.resize((w,h),Image.Resampling.BOX);ink=ink.resize((w,h),Image.Resampling.BOX)
    result=Image.new('RGBA',(w,h))
    for y in range(h):
        for x in range(w):
            coverage=a.getpixel((x,y));inside=ink.getpixel((x,y))
            if not coverage:result.putpixel((x,y),edge[:3]+(0,));continue
            t=min(1,inside/coverage) if stroke else 1
            rgb=tuple(round(fill[i]*t+edge[i]*(1-t)) for i in range(3))
            result.putpixel((x,y),rgb+(coverage,))
    return result

CENTERS={'Name':64,'Skill':230,'Rank':300,'Games':372,'Wins':437,'Losses':502,'Draws':567}

def edits(path,b):
    lookup=dict(resources(b));out={}
    def get(n):return texture(b,lookup[n])[0].copy()
    if path=='2D/rec.bpe':
        im=get('rec02_0.D4');bg=Counter(im.getdata()).most_common(1)[0][0]
        # Erase only the prior captions, retaining the original border/VS/Rank.
        for box in [(24,30,324,65),(24,68,344,106)]:im.paste(bg,box)
        for y,text in [(29,'Standard Matches'),(76,'Survival Matches')]:
            im.alpha_composite(label((236,18),text,14),(68,y))
        out['rec02_0.D4']=im
        im=get('rec02_1.D4');bg=Counter(im.getdata()).most_common(1)[0][0]
        im.paste(bg,(3,2,333,54))
        im.alpha_composite(label((170,21),'Play Time',15),(20,2))
        im.alpha_composite(label((236,18),'GBA Matches',14),(55,30))
        out['rec02_1.D4']=im
    if path=='2D/fai.bpe':
        for index in (20,22,28):
            n=f'fai{index}.D4';im=get(n);bg=im.getpixel((130,50))
            # One clean header band; never touch runtime-value rows (y>=40).
            im.paste(bg,(3,27,598,40))
            fields=list(CENTERS) if index!=28 else ['Games','Wins','Losses','Draws']
            for text in fields:
                w=62 if text!='Name' else 100
                im.alpha_composite(label((w,11),text,10,fill=(0,0,0,255)),(round(CENTERS[text]-w/2),27))
            out[n]=im
    if path=='2D/win.bpe':
        im=Image.new('RGBA',get('win30_0.D4').size)
        for i,text in enumerate(['Connect','Capture','Fight','Best']):
            im.alpha_composite(label((im.width,49),text,27,stroke=1.5),(0,i*50))
        out['win30_0.D4']=im
    if path=='font24/hggc24.bpe':
        # Same 192x384 CI4 atlas, same cell coordinates and character advances.
        # Preserve every ink pixel and glyph interior. Only white perimeter
        # coverage is removed to make one transparent pixel between cells.
        im=get('hggc24_a.D4')
        for code in range(32,127):
            if code==92:continue # Preserve the CP932 yen/backslash convention.
            x,y=code%16*12,code//16*24
            for yy in range(24):
                for xx in range(12):
                    if xx not in (0,11) and yy not in (0,23):continue
                    c=im.getpixel((x+xx,y+yy));assert c[:3]==(255,255,255)
                    im.putpixel((x+xx,y+yy),(255,255,255,0))
        out['hggc24_a.D4']=im
    return out
