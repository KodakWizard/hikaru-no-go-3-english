"""Fit complete original glyph cells inside native gutters, without cutting strokes."""
from pathlib import Path
from PIL import Image
from qa_research_v10 import current_files
from decode_bpe import decode
from textures import texture,resources

def edits(current):
    f,_,files=current_files(Path('English_Dialogue_v50/Hikaru no Go 3 - English Dialogue v50.iso'))
    off,size,_=files['font24/hggc24.bpe'];f.seek(off);source=decode(f.read(size));f.close()
    name='hggc24_a.D4';lookup=dict(resources(current));sl=dict(resources(source))
    original,desc=texture(source,sl[name]);before,current_desc=texture(current,lookup[name])
    assert desc==current_desc and original.size==(192,384)
    art=before.copy()
    for code in range(32,127):
        if code==92:continue
        x,y=code%16*12,code//16*24
        cell=original.crop((x,y,x+12,y+24))
        # Fit the full cell, including its original outer outline, rather than
        # clearing its perimeter. Premultiplied filtering preserves coverage.
        inset=cell.convert('RGBa').resize((10,22),Image.Resampling.BOX).convert('RGBA')
        tile=Image.new('RGBA',(12,24),(255,255,255,0));tile.paste(inset,(1,1))
        art.paste(tile,(x,y))
    return {name:art}
