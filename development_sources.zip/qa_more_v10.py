from qa_research_v10 import *
from smooth_art import palette
from PIL import ImageFont
if __name__=='__main__':
 for src in ['2D/bbg','title/title','2D/brs','2D/end','2D/ite']:
  b=decode((WORK/'extracted'/(src+'.bpe')).read_bytes());items=[]
  for n,o in resources(b):
   if not n.endswith('.D4'):continue
   im,desc=texture(b,o)
   if src=='2D/bbg' and 'bbg01' not in n:continue
   im.save(OUT/('original_'+n+'.png'));print(src,n,desc[:3]);im.thumbnail((290,180));items.append((n,im))
  sh=Image.new('RGB',(1200,210*((len(items)+3)//4)),'#405060');d=ImageDraw.Draw(sh)
  for i,(n,im) in enumerate(items):x=i%4*300;y=i//4*210;d.text((x,y),n,fill='white');sh.paste(im,(x,y+20),im)
  sh.save(OUT/(src.split('/')[-1]+'_original_scan.png'))
 # Explicit font sheet cell borders, alpha-only; compare texture gutters.
 b=decode((WORK/'extracted/font24/hggc24.bpe').read_bytes());o=dict(resources(b))['hggc24_a.D4'];im,_=texture(b,o)
 print('font palette',palette(b,o,8));print('row edge alphas',collections.Counter(im.getpixel((x,y))[3] for y in range(im.height) for x in range(im.width) if x%12 in (0,11) or y%24 in (0,23)))
 # Battle name font setter call sites, with immediately preceding arguments.
 lines=(WORK/'disassembly.txt').read_text().splitlines()
 with (OUT/'name_setters.txt').open('w') as f:
  for i,line in enumerate(lines):
   if 'bl 0x800a25c0' in line:f.write('\n'.join(lines[max(0,i-12):i+3])+'\n\n')
