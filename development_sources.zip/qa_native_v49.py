"""Apply QA art to fixed native resource slots; preserve all descriptors/layouts."""
from pathlib import Path
import json,struct
from qa_research_v10 import current_files
from decode_bpe import decode
from encode_bpe import encode
from textures import resources,texture
from smooth_art import write_texture
from archive_edit import rgba_resource
from palette_smooth_v42 import improve
from qa_art_v49 import edits as make_art

def prepare(base,out):
 out=Path(out);f,fst,files=current_files(base)
 inv=json.loads(Path('translation_work/inventory.json').read_text(encoding='utf-8'))
 placement=(max(o+n for o,n,_ in files.values() if o<1085734912)+0x7fff)&~0x7fff
 blobs=[];reports=[]
 for path in ['2D/bbg.bpe','2D/win.bpe']:
  off,size,index=files[path];f.seek(off);original=decode(f.read(size));new=bytearray(original)
  lookup=dict(resources(original));changes=make_art(path,original);ranges=[];rows=[]
  for name,im in changes.items():
   o=lookup[name];before,desc=texture(original,o);fmt,w,h,start=desc
   assert im.size==before.size
   palcheck=None
   if fmt in (8,9):
    palcheck=improve(new,o,im,True)
    if palcheck['accepted']:ranges.append(tuple(palcheck['palette_range']))
    after=write_texture(new,o,im)
    bw,bh=(8,8) if fmt==8 else (8,4)
    n=((w+bw-1)//bw)*bw*((h+bh-1)//bh)*bh//(2 if fmt==8 else 1)
   elif fmt==6:
    raw=rgba_resource(original,o,im);n=len(raw)-64;new[start:start+n]=raw[64:];after=texture(new,o)[0]
    assert im.tobytes()==after.tobytes()
   else:raise AssertionError((path,name,fmt))
   assert texture(new,o)[1]==desc
   ranges.append((start,start+n));after.save(out/(path.split('/')[-1]+'.'+name+'.png'))
   rows.append(dict(name=name,format=fmt,dimensions=[w,h],pixel_range=[start,start+n],palette_fit=palcheck,descriptor_unchanged=True))
  assert len(new)==len(original)
  cursor=0
  for lo,hi in sorted(ranges):assert original[cursor:lo]==new[cursor:lo];cursor=hi
  assert original[cursor:]==new[cursor:]
  packed=encode(new,4096);assert decode(packed)==new
  assert placement+len(packed)<1085734912
  assert all(placement+len(packed)<=e['offset'] or placement>=e['offset']+e['size'] for e in inv)
  assert all(placement+len(packed)<=o or placement>=o+n for o,n,_ in files.values())
  struct.pack_into('>II',fst,index*12+4,placement,len(packed))
  blobs.append((placement,packed,bytes(new)))
  reports.append(dict(path=path,offset=placement,stored=len(packed),previous_decoded=len(original),decoded=len(new),native_layout_and_descriptors_exact=True,edits=rows))
  print(path,len(rows),'QA images; native decoded bytes',len(new),flush=True)
  placement=(placement+len(packed)+0x7fff)&~0x7fff
 f.close()
 return fst,blobs,reports
