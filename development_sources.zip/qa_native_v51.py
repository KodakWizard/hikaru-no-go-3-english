"""Fixed-size native archive edits, with decoded-region and descriptor checks."""
from pathlib import Path
import json,struct
from qa_research_v10 import current_files
from decode_bpe import decode
from encode_bpe import encode
from textures import resources,texture
from smooth_art import write_texture,palette
from palette_smooth_v42 import word
from qa_art_v51 import edits as make_art,CENTERS
from PIL import Image,ImageDraw,ImageFont

PATHS=['2D/rec.bpe','2D/fai.bpe','2D/win.bpe','font24/hggc24.bpe']

def prepare(base,out):
    out=Path(out);out.mkdir(exist_ok=True)
    f,fst,files=current_files(base)
    inv=json.loads(Path('translation_work/inventory.json').read_text(encoding='utf8'))
    placement=(max(o+n for o,n,_ in files.values() if o<1085734912)+0x7fff)&~0x7fff
    blobs={};reports=[];previews=[]
    for path in PATHS:
        off,size,index=files[path];f.seek(off);old=decode(f.read(size));new=bytearray(old)
        lookup=dict(resources(old));changes=make_art(path,old);ranges=[];rows=[]
        for name,im in changes.items():
            o=lookup[name];before,desc=texture(old,o);fmt,w,h,start=desc
            assert fmt in (8,9) and im.size==before.size
            pf,count=struct.unpack_from('>HH',old,o+44)
            if path=='2D/win.bpe':
                assert name=='win30_0.D4' and pf==2 and count>=16
                colors=[(0,0,0,i*255/7) for i in range(8)]+[(255,255,255,i*255/7) for i in range(8)]
                colors += [(round(255*(i+1)/(count-15)),)*3+(255,) for i in range(count-16)]
                for i,c in enumerate(colors):struct.pack_into('>H',new,o+64+2*i,word(c,pf))
                ranges.append((o+64,o+64+count*2))
            after=write_texture(new,o,im)
            bw,bh=(8,8) if fmt==8 else (8,4)
            n=((w+bw-1)//bw)*bw*((h+bh-1)//bh)*bh//(2 if fmt==8 else 1)
            ranges.append((start,start+n))
            assert texture(new,o)[1]==desc and new[o+44:o+48]==old[o+44:o+48]
            # Unchanged resource pixels must survive re-encoding exactly.
            if path=='2D/fai.bpe':
                assert before.crop((0,0,w,27)).tobytes()==after.crop((0,0,w,27)).tobytes()
                assert before.crop((0,40,w,h)).tobytes()==after.crop((0,40,w,h)).tobytes()
            if path.startswith('font'):
                for code in list(range(32))+[92]+list(range(127,256)):
                    box=((code%16)*12,(code//16)*24,(code%16+1)*12,(code//16+1)*24)
                    assert before.crop(box).tobytes()==after.crop(box).tobytes(),code
                for code in range(32,127):
                    if code==92:continue
                    x,y=code%16*12,code//16*24
                    assert all(after.getpixel((x+xx,y+yy))[3]==0 for xx in range(12) for yy in range(24) if xx in (0,11) or yy in (0,23))
                    assert before.crop((x+1,y+1,x+11,y+23)).tobytes()==after.crop((x+1,y+1,x+11,y+23)).tobytes()
            after.save(out/(path.split('/')[-1]+'.'+name+'.png'))
            previews.append((path+'/'+name,before,after))
            rows.append({'name':name,'format':fmt,'dimensions':[w,h],'pixel_range':[start,start+n],
                         'palette_count':count,'palette_format':pf,'descriptor_unchanged':True})
        assert len(new)==len(old)
        cursor=0
        for lo,hi in sorted(ranges):assert old[cursor:lo]==new[cursor:lo];cursor=hi
        assert old[cursor:]==new[cursor:]
        packed=encode(new,4096);assert decode(packed)==new
        assert placement+len(packed)<1085734912
        assert all(placement+len(packed)<=r['offset'] or placement>=r['offset']+r['size'] for r in inv)
        assert all(placement+len(packed)<=o or placement>=o+n for o,n,_ in files.values())
        struct.pack_into('>II',fst,index*12+4,placement,len(packed))
        blobs[path]=(placement,packed,bytes(new))
        reports.append({'path':path,'offset':placement,'previous_stored':size,'stored':len(packed),
                        'decoded':len(new),'previous_decoded':len(old),'edits':rows,
                        'nonpixel_nonpalette_bytes_exact':True})
        placement=(placement+len(packed)+0x7fff)&~0x7fff
        print(path,len(rows),'images; decoded size unchanged',len(new),flush=True)
    f.close()
    # Before/after sheets are decoded native data, not unquantized draft art.
    for pg in range((len(previews)+3)//4):
        batch=previews[pg*4:(pg+1)*4]
        sheet=Image.new('RGB',(1240,240*len(batch)),'#607080');d=ImageDraw.Draw(sheet)
        for i,(name,a,b) in enumerate(batch):
            d.text((5,i*240+4),name+'   BEFORE / AFTER',fill='white')
            if name.endswith('hggc24_a.D4'):
                a=a.crop((0,96,192,168));b=b.crop((0,96,192,168))
            for col,im in enumerate([a,b]):
                im=im.copy();im.thumbnail((605,207))
                if im.width<300:im=im.resize((im.width*2,im.height*2))
                im.thumbnail((605,207));sheet.paste(im,(col*620+4,i*240+26),im)
        sheet.save(out/f'comparison_{pg}.png')
    # Value-position mockup uses unchanged native anchors, not emulator output.
    fai=Image.open(out/'fai.bpe.fai20.D4.png').convert('RGBA')
    font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',24);d=ImageDraw.Draw(fai)
    for name,value in [('Name','D o k i'),('Skill','16 kyu'),('Rank','1'),('Games','8'),('Wins','2'),('Losses','6'),('Draws','0')]:
        d.text((CENTERS[name],43),value,font=font,fill='black',anchor='mt')
    bg=Image.new('RGBA',fai.size,'#bbbbbb');bg.alpha_composite(fai);bg.resize((1200,146)).save(out/'heading_layout_mockup.png')
    return fst,blobs,reports

if __name__=='__main__':
    prepare(Path('English_Dialogue_v50/Hikaru no Go 3 - English Dialogue v50.iso'),Path('translation_work/qa_v51'))
