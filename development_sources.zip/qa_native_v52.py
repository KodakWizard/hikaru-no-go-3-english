from pathlib import Path
import json,struct
from PIL import Image,ImageDraw,ImageOps
from qa_research_v10 import current_files
from decode_bpe import decode
from encode_bpe import encode
from textures import resources,texture
from smooth_art import write_texture
from qa_art_v52 import edits

def prepare(base,out):
    out=Path(out);f,fst,files=current_files(base);path='font24/hggc24.bpe'
    off,size,index=files[path];f.seek(off);old=decode(f.read(size));f.close();new=bytearray(old)
    lookup=dict(resources(old));ranges=[];rows=[]
    for name,art in edits(old).items():
        o=lookup[name];before,desc=texture(old,o);fmt,w,h,start=desc
        assert (fmt,w,h)==(8,192,384)
        after=write_texture(new,o,art);ranges.append((start,start+w*h//2))
        assert texture(new,o)[1]==desc
        for code in range(256):
            x,y=code%16*12,code//16*24
            if code<32 or code>=127 or code==92:
                assert before.crop((x,y,x+12,y+24)).tobytes()==after.crop((x,y,x+12,y+24)).tobytes()
            else:
                assert all(after.getpixel((x+xx,y+yy))[3]==0 for xx in range(12) for yy in range(24) if xx in (0,11) or yy in (0,23))
        after.save(out/'font_ascii_complete_insets.png')
        # Diagnostic samples in both polarities, at native and scaled size.
        text='Results and play time. 123/0!?'
        sheet=Image.new('RGB',(1200,440),'#707070');d=ImageDraw.Draw(sheet)
        for row,(atlas,negative) in enumerate([(before,False),(after,False),(before,True),(after,True)]):
            strip=Image.new('RGBA',(12*len(text),24))
            for i,ch in enumerate(text):
                code=ord(ch);cell=atlas.crop((code%16*12,code//16*24,code%16*12+12,code//16*24+24))
                if negative:
                    rgb=ImageOps.invert(cell.convert('RGB'));rgb.putalpha(cell.getchannel('A'));cell=rgb
                strip.alpha_composite(cell,(12*i,0))
            d.text((5,row*110+4),('v51' if row%2==0 else 'v52 complete inset')+(' white/black diagnostic' if negative else ' black/white diagnostic'),fill='white')
            strip=strip.resize((strip.width*3,72),Image.Resampling.BILINEAR);sheet.paste(strip,(5,row*110+25),strip)
        sheet.save(out/'outline_comparison.png')
        rows.append(dict(name=name,format=fmt,dimensions=[w,h],pixel_range=ranges[-1],
                         complete_source_cells=94,inset_dimensions=[10,22],cell_dimensions=[12,24],
                         original_palette_and_descriptor_exact=True,other_cells_exact=True))
    cursor=0
    for lo,hi in sorted(ranges):assert old[cursor:lo]==new[cursor:lo];cursor=hi
    assert old[cursor:]==new[cursor:] and len(new)==len(old)
    packed=encode(new,4096);assert decode(packed)==new
    placement=(max(o+n for o,n,_ in files.values() if o<1085734912)+0x7fff)&~0x7fff
    inv=json.loads(Path('translation_work/inventory.json').read_text(encoding='utf8'))
    assert placement+len(packed)<1085734912
    assert all(placement+len(packed)<=r['offset'] or placement>=r['offset']+r['size'] for r in inv)
    assert all(placement+len(packed)<=o or placement>=o+n for o,n,_ in files.values())
    struct.pack_into('>II',fst,index*12+4,placement,len(packed))
    report=dict(path=path,offset=placement,stored=len(packed),decoded=len(new),previous_decoded=len(old),
                previous_stored=size,edits=rows,nonpixel_bytes_and_palette_exact=True)
    return fst,{path:(placement,packed,bytes(new))},[report]

if __name__=='__main__':
    p=Path('translation_work/qa_v52');p.mkdir(exist_ok=True)
    prepare(Path('English_QA_v51/Hikaru no Go 3 - English QA v51.iso'),p)
