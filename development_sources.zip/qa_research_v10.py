from pathlib import Path
import json,struct,textwrap,collections
from PIL import Image,ImageDraw
from textures import resources,texture
from decode_bpe import decode
from tutorial_translation_v07 import LESSONS
ROOT=Path(__file__).parent;WORK=ROOT/'translation_work';OUT=WORK/'qa_v10';OUT.mkdir(exist_ok=True)
def current_files(iso=None):
 m=json.loads((WORK/'disc_metadata.json').read_text());f=open(iso or ROOT/'English_Load_v091/Hikaru no Go 3 - English Load v091.iso','rb');f.seek(m['fst_offset']);fst=bytearray(f.read(m['fst_size']));n=int.from_bytes(fst[8:12],'big');names=fst[n*12:];stack=[('',n)];files={}
 for i in range(1,n):
  while i>=stack[-1][1]:stack.pop()
  word,o,s=struct.unpack_from('>III',fst,i*12);name=names[word&0xffffff:].split(b'\0')[0].decode('cp932');p=stack[-1][0]+name
  if word>>24:stack.append((p+'/',s))
  else:files[p]=(o,s,i)
 return f,fst,files
if __name__=='__main__':
 for name,rows in LESSONS.items():
  for i,s in enumerate(rows):
   lines=sum([textwrap.wrap(x,22,break_long_words=False,break_on_hyphens=False) or [''] for x in s.split('\n')],[])
   if len(lines)>3:print(name,i,repr(s),' -> ',lines)
 b=(WORK/'main.dol').read_bytes()
 for lo,hi in [(0x250200,0x250800),(0x262a00,0x262b10),(0x268e30,0x268f40)]:
  p=lo
  while p<hi:
   e=b.find(b'\0',p);raw=b[p:e]
   if raw:
    try:print(hex(p),repr(raw.decode('cp932')))
    except:pass
   p=e+1
 f,fst,files=current_files()
 for src in ['2D/bbg.bpe','font24/hggc24.bpe']:
  o,s,_=files[src];f.seek(o);data=decode(f.read(s))
  for name,at in resources(data):
   if 'bbg01' in name or name=='hggc24_a.D4':
    im,desc=texture(data,at);im.save(OUT/('current_'+name+'.png'));print(src,name,desc[:3])
    if name=='hggc24_a.D4':print(collections.Counter(im.getdata()).most_common(20))
 # Contact sheets of the small UI archives, to find the resident loading image.
 for src in ['2D/mjw','2D/scs','2D/sco','2D/rec','2D/ite','2D/agbctrdl']:
  data=(WORK/'decoded'/(src+'.bin')).read_bytes();items=[]
  for name,at in resources(data):
   if name.endswith('.D4'):
    im,_=texture(data,at);im.thumbnail((290,120));items.append((name,im))
  sheet=Image.new('RGB',(1200,145*((len(items)+3)//4)),'#405060');d=ImageDraw.Draw(sheet)
  for i,(name,im) in enumerate(items):x=i%4*300;y=i//4*145;d.text((x,y),name,fill='white');sheet.paste(im,(x,y+20),im)
  sheet.save(OUT/(src.split('/')[-1]+'_scan.png'))
