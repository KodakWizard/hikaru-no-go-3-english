"""Kifu numbers and conservative card-dialogue wrapping, read from v44."""
from pathlib import Path
import ast,json,re
R=Path(__file__).parent
ORIGINAL=(R/'translation_work/main.dol').read_bytes()
with (R/'English_Kifu_v44/Hikaru no Go 3 - English Kifu v44.iso').open('rb') as f:
 f.seek(125952);CURRENT=f.read(len(ORIGINAL))
TEXT={0x2dad98:'B',0x2dad9c:'W'}
for i in range(10):TEXT[0x2773b8+10*i]=str(i+1)
for i in range(19):TEXT[0x277478+10*i]=str(i+1)

def width(s):
 return len(re.sub(r'%[-0-9]*s','X'*16,re.sub(r'%[-0-9]*d','9999',s)))

def wrap(line,limit=32):
 rows=[];current=''
 for word in line.split():
  candidate=current+' '+word if current else word
  if width(candidate)>limit and current:rows.append(current);current=word
  else:current=candidate
 if current:rows.append(current)
 return rows or ['']

offsets=set()
for path in R.glob('*.py'):
 if path.name.startswith('build_'):continue
 try:tree=ast.parse(path.read_text(encoding='utf-8-sig'))
 except (UnicodeError,SyntaxError):continue
 for node in ast.walk(tree):
  if isinstance(node,ast.Dict):
   offsets.update(k.value for k in node.keys if isinstance(k,ast.Constant) and isinstance(k.value,int) and 0x22d400<=k.value<0x231900)
AUDIT=[]
for at in sorted(offsets):
 try:old=CURRENT[at:CURRENT.index(0,at)].decode('cp932')
 except (ValueError,UnicodeError):continue
 if not old or any(ord(c)>127 for c in old):continue
 if at in (0x2308fc,0x230170):continue # Metadata / concatenated control arguments.
 new=old.replace('Do not remove card or turn off power.','Keep card inserted.\nLeave power on.')
 if at in (0x230970,0x230a20,0x230cfc,0x230db8):
  new="%s card is full.\n%s needs 1 file\nand %d blocks.\nUse the console's Memory\nCard screen to free space."
 if new==old and any(width(line)>32 for line in new.split('\n')):
  new=' '.join(new.split())
 rows=[part for line in new.split('\n') for part in wrap(line)]
 new='\n'.join(rows)
 assert not any(re.fullmatch(r'[.,!?;:]+',line.strip()) for line in rows),(hex(at),rows)
 assert len(rows)<=6,(hex(at),rows)
 AUDIT.append(dict(offset=hex(at),before=old,after=new,estimated_cells=max(map(width,rows)),lines=len(rows)))
 if new!=old:TEXT[at]=new
EXPECTED={at:CURRENT[at:CURRENT.index(0,at)].decode('cp932') for at in TEXT}
