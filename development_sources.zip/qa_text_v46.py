"""Equal seven-cell integer rows in the centered estimate display."""
TEXT={0x2d9044:'B%6d',0x2d904c:'W%6d'}
EXPECTED={0x2d9044:'B %4d',0x2d904c:'W %4d'}
AUDIT=[]
for value in (0,1,11,99,361):
 for prefix in ('B','W'):
  row=(prefix+'%6d')%value
  komi='Komi %2d'%0
  assert len(row)==len(komi)==7
  assert row.rindex(str(value)[-1])==komi.rindex('0')==6
