"""Half-komi suffix and result-score ordering; preserve values and tokens."""
TEXT={0x2d8adc:'.5',0x24ba98:'%s +%spt',0x24baa8:'%s +%s%spt'}
EXPECTED={0x2d8adc:'\u534a',0x24ba98:'%spt +%spt',0x24baa8:'%spt +%spt%s'}
AUDIT=[]
