"""Screenshot corrections; original and earlier translation dictionaries retained."""
import copy,textwrap,unicodedata
from tutorial_translation_v07 import LESSONS as PREVIOUS
LESSONS=copy.deepcopy(PREVIOUS)
REVISIONS={
 ('tuto1_01',20):'In Japanese, count stones as one shi, two shi, and so on.',
 ('tuto1_01',30):'Top-right, top-left, bottom-right, bottom-left.',
 ('tuto1_02',33):'2. Connected stones are captured when all liberties are filled.',
 ('tuto1_04',23):'Each empty point in your territory is worth one point.',
 ('tuto1_06',35):'Black must play away. White can then save stone 4.',
}
for (name,i),text in REVISIONS.items():LESSONS[name][i]=text
def cells(s):return sum(2 if unicodedata.east_asian_width(c) in ('W','F') else 1 for c in s)
def wrap(s):
 out=[]
 for line in s.split('\n'):
  current=''
  for word in line.split():
   candidate=(current+' '+word).strip()
   if current and cells(candidate)>22:out.append(current);current=word
   else:current=candidate
  out.append(current)
 assert len(out)<=3,(s,out)
 assert all(cells(x)<=22 for x in out),(s,out)
 return '\n'.join(out)
TEXT={
 0x250210:'Choose a lesson.',
 0x2502b0:'About Go',0x2502bc:'Capturing',0x2502cc:'No Play',
 0x2502d8:'Scoring',0x2502e8:'Life/Death',0x2502f8:'Ko/Seki',
 0x250304:'Shicho',0x250310:'Snapback and Oiotoshi',
 0x25032c:'How to Live',0x250340:'How to Kill',0x250350:'Fuseki',
 0x250360:'Stone Shapes',0x250370:'Middle Game',0x250380:'Making Territory',
 0x250394:'Endgame',0x2503a4:'Ending Play',
 0x2503b4:'Atari: Take',0x2503c4:'Atari: Save',0x2503d4:'Connect',
 0x2503e0:'Cutting',0x2503ec:'Life/Death',0x2503f8:'Fighting',
 0x250404:'Star Joseki',0x250414:'Yose',0x250420:'Komoku Joseki',
 0x250430:'Advanced Yose',0x250440:'Invasion',0x25044c:'Hiraki',
 0x250460:'Next Move: Moyo',0x250478:'Big or Urgent?',0x250490:'Choose Joseki',
 0x2504a0:'Punish Errors',0x2504b0:'9x9 Yose',0x2504bc:'Which Yose Is Bigger?',
 0x2504d4:'Semeai',0x2504e0:'Capturing',0x2504ec:'Inside Play',0x2504fc:'Tsumego',
 0x250508:'Problems 1: Introduction  %2d/50',0x250534:'Problems 2: Beginner      %2d/50',
 0x250560:'Problems 3: Intermediate  %2d/50',0x25058c:'Problems 4: Advanced      %2d/50',
 0x2505b8:'Problems 5: Applications  %2d/50',
 0x2507ac:'Course 1: Basic Rules',0x2507c4:'Course 2: Tesuji',0x2507d8:'Course 3: Play',
 0x262a74:'Ah, how nostalgic.',0x268ea0:'Ah, how nostalgic.',
}
