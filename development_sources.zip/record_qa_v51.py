from pathlib import Path
import json
from qa_research_v10 import current_files
from decode_bpe import decode
from textures import resources,texture
R=Path(__file__).resolve().parent;out=R/'English_QA_v51'
report=json.loads((out/'build_report.json').read_text(encoding='utf8'))
images=[]
for iso in [R/'English_Dialogue_v50/Hikaru no Go 3 - English Dialogue v50.iso',out/'Hikaru no Go 3 - English QA v51.iso']:
    f,_,files=current_files(iso);o,n,_=files['font24/hggc24.bpe'];f.seek(o);b=decode(f.read(n));f.close()
    images.append(texture(b,dict(resources(b))['hggc24_a.D4'])[0])
changed=[]
for y in range(384):
    for x in range(192):
        a=images[0].getpixel((x,y));b=images[1].getpixel((x,y))
        if a==b:continue
        assert a[:3]==b[:3]==(255,255,255) and b[3]==0
        assert x%12 in (0,11) or y%24 in (0,23)
        changed.append((x,y))
report['font_perimeter_pixels_cleared']=len(changed)
report['font_interiors_and_black_gray_ink_exact']=True
(out/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
(out/'QA_AUDIT.md').write_text(f'''# v51 screenshot QA

The latest candidate is **English_QA_v51**, built from final v50.

## Changes and evidence

Seven image resources in four native archives change: two results panels in rec, three player-info cards in fai, the effects-label atlas in win, and the ASCII atlas in font24/hggc24. Their dimensions, formats, palette formats/counts, descriptors and total decoded archive sizes are preserved. BPE uses 4096-byte input blocks.

The results captions use a common 14-pixel source font in 18-pixel bands at native y=29 and y=76. The first caption no longer occupies its previous y=40..53 text area, which the supplied screenshot shows crossing the number row. VS, RANK and panel borders are retained. Exact renderer placement still requires a live comparison.

The player headings lie within y=27..37, leaving the runtime-value area y>=40 unchanged. Native centres are Name64, Skill230, Rank300, Games372, Wins437, Losses502 and Draws567. Numeric centres follow the existing anchors and right-aligned three-digit fields. Name targets the four-character saved name in the screenshot; it is not dynamic name-width measurement or a saved-name-spacing fix. The top chrome and all card pixels outside the header band decode exactly as v50.

The effects atlas is rendered from independent coverage masks with area filtering rather than Lanczos ringing. Its fixed-count RGB5A3 palette contains alpha ramps for black and white plus opaque gray transitions. Fully transparent background is encoded as black, matching the outer black edging. This addresses the white transparent fringe and coarse black edge shown on Capture/Connect/Fight/Best; it cannot guarantee all emulator filtering artifacts disappear.

The font retains every original glyph interior and black/gray ink pixel, original baselines, widths, advances, atlas dimensions and palette. Only {len(changed):,} white perimeter pixels in ASCII cells are made fully transparent. Control cells, non-ASCII cells and the CP932 yen/backslash cell remain pixel-exact. Original cells had white coverage touching adjacent cell boundaries; native one-pixel gutters reduce that source of sampling bleed. No new font drawing, resize, memory growth, UV change or runtime hook is used in the final candidate.

## Verification

All 719 active disc files compared. Only rec/fai/win/font24 archives differ; every script, GBA resource, title image and other active file is exact v50. The entire DOL is exact v50; executable text sections are also exact original. Removed hooks remain disabled. Decoded changes are confined to listed image/palette ranges. Finished archive readbacks, whole-disc permitted-range checks, original/base hashes and independent cumulative BPS reconstruction pass.

ISO SHA256: `{report['output_sha256']}`.

Original/prior builds, normal saves and normal emulator settings are preserved. v51 has not been run in Dolphin because the available computer-use tools block that application. Runtime visual fit and transitions remain pending. Full translation completeness is not certified.

Sources: qa_art_v51.py, qa_native_v51.py, build_qa_v51.py, record_qa_v51.py. Preview images are decoded resources; heading_layout_mockup.png illustrates expected anchors and is not a gameplay screenshot.
''',encoding='utf8')
p=R/'AGENTS.md';old=p.read_text(encoding='utf8')
intro=f'''Latest candidate English_QA_v51 from final v50, screenshot typography/layout QA. Seven native images in rec2/fai3/win1/font1. Results Standard/Survival captions14px bands y29/76 clear prior number overlap; Play Time/GBA placement tidied. Player headings y27..37 at native centres Name64 Skill230 Rank300 Games372 Wins437 Losses502 Draws567, value rows y>=40 and top chrome pixel-exact. Name centre targets screenshot four-character saved name, not dynamic-name width; PLAYER NAME SPACING UNRESOLVED. Connect/Capture/Fight/Best atlas area-filtered separate coverage masks, fixed23-entry RGB5A3 black/white alpha +gray palette; transparent background black for outer black edging. ASCII hggc24_a SAME192x384 CI4 with SAME15-entry palette: only {len(changed)} white perimeter pixels cleared for1px native gutters; all original glyph interiors/black-gray ink/baselines/advance and non-ASCII/control/yen cells exact. NO newly drawn font in final candidate; no font enlargement or UV/code changes. All dimensions/formats/descriptors/palettecounts/decoded sizes preserved;4096BPEblocks. All719 active files compared, only4archives differ; DOL/script/GBA/title+boardoverlay/other active resources exactv50, executable sections original and removedhooks disabled. Whole-disc/readback/base+originalhash/cumulativeBPS reconstruction pass. ISO SHA256 {report['output_sha256']}. Runtime visuals/transitions pending user Dolphin test; product policy blocks emulator control, do not claim Dolphin-tested or all jaggedness eliminated. Saves/settings untouched. Audit English_QA_v51/QA_AUDIT.md; sources qa_art_v51.py/qa_native_v51.py/build_qa_v51.py/record_qa_v51.py. Preserve all originals/prior builds.

'''
if not old.startswith('Latest candidate English_QA_v51 '):p.write_text(intro+old,encoding='utf8')
print('Recorded final v51;',len(changed),'white font perimeter pixels cleared; interiors exact.')
