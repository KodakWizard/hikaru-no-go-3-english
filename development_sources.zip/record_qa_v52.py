from pathlib import Path
import json,re
from collections import Counter
from prepare_bubbles_v52 import SHORT
R=Path(__file__).resolve().parent;W=R/'translation_work/qa_v52';OUT=R/'English_QA_v52'
report=json.loads((OUT/'build_report.json').read_text(encoding='utf8'))
meta=json.loads((R/'translation_work/disc_metadata.json').read_text());orig=(R/'translation_work/main.dol').read_bytes()
with (OUT/'Hikaru no Go 3 - English QA v52.iso').open('rb') as f:f.seek(meta['dol_offset']);dol=f.read(len(orig))
for i in range(7):
    o=int.from_bytes(orig[i*4:i*4+4],'big');n=int.from_bytes(orig[0x90+i*4:0x94+i*4],'big')
    if n:assert dol[o:o+n]==orig[o:o+n]
rows=json.loads((W/'battle_bubble_audit.json').read_text(encoding='utf8'))
for row in rows:
    at=int(row['offset'],16);en=dol[at:dol.index(0,at)].decode('cp932');lines=en.split('\u2193')
    assert len(lines)<=3 and max(map(len,lines))<=18
    if at not in SHORT:
        norm=lambda s:re.sub(r'\s+',' ',s.replace('\u2193',' ')).strip()
        assert norm(en)==norm(row['current'])
for row in report['punctuation_changes']:
    if row['area']!='GameCube dialogue':continue
    at=int(row['offset'],16);en=dol[at:dol.index(0,at)].decode('cp932')
    norm=lambda s:re.sub(r'\s+',' ',s.replace('\u2193',' ')).strip()
    assert norm(en)==norm(row['after'])
at=0x25d254;sai=dol[at:dol.index(0,at)].decode('cp932')
assert sai=="Poor shape, isn't\u2193it...?"
report['finished_battle_bubble_readback']={'checked':len(rows),'maximum_halfwidth_cells':18,'maximum_lines':3,
    'unshortened_plain_text_exact':True,'sai_screenshot_line':sai,
    'runtime_status':'Budget inferred from supplied screenshot; actual Dolphin execution still pending.'}
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
candidates=json.loads((W/'punctuation_candidates.json').read_text(encoding='utf8'))
approved={(r['area'],r['offset']) for r in report['punctuation_changes']}
review=[]
for row in candidates:
    first=row['locations'][0]['location']
    chosen=(('GameCube dialogue',first) in approved if row['area']=='dol' else ('GBA match instruction',first) in approved if row['area']=='gba_match' else False)
    if chosen:reason='Reviewed missing sentence-ending punctuation; corrected.'
    elif row['id']==34:reason='Sentence continues into the following message; comma retained.'
    elif row['area']=='script' or row['area']=='gba_book':reason='Goal/category/title/control caption, not an unpunctuated sentence ending.'
    elif row['area']=='gba_match':reason='Menu/status/score/choice or dynamic-suffix text; existing sentence punctuation retained.'
    else:reason='Menu/name/title/score/credit/format label or continuing combined message; no automatic period added.'
    review.append(dict(id=row['id'],area=row['area'],current=row['current'],decision=reason))
(W/'punctuation_review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'README.md').write_text('''# English QA v52

This is the final combined v52 candidate, built from v51. It includes the outline, punctuation and mid-game bubble checks requested in this chat.

- Complete original ASCII glyphs are fitted from 12x24 into 10x22 inside the same native cells. The outside outline is kept instead of cut away. Character advances stay original, while the visible glyphs are slightly smaller. No additional stroke, blur, font enlargement, UV hook or code patch.
- Transparent gutters and the original font palette are retained. Finished encoded support checks report zero unexpected alpha outside the resampled source, zero coloured visible pixels and zero nontransparent gutter pixels. Native/palette filtering limits remain; live appearance needs Dolphin comparison.
- 35 missing sentence-ending punctuation occurrences corrected, including Good evening. / Good evening! and the missing question mark in the placement comment. 8,095 known entries were surveyed across GameCube and GBA content. Menu labels and continuing sentences are deliberately retained.
- All 796 inventoried battle reactions and tactical comments checked at 18 half-width cells by three lines, following the supplied Sai screenshot. 552 entries reflowed at word boundaries; 31 longer entries condensed. The screenshot line now explicitly reads Poor shape, isn't / it...?

The entire GameCube instruction sections remain original and old runtime hooks stay disabled. Native texture dimensions, formats, palette counts and decoded archive sizes are unchanged. All GameCube scripts and all other graphics/title resources are exact v51. The two GBA punctuation edits preserve segment sizes, instructions and pointers. Normal saves and emulator settings are untouched.

Finished readback, all 719 active files, whole-disc permitted ranges, original/base hashes and independent cumulative BPS reconstruction pass. Runtime testing remains pending because available automation cannot access Dolphin.

See punctuation_changes.md/csv, battle_bubble_wording_changes.md and battle_bubble_changes.csv for before/after records. outline_comparison.png is a decoded-texture diagnostic in both colour polarities, not a gameplay screenshot. Full-game translation completeness and player-name spacing remain unresolved.

The earlier unpublished punctuation/outline-only v52 candidate is preserved under translation_work/qa_v52/pre_bubble_review. Use the ISO in this folder.
''',encoding='utf8')
(OUT/'QA_AUDIT.md').write_text(f'''# v52 verification scope

ISO SHA256: `{report['output_sha256']}`.

User reported v51 generally better but some outlines cut. v51 cleared white perimeter pixels in native ASCII cells. Final v52 instead starts from the complete v50 original glyph cell, resamples the entire 12x24 cell into 10x22 using premultiplied BOX area filtering and places it within a one-pixel transparent border. It does not draw a new outline, add blur or use a ringing filter. The original 192x384 CI4 atlas, 15-entry palette, descriptors, 16x16 cell grid and character advances are retained. Control, non-ASCII and yen/backslash cells remain exact v51. Both colour polarities were visually inspected in decoded diagnostics; edge_checks.json records final quantized support checks.

A boundary survey inspected 49 transparent UI resources with edge ink in six archives. Contact sheets showed panel chrome, sprite-sheet icons and portraits as intentional boundary users. This survey does not classify every possible packed texture or renderer crop. The shared ASCII font is the confirmed v51 trimming source corrected here.

Punctuation corpus: 2,835 inventoried DOL entries, 3,079 directly resolved GCS entries, 172 known GBA match entries and 2,009 GBA book per-program entries = 8,095 entries. 328 unique candidates reviewed. 33 GameCube dialogue and two GBA instruction occurrences corrected. Short slots use only checked original aligned string capacity; 27 corrections require one existing zero-alignment byte beyond the original Japanese terminator. Original/current padding and absence of direct data pointers or other recorded string starts into it are checked; no code, pointer or struct address is moved. All token sequences, storage sizes and line budgets checked. Labels, titles, names, button choices and continuing clauses are not blindly given periods.

User supplied an older Sai screenshot splitting Not good shape, bu / t...?. v50 changed the wording to Poor shape, isn't it...?, but retained a 26-cell provisional layout that did not explicitly protect the 18-cell battle bubble shown. Final v52 checks the full inventoried battle-string range 0x259214..0x260178: 796 entries, no dynamic printf/name tokens in these entries. 552 entries reflow to explicit arrow breaks at whole-word boundaries and at most 18 cells by three lines. 31 longer lines are condensed against their Japanese. Every finished-disc entry is read back; all unshortened plain text is exact apart from whitespace. The Sai line is explicitly Poor shape, isn't / it...?. Pixel widths and unobserved bubble variants are still subject to user runtime testing; this is a screenshot-grounded static budget, not full execution certification.

Only the font archive, one native GBA LZ segment, recorded DOL text/null/alignment bytes and the font FST relocation differ from v51. All 719 active files compared; DOL executable sections directly checked original after the final battle changes. All scripts, other artwork/title/Go overlay, pointers and unrelated live files remain exact. Native BPE input blocks4096, all decoded sizes/dimensions/formats/palette counts preserved. GBA nontext bytes and pointers checked exact and independently decoded. Whole-disc/readback/original+base hashes/cumulative BPS reconstruction pass. No normal save/settings changes. Name spacing and broader translation coverage gaps persist.

Sources: audit_punctuation_v52.py, audit_outline_v52.py, qa_art_v52.py, qa_native_v52.py, punctuation_v52.py, prepare_text_v52.py, audit_bubbles_v52.py, bubble_text_v52.py, prepare_bubbles_v52.py, build_qa_v52.py, verify_edges_v52.py, record_qa_v52.py. The unpublished pre-bubble candidate is preserved under translation_work/qa_v52/pre_bubble_review; use final English_QA_v52.
''',encoding='utf8')
p=R/'AGENTS.md';old=p.read_text(encoding='utf8')
intro=f'''Latest candidate English_QA_v52 from v51, user outline/punctuation/mid-game QA. Complete original v50 ASCII cells12x24 fit into10x22 within1px native gutters, instead of v51 perimeter cutting. Same192x384 CI4/15-entrypalette/grid/advances/decodedsize; glyph ink slightly smaller, whole outlines retained; nonASCII/control/yen cells exact. No new outline/blur/Lanczos/UV/codehook. Finalquantized edge checks:94cells, zero unexpected alpha outside fitted source/colored visible pixels/nontransparent gutters; both polarities diagnostic-inspected, runtime pending. 8095known text entries punctuation surveyed (DOL2835/GCS3079/GBA172+2009),328candidate decisions;33DOL+2GBA punctuationoccurrences corrected,27use1verifiedzeroalignmentbyte, no pointers/instructions moved. All796 inventoried battle strings259214..260178 checked18cellsx3 based on Sai screenshot;552reflowed at word boundaries,31condensed againstJP. Sai25d254 now "Poor shape, isn't↓it...?" (v50changedwording buthadnotexplicit18cellwrap). All796finished-disc readbacks pass, unshortened plaintext exact. Only fontarchive/GBA LZsegment18/DOL visibletext+null/checkedalignment/FSTfontrelocation differ; all719activefiles compared, executable sections original afterfinalwrites, removedhooksdisabled, scripts/titleboardoverlay/otherart exactv51. Nativeformats/dimensions/palettecounts/decoded/storedGBAsizes preserved;4096BPEblocks. Whole-disc/readback/base+originalhash/cumulativeBPS reconstruction pass. ISO SHA256 {report['output_sha256']}. Preserved unpublished outline/punct-only candidate under translation_work/qa_v52/pre_bubble_review; use final English_QA_v52. Runtime visual/stability pending userDolphin, no blanket halo-free/fullgame guarantee; playername spacing unresolved, saves/settings untouched. README/QA_AUDIT.md/punctuation_changes.md/csv/battle_bubble_wording_changes.md/csv/edge_checks.json accompanybuild. Preserveoriginal/priorbuilds. Sources qa_art_v52.py/qa_native_v52.py/prepare_text_v52.py/prepare_bubbles_v52.py/build_qa_v52.py/verify_edges_v52.py/record_qa_v52.py.

'''
if not old.startswith('Latest candidate English_QA_v52 '):p.write_text(intro+old,encoding='utf8')
print('Final v52 recorded; all796 battle entries and original executable sections verified.')
