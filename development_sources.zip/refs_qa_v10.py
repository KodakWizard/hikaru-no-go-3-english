from pathlib import Path
import re
lines=Path('translation_work/disassembly.txt').read_text().splitlines();regs={};hits=[]
for i,line in enumerate(lines):
 parts=line.split(' ',3)
 if len(parts)<4:continue
 addr,off,op,args=parts
 aa=[x.strip() for x in args.split(',')]
 def val(v):
  try:return int(v,0)
  except:return regs.get(v)
 value=None
 if op=='lis':value=(val(aa[1])<<16)&0xffffffff
 elif op=='addi' and val(aa[1]) is not None:value=(val(aa[1])+val(aa[2]))&0xffffffff
 elif op=='mr':value=val(aa[1])
 if value is not None:
  regs[aa[0]]=value
  if 0x8024fa70<=value<=0x8024fc40:hits.append('\n'.join(lines[max(0,i-5):i+12]))
 elif op=='bl':
  for r in range(3,13):regs.pop('r'+str(r),None)
 elif aa and aa[0].startswith('r') and op not in ['stw','stb','sth','cmpw','cmplw','cmpwi','cmplwi','mtctr','mtlr']:regs.pop(aa[0],None)
Path('translation_work/qa_v10/battle_refs.txt').write_text('\n\n'.join(hits))
print('\n\n'.join(hits[:8]))
