﻿from pathlib import Path
import json
for d in ['English_Menu_POC','English_Story_v02','English_Story_v03','English_Menu_v04','English_Menu_v05','English_Interface_v08','English_Menu_v09']:
 r=json.loads((Path(d)/'build_report.json').read_text(encoding='utf8'));print(d,[(k,len(v)) for k,v in r.items() if isinstance(v,list)])
