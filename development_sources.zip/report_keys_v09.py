﻿from pathlib import Path
import json
for d,k in [('English_Menu_POC','text_changes'),('English_Story_v02','dialogue'),('English_Story_v03','edits'),('English_Menu_v04','text'),('English_Menu_v05','text'),('English_Interface_v08','text_checks'),('English_Menu_v09','edits')]:
 r=json.loads((Path(d)/'build_report.json').read_text(encoding='utf8'));print(d,list(r[k][0].keys()),r[k][0].get('offset'))
