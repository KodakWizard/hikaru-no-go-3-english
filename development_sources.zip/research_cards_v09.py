﻿from pathlib import Path
import struct,json,re
b=Path('translation_work/main.dol').read_bytes();m=json.loads(Path('translation_work/disc_metadata.json').read_text())
with Path('English_Title_v081/Hikaru no Go 3 - English Title v081.iso').open('rb') as f:f.seek(m['dol_offset']);new=f.read(len(b))
for at in [0x22da14,0x22da20,0x230b3c]:print(hex(at),repr(b[at:b.index(0,at)].decode('cp932')),repr(new[at:new.index(0,at)].decode('cp932')))
for target in [0x80233b3c,0x80230a14,0x80230a20]:
 needle=target.to_bytes(4,'big');p=0
 while True:
  p=b.find(needle,p)
  if p<0:break
  print('ptr',hex(target),hex(p));p+=1
regs={};hits=[]
for line in Path('translation_work/disassembly.txt').read_text().splitlines():
 fields=line.split(' ',3)
 if len(fields)<4:continue
 addr,off,mn,args=fields
 args=args.split(', ')
 try:
  if mn=='lis':regs[args[0]]=(int(args[1],0)<<16)&0xffffffff
  elif mn=='addi':
   if args[1] in regs:
    regs[args[0]]=(regs[args[1]]+int(args[2],0))&0xffffffff
    if regs[args[0]] in (0x80233b3c,0x80230a14,0x80230a20):hits.append((line,hex(regs[args[0]])))
   else:regs.pop(args[0],None)
  elif mn=='mr':
   if args[1] in regs:regs[args[0]]=regs[args[1]]
   else:regs.pop(args[0],None)
  elif mn=='bl':
   for r in range(3,13):regs.pop('r'+str(r),None)
  elif mn=='blr':regs={}
  elif mn not in ['stw','stb','sth','stfs','stfd','cmpwi','cmplwi','cmpw','cmplw','b','beq','bne','bgt','blt','bge','ble','mtctr','mflr','mtlr','crclr']:regs.pop(args[0],None)
 except (ValueError,IndexError):pass
print(hits)
