from pathlib import Path
regs={};hits=[]
for line in Path('translation_work/disassembly.txt').read_text().splitlines():
 fields=line.split(' ',3)
 if len(fields)<4:continue
 addr,off,mn,args=fields
 args=args.split(', ')
 try:
  if mn=='lis':regs[args[0]]=(int(args[1],0)<<16)&0xffffffff
  elif mn=='addi':
   if args[1] in regs:
    regs[args[0]]=(regs[args[1]]+int(args[2],0))&0xffffffff
    if regs[args[0]] in (0x80253720,0x80253bcc,0x80253bd8):hits.append((line,hex(regs[args[0]])))
   else:regs.pop(args[0],None)
  elif mn=='mr':
   if args[1] in regs:regs[args[0]]=regs[args[1]]
   else:regs.pop(args[0],None)
  elif mn=='bl':
   for r in range(3,13):regs.pop('r'+str(r),None)
  elif mn=='blr':regs={}
  elif mn not in ['stw','stb','sth','stfs','stfd','cmpwi','cmplwi','cmpw','cmplw','b','beq','bne','bgt','blt','bge','ble','mtctr','mflr','mtlr','crclr']:regs.pop(args[0],None)
 except (ValueError,IndexError):pass
print(hits)
