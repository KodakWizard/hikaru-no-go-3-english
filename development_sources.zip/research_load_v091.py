﻿from pathlib import Path
b=Path('translation_work/main.dol').read_bytes()
for term in ['棋力','ランク','時間','%d級','%d段','級','段']:
 needle=term.encode('cp932');start=0;hits=[]
 while True:
  p=b.find(needle,start)
  if p<0:break
  start=p+len(needle)
  if term in ['級','段'] and not (p>0x2d0000 or 0x24a000<p<0x258c00):continue
  a=b.rfind(b'\0',max(0,p-100),p)+1;z=b.find(b'\0',p)
  try:s=b[a:z].decode('cp932')
  except:continue
  if all(c.isprintable() or c=='\n' for c in s):hits.append((hex(p),hex(a),repr(s)))
 print(term,hits)
