﻿from pathlib import Path
from PIL import Image,ImageDraw
from textures import resources,texture
out=Path('translation_work/qa_v10');out.mkdir(exist_ok=True)
for src in ['2D/sbg','font24/hggc24','2D/bbg']:
 b=Path('translation_work/decoded/'+src+'.bin').read_bytes();items=[]
 for n,o in resources(b):
  if not n.endswith('.D4'):continue
  im,desc=texture(b,o);items.append((n,im));im.save(out/(n+'.png'))
  if src.startswith('font'):print(n,desc[:3],'alpha',sorted(set(im.getchannel('A').getdata())),'corner',im.getpixel((0,0)))
 if not src.startswith('font'):
  sh=Image.new('RGB',(1200,100*((len(items)+2)//3)),'#405060');d=ImageDraw.Draw(sh)
  for i,(n,im) in enumerate(items):
   im=im.copy();im.thumbnail((390,76));x=i%3*400;y=i//3*100;d.text((x,y),n,fill='white');sh.paste(im,(x,y+20),im)
  sh.save(out/(src.split('/')[-1]+'.png'))
b=Path('translation_work/main.dol').read_bytes()
terms=['【講座','囲碁とは','講座を選択','ああ、なつかしい','しばらくお待ち','基本ルール']
for t in terms:
 s=0;needle=t.encode('cp932')
 while True:
  at=b.find(needle,s)
  if at<0:break
  s=at+len(needle);a=b.rfind(b'\0',max(0,at-60),at)+1;z=b.find(b'\0',at)
  print(t,hex(at),hex(a),repr(b[a:z].decode('cp932','replace')))
