from pathlib import Path
import json,struct
from collections import Counter
from PIL import Image,ImageDraw
from qa_research_v10 import current_files
from decode_bpe import decode
from textures import resources,texture
from smooth_art import palette
R=Path(__file__).parent;W=R/'translation_work/qa_v51';W.mkdir(exist_ok=True)
f,_,files=current_files(R/'English_Dialogue_v50/Hikaru no Go 3 - English Dialogue v50.iso')
for path,names in [('2D/fai.bpe',['fai20.D4','fai22.D4','fai28.D4']),('2D/rec.bpe',['rec02_0.D4','rec02_1.D4']),('2D/win.bpe',['win30_0.D4']),('font24/hggc24.bpe',['hggc24_a.D4'])]:
 off,size,_=files[path];f.seek(off);b=decode(f.read(size));lookup=dict(resources(b))
 (W/(path.replace('/','_')+'.bin')).write_bytes(b)
 for name in names:
  im,desc=texture(b,lookup[name]);print(path,name,desc,Counter(im.getdata()).most_common(8));im.save(W/name.replace('.D4','.png'))
  if desc[0] in (8,9):print('PAL',palette(b,lookup[name],desc[0]))
  if 'hggc' in name:
   im.crop((0,96,192,168)).resize((1152,432)).save(W/'font_cells.png')
   border=Counter()
   for code in range(32,127):
    x,y=code%16*12,code//16*24
    for xx in range(12):
     for yy in range(24):
      if xx in (0,11) or yy in (0,23):border[im.getpixel((x+xx,y+yy))]+=1
   print('ASCII BORDER',border)
  else:im.resize((im.width*2,im.height*2)).save(W/(name+'.2x.png'))
f.close()
