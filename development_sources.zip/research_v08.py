﻿from pathlib import Path
from PIL import Image,ImageDraw
from textures import resources,texture
out=Path('translation_work/ui_v08');out.mkdir(exist_ok=True)
for src in ['2D/map','2D/bbg','2D/mba_battle','title/title']:
 p=Path('translation_work/decoded/'+src+'.bin')
 if not p.exists(): print('MISSING',src);continue
 b=p.read_bytes(); items=[]
 for n,o in resources(b):
  if not n.endswith('.D4'):continue
  try: im,d=texture(b,o)
  except Exception as e: print(n,e);continue
  im.save(out/(src.replace('/','_')+'_'+n+'.png'));items.append((n,im))
 print(src,[(n,im.size) for n,im in items])
 for start in range(0,len(items),60):
  rows=items[start:start+60];sheet=Image.new('RGB',(1200,100*((len(rows)+2)//3)),'#405060');dr=ImageDraw.Draw(sheet)
  for i,(n,im) in enumerate(rows):
   im=im.copy();im.thumbnail((390,72));x=i%3*400;y=i//3*100;dr.text((x,y),n,fill='white');sheet.paste(im,(x,y+20),im)
  sheet.save(out/(src.replace('/','_')+str(start)+'.png'))
b=Path('translation_work/main.dol').read_bytes()
for s in ['さん','自宅','お願いします。']:
 needle=s.encode('cp932');i=0
 while True:
  i=b.find(needle,i)
  if i<0:break
  print(s,hex(i),repr(b[max(0,i-20):i+60].decode('cp932','replace')));i+=len(needle)
