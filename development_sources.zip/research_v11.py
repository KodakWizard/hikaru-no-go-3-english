from pathlib import Path
import json,re,struct
from gcs_text import text_tail
from textures import resources,texture
from decode_bpe import decode
from PIL import Image,ImageDraw
ROOT=Path(__file__).parent;W=ROOT/'translation_work';O=W/'qa_v11';O.mkdir(exist_ok=True)
b=(W/'main.dol').read_bytes()
terms=['アタリ','ゲタ','問題を選択','囲碁問題集一巻','ブリスターパック','手完','中押し勝ち','を手に入れた','第%','第１問']
for t in terms:
 n=t.encode('cp932');start=0
 while True:
  at=b.find(n,start)
  if at<0:break
  start=at+len(n);lo=b.rfind(b'\0',max(0,at-100),at)+1
  if lo==0:lo=at
  hi=b.find(b'\0',at);print(hex(at),hex(lo),repr(b[lo:hi].decode('cp932','replace')))
for name in ['tutorial/tuto2_01','drill/dri_001']:
 data=(W/'extracted/script'/(name+'.gcs')).read_bytes();base,start,rows=text_tail(data)
 print(name)
 for i,r in enumerate(rows):print(i,[hex(int.from_bytes(data[p-4:p],'big')) for p in r['references']],r['japanese'].replace('\n',' / '))
for src in ['2D/moe1','2D/moe2','2D/bbg','2D/fai']:
 data=decode((W/'extracted'/(src+'.bpe')).read_bytes());items=[]
 for name,at in resources(data):
  if name.endswith('.D4'):
   im,desc=texture(data,at)
   if src.endswith('bbg') and not name.startswith('bbg11'):continue
   if src.endswith('fai') and not name.startswith(('fai10','fai11')):continue
   im.thumbnail((240,180));items.append((name,im));print(src,name,desc[:3])
 sh=Image.new('RGB',(1000,205*((len(items)+3)//4)),'#405060');d=ImageDraw.Draw(sh)
 for i,(name,im) in enumerate(items):x=i%4*250;y=i//4*205;d.text((x,y),name,fill='white');sh.paste(im,(x,y+20),im)
 sh.save(O/(src.split('/')[-1]+'.png'))
