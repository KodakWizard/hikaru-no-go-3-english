from pathlib import Path
import json,struct,re
from qa_research_v10 import current_files
from textures import resources,texture
from PIL import Image,ImageDraw
from decode_bpe import decode
R=Path(__file__).parent;W=R/'translation_work';O=W/'qa_v12';O.mkdir(exist_ok=True)
if __name__=='__main__':
 b=(W/'main.dol').read_bytes()
 for lo,hi in [(0x2d9000,0x2d9090),(0x2d96d0,0x2d9740),(0x24cc90,0x24cd50)]:
  for at in range(lo,hi,4):
   if b[at-1] not in (0,0xcd):continue
   end=b.find(b'\0',at)
   try:s=b[at:end].decode('cp932')
   except:continue
   if s:print(hex(at),repr(s))
 f,fst,files=current_files(R/'English_Content_v11/Hikaru no Go 3 - English Content v11.iso')
 for src in ['2D/agbctrdl','2D/fai','2D/mjw','2D/sai','2D/roo','2D/end','2D/rec','2D/scs']:
  off,size,_=files[src+'.bpe'];f.seek(off);b=decode(f.read(size));items=[]
  for n,at in resources(b):
   if not n.endswith('.D4'):continue
   im,desc=texture(b,at)
   if desc[0]==6:continue
   if im.width<24 or im.height<14:continue
   im.thumbnail((290,115));items.append((n,im))
  for pg in range((len(items)+47)//48):
   batch=items[pg*48:(pg+1)*48];sh=Image.new('RGB',(1200,140*((len(batch)+3)//4)),'#405060');d=ImageDraw.Draw(sh)
   for i,(n,im) in enumerate(batch):x=i%4*300;y=i//4*140;d.text((x,y),n,fill='white');sh.paste(im,(x,y+20),im)
   sh.save(O/(src.split('/')[-1]+f'_{pg}.png'))
  print(src,'non-RGBA candidate images',len(items))
