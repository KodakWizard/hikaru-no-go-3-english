from pathlib import Path
from gcs_text import text_tail
import json,struct
from qa_research_v10 import current_files
from decode_bpe import decode
from textures import resources,texture
from PIL import Image,ImageDraw
W=Path('translation_work');O=W/'qa_v13';O.mkdir(exist_ok=True)
b=(W/'main.dol').read_bytes()
for term in ['中押し','負け','手完','検討中','石を打つ','一手戻る','終了']:
 n=term.encode('cp932');p=0
 while (p:=b.find(n,p))>=0:
  lo=b.rfind(b'\0',max(0,p-80),p)+1;e=b.find(b'\0',p)
  if lo:print(hex(lo),repr(b[lo:e].decode('cp932','replace')))
  p+=len(n)
f,fst,files=current_files(Path('English_Polish_v12/Hikaru no Go 3 - English Polish v12.iso'))
for src in ['2D/moe1.bpe','2D/moe2.bpe','2D/bbg.bpe','2D/agbctrdl.bpe','font24/hggc24.bpe']:
 o,s,_=files[src];f.seek(o);b=decode(f.read(s));items=[]
 for n,at in resources(b):
  if not n.endswith('.D4'):continue
  im,desc=texture(b,at)
  if src.endswith('bbg.bpe') and n.startswith(('bbg11','bbg00','bbg01')):continue
  if src.endswith('agbctrdl.bpe') and not n.startswith('cau'):continue
  if src.startswith('font') and n!='hggc24_a.D4':continue
  im.save(O/(src.split('/')[-1]+'.'+n+'.png'));im.thumbnail((240,150));items.append((n,im))
 for pg in range((len(items)+39)//40):
  batch=items[pg*40:(pg+1)*40];sh=Image.new('RGB',(1000,175*((len(batch)+3)//4)),'#405060');d=ImageDraw.Draw(sh)
  for i,(n,im) in enumerate(batch):x=i%4*250;y=i//4*175;d.text((x,y),n,fill='white');sh.paste(im,(x,y+20),im)
  sh.save(O/(src.split('/')[-1]+f'_{pg}.png'))
print('Contacts saved')
