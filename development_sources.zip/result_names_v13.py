"""Normalize only a temporary copy at the verified battle label setters."""
import struct
from name_display_v08 import branch
def patch(dol,original,freed_ranges,blocked):
 entry=0x80230a80
 nodes=[0x9421ffa0,0x7c0802a6,0x90010064,0x90610008,0x38610010,('call',entry),0x80610008,0x38810010,('call',0x800a25c0),0x80010064,0x7c0803a6,0x38210060,0x4e800020]
 addresses=[];words={};available=[]
 for lo,hi in freed_ranges:
  available.extend(at for at in range((lo+3)&~3,hi-7,8) if dol[at:at+8]==bytes(8) and not any(at<p+4 and p<at+8 for p in blocked))
 assert len(available)>=len(nodes),'Not enough verified reclaimed string tails'
 for at in available:
  if at+0x80003000 not in addresses:
   assert dol[at:at+8]==bytes(8)
   assert (at+0x80003000).to_bytes(4,'big') not in original[0x22d420:]
   addresses.append(at+0x80003000)
   if len(addresses)==len(nodes):break
 for i,(addr,node) in enumerate(zip(addresses,nodes)):
  words[addr]=branch(addr,node[1],True) if isinstance(node,tuple) else node
  if i+1<len(nodes):words[addr+4]=branch(addr+4,addresses[i+1])
 for addr,word in words.items():struct.pack_into('>I',dol,addr-0x80003000,word)
 hooks=[0x8012d75c,0x8012d774,0x8012d790,0x8012d7a8,0x8012d7d0,0x8012d7dc,0x8012d7ec,0x8012d7f8]
 for addr in hooks:
  at=addr-0x80018ba0+0x2620;assert int.from_bytes(dol[at:at+4],'big')==branch(addr,0x800a25c0,True);struct.pack_into('>I',dol,at,branch(addr,addresses[0],True))
 # Execute the actual wrapper words, stubbing the two previously verified
 # external functions. Check stack/LR restoration, input preservation and ABI.
 tests=['Ｄｏｋｉ','Doki','ＡＢＣｘｙｚ０１９','あかり','ＡあＢ','ｶﾀｶﾅＡ','藤崎あかり','']
 for text in tests:
  raw=text.encode('cp932')+b'\0';mem={0x100000+i:x for i,x in enumerate(raw)};regs=[0]*32;regs[1]=0x300000;regs[3]=0x400000;regs[4]=0x100000;lr=0x900000;pc=addresses[0];seen=[]
  def word(at):return sum(mem.get(at+i,0)<<(24-i*8) for i in range(4))
  def put(at,v):
   for i in range(4):mem[at+i]=(v>>(24-i*8))&255
  def string(at):
   out=bytearray()
   while mem.get(at,0):out.append(mem[at]);at+=1
   return bytes(out)
  for step in range(200):
   if pc in (entry,0x800a25c0):
    if pc==entry:
     src=string(regs[4]).decode('cp932');narrow=''.join(chr(ord(c)-0xfee0) if '０'<=c<='９' or 'Ａ'<=c<='Ｚ' or 'ａ'<=c<='ｚ' else c for c in src).encode('cp932')+b'\0'
     for i,v in enumerate(narrow):mem[regs[3]+i]=v
     for r in range(4,8):regs[r]=0xbad
    else:
     assert regs[3]==0x400000;seen.append(string(regs[4]));regs[3]=0x12345678
    pc=lr;continue
   if pc==0x900000:break
   w=words[pc];nxt=pc+4;op=w>>26;rt=w>>21&31;ra=w>>16&31;imm=w&65535;imm=imm-65536 if imm&32768 else imm
   if w==0x7c0802a6:regs[0]=lr
   elif w==0x7c0803a6:lr=regs[0]
   elif w==0x4e800020:nxt=lr
   elif op==37:a=regs[ra]+imm;put(a,regs[rt]);regs[ra]=a
   elif op==36:put(regs[ra]+imm,regs[rt])
   elif op==32:regs[rt]=word(regs[ra]+imm)
   elif op==14:regs[rt]=regs[ra]+imm
   elif op==18:
    delta=w&0x3fffffc;delta=delta-(1<<26) if delta&(1<<25) else delta
    if w&1:lr=pc+4
    nxt=pc+delta
   else:raise AssertionError(hex(w))
   pc=nxt
  else:raise AssertionError('Wrapper did not return')
  expect=''.join(chr(ord(c)-0xfee0) if '０'<=c<='９' or 'Ａ'<=c<='Ｚ' or 'ａ'<=c<='ｚ' else c for c in text).encode('cp932')
  assert seen==[expect] and regs[1]==0x300000 and lr==0x900000 and regs[3]==0x12345678 and string(0x100000)==raw[:-1]
 return dict(entry=hex(addresses[0]),hooks=[hex(a) for a in hooks],reclaimed_words=[hex(a-0x80003000) for a in words],wrapper_ppc_tests=len(tests),saved_name_bytes_unchanged=True,scope='Battle name label setters; Dolphin test required')
