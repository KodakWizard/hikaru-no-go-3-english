from pathlib import Path
import json
from dialogue_polish_v50 import REVISIONS,SCRIPT_REVISIONS
r=Path('translation_work/dialogue_v50')
rows=json.loads((r/'dol_unique.json').read_text(encoding='utf8'))
out=[]
for i,s in sorted(REVISIONS.items()):
 out.append(f"{i} {rows[i]['japanese']} | {rows[i]['english']} -> {s}")
for at in range(0,len(out),150):
 (r/f'revisions_{at}.txt').write_text('\n'.join(out[at:at+150]),encoding='utf8')
