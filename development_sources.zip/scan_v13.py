from pathlib import Path
from decode_bpe import decode
terms=['中押','手完','手','勝ち','負け','検討中']
for f in Path('translation_work/extracted').rglob('*'):
 if not f.is_file() or f.suffix not in ('.gcs','.bin','.bpe'):continue
 b=f.read_bytes()
 if f.suffix=='.bpe':
  try:b=decode(b)
  except:continue
 for t in terms:
  n=t.encode('cp932');p=0;hits=[]
  while (p:=b.find(n,p))>=0:
   lo=b.rfind(b'\0',max(0,p-50),p)+1;e=b.find(b'\0',p)
   if lo and 0<=e-lo<180:
    try:s=b[lo:e].decode('cp932')
    except:s=''
    if s:hits.append((hex(lo),s))
   p+=len(n)
  if hits and (t in ['中押','手完','検討中'] or not str(f).endswith('.gcs')):print(str(f),t,hits[:20])
