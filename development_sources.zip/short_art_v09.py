﻿from pathlib import Path
p=Path('menu_translation_v09.py');s=p.read_text(encoding='utf8').replace("'brs02_0.D4':'Rotate'","'brs02_0.D4':'Spin'");p.write_text(s,encoding='utf8')
