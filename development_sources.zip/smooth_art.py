"""Supersampled text and alpha-aware quantisation for the game's GX palettes."""
import struct,math
from PIL import Image,ImageDraw,ImageFont
from textures import texture

def render_label(im,text,max_size=22,margin=3,italic=False,title=False,text_colour=None,outline_width=None):
 w,h=im.size;scale=6;lines=text.split('\n');stroke=1 if w>32 else 0
 if outline_width is not None:stroke=outline_width
 fontpath='C:/Windows/Fonts/arialbi.ttf' if italic else 'C:/Windows/Fonts/arialbd.ttf'
 for size in range(max_size,9,-1):
  font=ImageFont.truetype(fontpath,size*scale)
  boxes=[font.getbbox(l,stroke_width=stroke*scale) for l in lines]
  widths=[b[2]-b[0] for b in boxes];heights=[b[3]-b[1] for b in boxes]
  total=sum(heights)+2*scale*(len(lines)-1)
  if max(widths)<=scale*(w-2*margin) and total<=scale*(h-2*margin):break
 else:raise ValueError(('label will not fit',text,w,h))
 bg=(0,0,0,0) if title else im.getpixel((0,0))
 canvas=Image.new('RGBA',(w*scale,h*scale),bg);dr=ImageDraw.Draw(canvas);y=(h*scale-total)//2
 fill=(255,170,0,255) if title else (255,255,255,255)
 if text_colour is not None:fill=text_colour
 if title and 'GREY' in text:raise ValueError('Pass grey via recolour, not text')
 for line,box,tw,th in zip(lines,boxes,widths,heights):
  dr.text(((w*scale-tw)//2-box[0],y-box[1]),line,font=font,fill=fill,stroke_width=stroke*scale,stroke_fill='black');y+=th+2*scale
 return canvas.resize((w,h),Image.Resampling.LANCZOS),dict(font_size=size,ink_width=math.ceil(max(widths)/scale),ink_height=math.ceil(total/scale),width=w,height=h,margin=margin)

def palette(b,o,fmt):
 pf,n=struct.unpack_from('>HH',b,o+44);pal=[]
 for j in range(n if fmt==9 else min(n,16)):
  v=int.from_bytes(b[o+64+j*2:o+66+j*2],'big')
  if pf==0:c=(v&255,v&255,v&255,v>>8)
  elif pf==1:c=(((v>>11)&31)*255//31,((v>>5)&63)*255//63,(v&31)*255//31,255)
  else:c=(((v>>10)&31)*255//31,((v>>5)&31)*255//31,(v&31)*255//31,255) if v&32768 else (((v>>8)&15)*17,((v>>4)&15)*17,(v&15)*17,((v>>12)&7)*255//7)
  pal.append(c)
 return pal

def write_texture(b,o,im):
 _,(fmt,w,h,start)=texture(b,o);assert fmt in (8,9) and im.size==(w,h)
 pal=palette(b,o,fmt)
 def premul(c):return (c[0]*c[3]/255,c[1]*c[3]/255,c[2]*c[3]/255,c[3])
 vectors=[premul(c) for c in pal];cache={}
 def nearest(c):
  if c not in cache:
   v=premul(c);cache[c]=min(range(len(pal)),key=lambda j:sum((v[k]-vectors[j][k])**2*(2 if k==3 else 1) for k in range(4)))
  return cache[c]
 pix=list(im.getdata());bw,bh=(8,8) if fmt==8 else (8,4);packed=bytearray()
 for y in range(0,h,bh):
  for x in range(0,w,bw):
   vals=[nearest(pix[(y+yy)*w+x+xx]) if y+yy<h and x+xx<w else 0 for yy in range(bh) for xx in range(bw)]
   packed.extend(((vals[i]<<4)|vals[i+1] for i in range(0,len(vals),2)) if fmt==8 else vals)
 b[start:start+len(packed)]=packed
 return texture(b,o)[0]

def title_palette(b,o,grey=False):
 # 16 CI4 entries: eight coverage levels each for lettering and black edging.
 assert int.from_bytes(b[o+40:o+44],'big')==0x40
 rgb=(10,10,10) if grey else (15,10,0)
 vals=[(a<<12)|(rgb[0]<<8)|(rgb[1]<<4)|rgb[2] for a in range(8)]+[(a<<12) for a in range(8)]
 struct.pack_into('>HH',b,o+44,2,16)
 for j,v in enumerate(vals):struct.pack_into('>H',b,o+64+j*2,v)
