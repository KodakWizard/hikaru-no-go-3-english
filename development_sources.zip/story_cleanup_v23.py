"""Short lines missed by duplicate matching in earlier Story passes."""
TEXT = {
0x261400: 'Game end',
0x261604: 'Miss',
0x263ff4: 'Huh?↓Shogi?',
0x269118: '.......',
0x2695bc: 'I see.',
0x269fb0: '.........',
0x26a384: 'Huh?↓Shogi?',
0x26ac08: 'Later.',
0x26ae2c: 'Hi, $1.',
}
