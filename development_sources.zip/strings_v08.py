﻿from pathlib import Path
b=Path('translation_work/main.dol').read_bytes()
out=[]
for lo,hi in [(0x251000,0x251c00),(0x259400,0x259a00),(0x2d9e00,0x2da700)]:
 i=lo
 while i<hi:
  j=b.find(b'\0',i)
  try:s=b[i:j].decode('cp932')
  except:s=''
  if s and all(c.isprintable() for c in s):out.append(f'{i:x} {s}')
  i=j+1
Path('translation_work/ui_v08/strings.txt').write_text('\n'.join(out),encoding='utf8')
