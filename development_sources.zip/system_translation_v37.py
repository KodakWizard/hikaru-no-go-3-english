"""Residual player-facing system text. No debug/encoding-table edits."""
TEXT = {
 0x230854:'Hikaru Go 3 System Data',
 0x230884:'Hikaru Go 3 Story Data',
 0x2308c0:'Hikaru Go 3 Pair Go Record',
 0x2308e0:'Hikaru Go 3 Game Record',
 0x230908:'Hikaru Go 3 Pair Go Resume',
 0x230928:'Hikaru Go 3 Resume Data',
 0x231788:'Download complete.\nYou may now switch off\nthe Game Boy Advance.',
}
for i in range(4):
 TEXT[0x231448+i*0x40]=f'Port {i+1}: connection error.\nPlease check the cable.'
 TEXT[0x231548+i*0x88]=f'Port {i+1}: GBA link failed.\nSet GBA to Download Mode,\nthen reconnect it.'
