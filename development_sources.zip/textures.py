from pathlib import Path
import struct,json
from PIL import Image,ImageDraw

def resources(b):
 d=int.from_bytes(b[4:8],'big')+32;n=int.from_bytes(b[12:16],'big');ns=d+n*8
 for i in range(n):
  o,no=struct.unpack_from('>II',b,d+i*8)
  name=b[ns+no:].split(b'\0')[0].decode('ascii')
  yield name,o+32

def texture(b,o):
 fmt,w,h,unk,ptr=struct.unpack_from('>HHHHI',b,o+32)
 start=o+32+ptr
 im=Image.new('RGBA',(w,h));p=im.load();k=start
 palette=[]
 if fmt in (8,9):
  pf,n=struct.unpack_from('>HH',b,o+44)
  for j in range(n):
   v=int.from_bytes(b[o+64+j*2:o+66+j*2],'big')
   if pf==0:c=(v&255,v&255,v&255,v>>8)
   elif pf==1:c=(((v>>11)&31)*255//31,((v>>5)&63)*255//63,(v&31)*255//31,255)
   else:c=(((v>>10)&31)*255//31,((v>>5)&31)*255//31,(v&31)*255//31,255) if v&32768 else (((v>>8)&15)*17,((v>>4)&15)*17,(v&15)*17,((v>>12)&7)*255//7)
   palette.append(c)
 if fmt in (0,8):k*=2
 # Observed format IDs use GX texture formats.
 bw,bh={0:(8,8),1:(8,4),2:(8,4),3:(4,4),4:(4,4),5:(4,4),6:(4,4),8:(8,8),9:(8,4)}.get(fmt,(0,0))
 if not bw:raise ValueError(fmt)
 for y in range(0,h,bh):
  for x in range(0,w,bw):
   for yy in range(bh):
    for xx in range(bw):
     if fmt in (0,8):
      v=(b[k//2]>>(4 if k%2==0 else 0))&15;k+=1;c=(255,255,255,v*17)
      if fmt==8:c=palette[v]
     elif fmt==9:
      v=b[k];k+=1;c=palette[v]
     elif fmt==1:
      v=b[k];k+=1;c=(255,255,255,v)
     elif fmt==3:
      a,v=b[k:k+2];k+=2;c=(v,v,v,a)
     elif fmt==5:
      v=int.from_bytes(b[k:k+2],'big');k+=2
      c=(((v>>10)&31)*255//31,((v>>5)&31)*255//31,(v&31)*255//31,255) if v&32768 else (((v>>8)&15)*17,((v>>4)&15)*17,(v&15)*17,((v>>12)&7)*255//7)
     elif fmt==6:
      base=k+((yy*4+xx)*2);a,v=b[base:base+2];g,bl=b[base+32:base+34];c=(v,g,bl,a)
     else:raise ValueError(fmt)
     if x+xx<w and y+yy<h:p[x+xx,y+yy]=c
   if fmt==6:k+=64
 return im,(fmt,w,h,start)

if __name__=='__main__':
 out=Path('translation_work/textures');out.mkdir(exist_ok=True);meta=[]
 for src in ['title/title','2D/sbg','2D/mba','2D/roo','2D/win','font24/hggc24']:
  b=Path('translation_work/decoded/'+src+'.bin').read_bytes()
  for name,o in resources(b):
   if not name.endswith('.D4'):continue
   try:
    im,desc=texture(b,o);im.save(out/(name+'.png'));meta.append(dict(archive=src,name=name,offset=o,format=desc))
   except Exception as e: print(src,name,hex(o),b[o+32:o+48].hex(),e)
 (out/'metadata.json').write_text(json.dumps(meta,indent=2))
 thumbs=[]
 for m in meta:
  if m['archive'].startswith('font'):continue
  im=Image.open(out/(m['name']+'.png'));im.thumbnail((300,140));tile=Image.new('RGB',(320,175),'#40505a');tile.paste(im,((320-im.width)//2,25),im);ImageDraw.Draw(tile).text((4,4),m['name'],fill='white');thumbs.append(tile)
 sheet=Image.new('RGB',(320*4,175*((len(thumbs)+3)//4)),'#202020')
 for i,t in enumerate(thumbs):sheet.paste(t,((i%4)*320,(i//4)*175))
 sheet.save(out/'contact_sheet.png')
