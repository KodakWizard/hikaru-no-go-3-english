"""English title plate rendered as smooth text and Go-stone vector shapes."""
from PIL import Image,ImageDraw,ImageFont

def english_title(original):
 scale=4;im=original.resize((2560,1920),Image.Resampling.LANCZOS);d=ImageDraw.Draw(im)
 def box(v):return tuple(int(x*scale) for x in v)
 # A deliberate opaque title plate covers the complete Japanese logo while
 # preserving Sai's face and the surrounding original illustration.
 d.rounded_rectangle(box((14,53,386,224)),radius=17*scale,fill=(17,16,31,255),outline=(244,192,65,255),width=2*scale)
 d.rounded_rectangle(box((20,59,380,218)),radius=13*scale,outline=(101,80,51,255),width=scale)
 for x in range(31,375,22):d.line(box((x,69,x,207)),fill=(43,40,53,255),width=scale)
 for y in range(75,215,22):d.line(box((28,y,371,y)),fill=(43,40,53,255),width=scale)
 def lettering(text,xy,size,fill,stroke=1):
  font=ImageFont.truetype('C:/Windows/Fonts/arialbi.ttf',size*scale)
  d.text(box(xy),text,font=font,fill=fill,stroke_width=stroke*scale,stroke_fill=(4,4,10,255))
 lettering('HIKARU', (29,67),52,(255,204,54,255),2)
 lettering('NO GO', (32,125),51,(250,246,227,255),2)
 lettering('3',(302,77),108,(255,183,25,255),2)
 # A black and white pair forms the visual punctuation of the Go title.
 for x,white in [(255,False),(282,True)]:
  d.ellipse(box((x,191,x+19,210)),fill=(230,230,224,255) if white else (8,8,13,255),outline=(170,170,165,255),width=scale)
  d.ellipse(box((x+4,194,x+10,198)),fill=(255,255,255,255) if white else (65,65,76,255))
 # Translate the first legal-credit line, retaining every credited party.
 d.rectangle(box((0,383,639,414)),fill='white')
 credits='© Yumi Hotta · HMC · Takeshi Obata · Noel / Shueisha · TV Tokyo · Dentsu · Studio Pierrot'
 font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',12*scale)
 while d.textbbox((0,0),credits,font=font)[2]>608*scale:
  font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',font.size-1)
 bb=d.textbbox((0,0),credits,font=font);w=bb[2]-bb[0]
 d.text(((640*scale-w)//2,394*scale-bb[1]),credits,font=font,fill='black')
 return im.resize(original.size,Image.Resampling.LANCZOS)
