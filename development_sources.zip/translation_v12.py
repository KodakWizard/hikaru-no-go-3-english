"""Prediction panel, short problem categories and one-line GCS headings."""
TEXT={0x2d9044:'B %4d',0x2d904c:'W %4d',0x2d9054:'%3d%spt',0x2d905c:'0.5pt',0x2d9064:'B ahead',0x2d906c:'W ahead',0x2d8d94:'.5',0x24ccd8:'Komi 0.5',0x24cce4:'Rev. 0.5',0x24ccf0:'Komi %2d%s',0x24cd00:'Rev. %2d%s',0x24cd10:'Even game',0x2d96e0:'Capture',0x2d96e8:'Join',0x2d96f0:'Cut',0x2d96f8:'L&D',0x2d9700:'Escape',0x2d9708:'Tsumego',0x2d9710:'Tesuji',0x2d9718:'Middle',0x2d9720:'Links'}
PAD_SLOTS={0x2d96e0:0x2d96e8,0x2d9700:0x2d9708,0x2d9708:0x2d9710,0x2d9710:0x2d9718}
HEADINGS={}
for k in range(1,51):
 if k==1:s='Capture every White stone.'
 elif k in (2,4):s=f'Protect all with {4 if k==2 else 3} Black stones.'
 elif k==3:s='Take most Whites with 4 Black stones.'
 elif k in (5,6):s='Connect all Black stones.'
 elif k in (7,8,30,31):s='Exploit weak points to cut White.'
 elif k in (9,10) or 32<=k<=40:s='Destroy eyes so White cannot live.'
 elif k in (11,12):s='Make Black live.'
 elif k in (13,14,17,18,19):s='Capture White △.'
 elif k in (15,16,20,21,22,23,44):s='Exploit weak points to take White.'
 elif 24<=k<=29:s='Protect and connect Black.'
 elif k==41:s='Take White: too few liberties.'
 elif k==42:s='Break through to rescue Black.'
 elif k==43:s='Take White to save two Black stones.'
 elif k==45:s='Take White to rescue Black.'
 elif k==46:s="Capture White's key stones."
 elif k==47:s='Take 3 Whites to settle Black.'
 elif k==48:s='Exploit the White weaknesses.'
 elif k==49:s='Break White territory at weak points.'
 elif k==50:s='Chase and capture 3 White stones.'
 else:raise AssertionError(k)
 HEADINGS[k]=f'1-{k:02d}: '+s
