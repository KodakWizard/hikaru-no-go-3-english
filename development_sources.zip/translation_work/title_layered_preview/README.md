﻿# Layered title visual proposal — 2026-10-19

The first two images are visual proposals. Following user approval, a separate local v57 test ISO was built. Public Version 1 and GitHub remain unchanged.
Built-in image_gen used, two editing stages.

Stage 1 prompt: Restore original_tit00.D4.png by removing only the baked Japanese logo and shadow, continuing purple scenery/hair behind it. Preserve Sai, fan, colors, white margins and copyright region. Keep the illustration top and bottom edges straight at native y52 and y379. No new logo, controls, or board grid.
Stage 2 prompt: Composite the existing transparent English project-logo.png over the clean background; use the user screenshot for placement and copyright text. Add clipped thin board grid behind logo, black Story stone and single-line Free Match. Preserve background continuity and straight white margins; no seams or extra halo.

Inputs: translation_work/qa_v47/original_tit00.D4.png; GitHub_Release_v1/project-logo.png; user Dolphin_itgp8KYE9p.png screenshot.
Outputs: sai-background-draft.png; title-menu-proposal.png.

The generated composite altered the logo proportions/details; it was NOT substituted into the game. A third generated master was also kept only as a reference, not used by the build.

## Approved direction implemented in local test v57

`title_layers_v57.py` deterministically resamples the clean, generated background-only restoration into the native illustration rectangle (640 by 327), places the existing transparent project logo with its preserved aspect ratio, and derives two native 640 by 480 textures. The upper margin is uniform opaque white; released English copyright pixels are copied exactly. A thin board grid is drawn before the alpha logo for the menu state. Existing menu sprites, prompts and animation data remain byte-exact v56. Native RGBA8 encoding round-trips pixel-exactly; all resource descriptors, dimensions and decoded archive size are preserved.

The generated clean background covers the entire illustration rectangle, so it is not a pixel-exact restoration of the original Sai art. This follows the user's approval of the visual proposal. Neither the generated menu text nor generated logo variants are used. The composited result uses the original transparent English logo, resized once with Lanczos filtering. No extra halo is added.

Build: `build_title_layers_v57.py`. Output: `English_TitleLayers_Test_v57/`. All 719 active files were checked; only title/title.bpe changes. Whole-disc comparison allows only the relocated title archive and its eight-byte FST location/size entry. Cumulative BPS reconstruction and original/v56 hash checks pass. No runtime QA performed; cold-boot title transitions and both menu selections need Dolphin testing. No GitHub update or public version change has been made.
