"""Remaining Course 2/3 strings; indices match verified original pools."""
LESSONS={}
def add(name,text):LESSONS[name]=text.strip().splitlines()
add('tuto3_04','''
3-4: Territory
3-4: Territory ⑪ Play
Let us study how to build territory.
During fuseki, decide where to build your territory.
Decide which parts of the board to develop.
Focusing on just one area leaves you behind overall.
We discussed that before.
For example...
So far, Black and White are even.
But Black 7 and 9 focus only on the upper-right corner.
White 6 and 8 spread out quickly.
By Black 15, the upper-right corner is secure...
But after White 16, Black cannot win.
White's territory is far too big!
Continuing to White 22 widens the gap even more.
Build a framework first, or fall behind overall.
From Black 1 at komoku, Black 2 encloses the corner.
This is a shimari, remember?
These two moves secure most of the corner.
Black can leave it and play elsewhere.
Defend the upper-right corner when White approaches.
If the first move is hoshi...
Black 1, 2 and 3 make an enclosure.
If White tries to enter the enclosure...
Black 2 and 4 defend and keep White out.
If White invades directly...
Black 2 and 4 trap White in the corner.
Stones trapped inside an enclosure...
Find it hard to live.
A shimari usually secures the corner well enough.
Before defending further, compare overall territory.
Do not fall behind in total territory.
Next, territory along the sides.
The basic side shape uses Black 1 and 2.
This is niken-biraki, a two-space extension.
It secures most of this top-side area.
If White forces its way between them...
Black answers at 2.
If White plays 3, Black 4 counterattacks.
White 1 escapes from atari.
Black 6 defends the weakness here.
Even if White 3 tries to escape at 7...
Black 8 blocks, then chases White to the edge.
A two-space extension usually secures side territory.
In fuseki, you often extend farther than two spaces.
Here, Black 1 normally extends to the side's centre.
This does not make the whole right half Black's yet.
If White approaches from the left at 2...
Black 3 makes a two-space extension.
Now this area is mostly Black territory.
What if White enters on this side?
Black 3 extends two spaces this way.
The left part of the top becomes Black territory.
Black gets less than before, but White also gets less.
A two-space extension gives fairly secure territory.
Now let us look at wider extensions.
Consider this position.
White △ cannot claim the entire top with two stones.
That is right.
The gap is wider than the basic two spaces...
So Black can reduce White's territory.
Let us enter at Black 1.
This is an uchikomi, an invasion.
What should invading stones watch out for?
Avoid being trapped against the edge.
Reaching toward the centre makes the invasion succeed.
By Black 9, White has almost no territory at the top.
If Black does not invade...
White 1 secures most of the top.
White 1 has a two-space gap right and one-space left.
One final point for reference.
Two spaces is the basic side extension...
But strong stones can support wider extensions.
These three Black △ stones form a strong group.
From here, extending to A or B...
With three or four spaces is often safe.
A wider extension can gain more territory.
Two spaces is the starting point...
But experiment as your skill grows.
Let us practise.
Build Black territory on the top side.
You cannot play there.
Now the top has become White territory.
Not bad, but Black can gain a little more.
Suddenly touching enemy stones does not work well.
This lets Black be captured.
This is a poor shape for Black.
It makes territory, but too little.
Try extending a little toward the centre too.
A clever idea. I will accept that alternative.
The framework is a little low.
White 1 limits its potential toward the centre.
Correct! The basic two-space extension.
Would you like to try again?
Shimari in corners; two-space extensions on sides.
Experiment with these as your skill improves.
''')
add('tuto3_05','''
3-5: Endgame
3-5: Endgame ⑪ Play
A game begins with fuseki, then middle-game fighting.
Eventually, it approaches the end.
By the endgame, Black and White areas are mostly set.
Now push their boundaries in your favour...
And protect the territory you have enclosed.
This is the endgame.
It is also called yose.
Let us study some common endgame techniques.
Black holds the upper right, White the upper left.
But their boundary at the top is not settled.
Once it is fixed, we can count each side's points.
Black 1 completes the upper-right territory.
That is right.
White 2 completes the territory on the left.
Black has 17 points, White 18.
White has one point more.
Back to the unsettled boundary.
Black 1 can advance this far.
Even if White plays 2...
Black 3 captures White 2.
So White must block Black 1 at 2.
Now Black 1 is in atari...
So Black 3 defends.
White cannot leave things here. White 4 must defend.
Without White 4, Black 5 can cut here.
White 2 enters atari and is chased to the edge.
That would greatly reduce the upper-left territory.
So White 4 is necessary.
The boundary is now fixed.
Black has 17 points, White 16.
Now Black has more territory.
Hane at Black 1, connect at 3: this is hane-tsugi.
Hane-tsugi also works a little farther from the edge.
You can use hane-tsugi here too.
Even if White enters at 2...
Black 3 captures White 2.
Yes. White 2 does not work.
So White 2 blocks and Black 3 connects.
After Black 1 and White 2...
You might want Black 3 to push farther...
But that does not work.
This is a common beginner mistake.
Black 3 must defend.
Otherwise White 4 puts Black 1 in atari.
Black 5 defends, but White 6 puts all three in atari.
Even if Black 7 runs, White 8 captures them all.
That is a big loss for Black.
After hane, complete the sequence by connecting.
Hane-tsugi helps settle boundaries.
Before hane-tsugi, another common position...
Has opposing stones on the third line like this.
Here, Black 1's kosumi is a good move.
White 2 blocks to protect the left-side territory.
Then Black plays 3 and 5.
That is hane-tsugi.
After White 6, this boundary is settled.
Black's territory has grown considerably.
What if Black's kosumi advances this far to 1?
It is too far from Black △.
Black's connection is weak.
White 2 cuts Black 1 off.
Even after Black 3, White 4 captures Black 1.
Black 1 went too far.
In yose, watch for weaknesses in your enclosure too.
A late invasion can overturn the result.
The lead can change at the end.
For example, Black 2 must answer White 1.
If Black forgets to play 2...
White 3 traps Black △ in an inescapable atari.
Black loses a great deal.
This shape is safe as it stands, but...
White 1 puts three Black stones in atari.
Black 2 must defend or they will be captured.
Both sides finish the territorial boundaries.
Keep settling those boundaries.
Let us practise.
The game is nearly over. Settle the edges by hane-tsugi.
You cannot play there.
That move is unrelated to this yose exercise.
You have not used hane-tsugi here.
Your hane stone was captured.
This lets Black be captured.
White entered a little too far into Black's area.
Black cannot be saved now. You needed to defend.
You need not retreat so far when answering.
Well done! You understand hane-tsugi.
Would you like to try again?
Play many games to develop your feel for yose.
''')
add('tuto3_06','''
3-6: Ending a Game
3-6: Ending a Game ⑪ Play
3-6: Ending a Game ⑪ Select
Our final chapter: ending a game.
Ending a game is simple in itself...
But recognising the end on your own...
May take some experience.
It is natural not to see it immediately.
Do not worry. Keep practising.
The game ends when no move can gain anything.
For example, this position.
The whole board is either Black or White territory.
Black is next, but has nowhere useful to play.
Black could play 1 inside its own area...
But without that move, the upper-right corner has 10.
Black 1 reduces it to 9 points.
Playing inside your own area loses territory.
But if Black 1 enters White's area...
It will simply be captured, gaining nothing.
That is right.
Black has no useful move anywhere on the board.
Black must pass.
The same is true for White.
Playing inside White territory loses points.
Entering Black's territory only loses a stone.
So White passes too.
Neither side has a useful move left.
Two consecutive passes end the game.
Then we can count both sides' territory.
Let us count it.
Black has 16 points; White has 17.
White wins by one point.
Let us look at another example.
This game is almost over, but not quite.
Black to play. Where would you play?
This is Black territory.
Playing here loses a point, so Black should not.
This is White territory.
This Black stone will be captured...
So Black should not play here either.
This is dame: a neutral point worth nothing.
We will discuss it later. It is not the move now.
Black 1 is correct.
Only this boundary of White's area was unsettled.
Black 1, White 2: White has 9 points at upper left.
If White plays 1 first, that area has 10 points.
Who plays here makes a one-point difference.
So this move is worth one point.
Such moves can decide a game. Pay attention!
After Black 1 and White 2, the game ends.
But what about point A and White △?
A is neither Black nor White territory.
Either side can play there without gain: dame.
Remaining dame makes territory harder to count.
Take turns filling those points.
Next, White △.
It cannot escape or live.
White has given up those stones.
Stones left behind in the opponent's territory...
With no hope of life are dead stones.
You may remove dead stones when the game ends.
Stones captured during play and dead stones removed...
Can fill enemy territory, reducing its size.
Let us review the steps.
First, useful moves run out.
One player passes.
The other player passes too.
The game ends.
First, take turns filling dame.
Next, remove the opponent's dead stones.
Take stones captured during play and dead stones...
And fill the opponent's territory with them.
Then count both sides' territory.
At first, simply count it as it is.
White: 7 upper left, 8 lower right. Total: 15.
Black: 8 upper right, 6 lower left. Total: 14.
White wins by one point.
Even games also use the komi rule.
Black moves first, so White receives 6.5 points.
This compensation is called komi.
Here, White leads by one point on the board.
Adding komi gives White a 7.5-point win.
The half-point prevents a draw.
With 6.5 komi, Black must lead by at least 7...
On the board to win the game.
In real games, we rearrange territory for counting.
This is called seichi.
In the previous diagram, move White △ to △.
Now White has 10 upper left and 5 lower right.
That is easier to count and add.
Move Black □ here too.
Black has 10 upper right and 4 lower left.
You cannot play there.
Let us practise.
This game has ended.
First, select every dame point.
That is Black territory.
That is White territory.
Well done!
The dame is filled with Black and White stones.
Next, select both sides' dead stones.
That stone is not dead.
The dead stones now fill the opponent's territory.
With 6.5 komi, who wins?
Black 17, White 11: Black leads 6, but White wins 0.5.
The correct answer is White.
A few mistakes, but practice makes endings familiar.
Keep practising until ending a game feels natural.
This concludes the Go courses.
Now put it all into practice!
Play more games and keep growing stronger!
''')
add('tuto3_01','''
3-1: Fuseki
Now let us study how to play a real game.
We will follow the flow of a game.
First, the opening moves.
The opening is called fuseki.
At first, no part of the board belongs to either side.
You must build your own territory.
Start in the corners, where territory is easiest.
Black 1 gives Black influence over this corner.
This is a side.
Two moves here can form a territorial framework.
This is the centre.
Territory is hard to make in the centre.
Even with Black 1 here...
It is hard to picture any Black territory, is it not?
Using the centre well takes considerable skill.
Start in the corners, where territory is easier.
That is right.
One more thing about fuseki.
The third and fourth lines from the edge...
Are the main lines to play on.
Take the first move in a corner.
If Black 1 is too close to the edge...
It encloses only this small space.
But if Black 1 is too close to the centre...
The area would be large if it became territory...
Yet White 2 can invade and take the corner easily.
Where should the very first move go?
In a corner, A, B and C are the common choices.
Black 1 here is hoshi, the star point.
It develops toward the sides and centre for big areas.
But its loose defence lets White invade at 2.
Handicap stones also start on star points.
It may be the most popular opening point.
This is komoku, the 3-4 point.
It balances corner territory...
With development along the side.
Sai likes this move.
You always start at the upper-right komoku, Sai.
I often begin with this move.
Finally, san-san, the 3-3 point.
It secures this corner firmly.
The defence is strong, but the territory is small.
Developing along the sides and centre takes longer.
Other choices are A: 4-5, B: 3-5, C: 4-6...
And D: 5-5. These need more advanced judgement.
Study them as your skill grows.
First, learn the basic shapes.
Start by trying hoshi, komoku and san-san.
Try hoshi, komoku and san-san.
Let us watch an example of fuseki.
There are four corners...
But etiquette is to start in the upper-right one.
White chooses another empty corner.
Both sides first play in the corners.
Black 5 is a shimari, a corner enclosure.
Black 1 and 5 secure most of the upper-right corner.
A shimari is a big move.
White encloses this corner too.
Black 5 could instead prevent White's enclosure.
That is called kakari, an approach move.
This area is likely to become Black territory.
And this area is likely to become White territory.
The rest of the board is still undecided.
After the corners, play along the sides.
A builds Black territory on the top.
B builds Black territory on the right.
C builds Black territory on the bottom.
D prevents White from taking the left side.
Let us play Black 7 on the top side.
White builds territory on the left.
Black builds territory on the right.
White takes the remaining bottom side.
Now the corners and sides have frameworks.
Black's territory is likely to be here...
And White's here.
The centre remains.
With the corners and sides occupied, Black plays 11.
White 12 also heads toward the centre.
At first, the board belonged to neither side...
But now it has Black and White areas.
Try to build more territory than your opponent.
''')
add('tuto3_02','''
3-2: Basic Moves
3-2: Basic Moves ⑪ Play
Let us study basic ways to connect stones.
Black 1 plays right beside Black △.
This is nobi, an extension.
Moving one step at a time gives solid defence.
It is useful when enemy stones touch yours.
But it is slow...
And can fall behind in building territory.
Consider this position.
In answer to White 1...
Black 2 heads toward the centre.
In answer to White 3...
Black plays 4.
These Black moves are nobi.
White △ is very close here.
That makes nobi useful.
If Black answers White 1 with 2 instead of nobi...
White 3 traps Black in the corner.
To pass between White △ toward the centre...
Use the solid connections of nobi.
Depending on the position...
Black 1 here is called osae, a block.
Black 1 here is magari, a turn.
This is hai, a crawl.
Learn these names gradually.
Playing beside your stones connects them firmly.
This is useful in close contact with enemy stones.
Now let us see the weakness of nobi.
We will use a game example.
Corners first, right?
Both sides begin in the corners.
Black uses solid nobi moves to build the right side.
White has already secured most of the left side.
White can now head for the top and bottom.
Black finally finishes the right side.
Black reaches White's stones.
White should use nobi here too.
Black has about this much territory.
White has about this much.
White's territory is much larger.
There were no White stones near Black...
So Black did not need such solid moves.
Nobi's weakness is its slow pace.
Let us move on.
Black 1 leaves one empty point from Black △.
This is ikken-tobi, a one-space jump.
It is one of the most common moves.
With no enemies nearby, it is usually safe from cuts.
If White enters at 2...
Black answers at 3.
White 2 escapes from atari.
Black 5 secures one side first.
If White cuts at 6...
Black 7 gives atari.
White runs, but Black captures it like this.
It does not always work out this neatly...
But forcing a cut is dangerous for White...
So Black gains an advantage.
The one-space jump is fairly connected and fast.
If White approaches the jump at 2...
Black 3 solidifies the shape.
Black 3 is tsugi, a connection.
With two Black △ stones side by side...
Black 1 can connect safely with a one-space jump.
Then Black 5 connects.
Black is fully connected now.
But with an enemy stone near Black △...
Black 1's one-space jump is dangerous.
White plays 2.
Black answers at 3, but...
White 4 can cut.
That is right.
Black is cut apart like this.
If Black 5 tries another jump to escape downward...
White 6 surrounds the three Black stones.
In close fighting like this...
A one-space jump can be cut apart.
One more warning.
Leaving a diagonal gap like Black 1 is not a jump.
This is hazama, a bad shape.
White first enters at 2.
Even if Black plays 3...
White 4 easily cuts Black apart.
Black 1 diagonally beside a stone is kosumi.
This diagonal move is called kosumi.
Like nobi, kosumi connects reliably.
For example, White plays 2.
Black 3 connects fully.
Kosumi moves diagonally.
It is useful in positions like this.
Black △ wants to reach □ and avoid being trapped.
If Black 1 extends, White plays 2.
Black 3 and White 4 leave Black trapped at the top.
Instead, Black 1 moves diagonally: kosumi.
If White plays 2, Black plays 3.
White 4, Black 5: Black passes between White ×.
Black 5 escapes between White ×.
Be careful: Black 1 here is not kosumi.
White △ is already there, so White 2 cuts.
This Black 1 is called hane.
Without White △, it would be kosumi.
Then Black 3 could connect in answer to White 2.
Finally, let us study keima.
Black 1 from △ is keima, a knight's move.
It moves like the knight in shogi.
Keima has several uses.
Unlike a straight one-space jump, it moves diagonally.
For example, in this position...
With jumps at Black 1 and 3...
Black and White get about equal territory.
But with keima at Black 1 and 3...
Black can enlarge its territory.
As you improve, you will learn more uses for keima.
Nobi, ikken-tobi, kosumi and keima.
Learn these four basic moves first.
Let us practise.
Help Black △ escape. Connect to any Black □.
You cannot play there.
Now Black △ cannot connect to □.
Well done.
Escape toward the centre with Black △ and join □.
Too bad. Black is trapped.
Correct! Black escaped successfully.
Would you like to try again?
''')
add('tuto3_03','''
3-3: Middle Game
3-3: Middle Game ⑪ Play
Now for the middle game.
Sooner or later, your stones will meet the enemy's.
Let us study the right distance between stones.
Consider this position.
Black holds the upper-right corner, White the left.
Now Black wants territory along the top.
That is right.
Black 1 should leave one space from White △.
You may think moving Black 1 right up to White...
Would gain more territory.
But if Black comes too close...
White 2 can enter along the top.
If Black 3 blocks...
White 4 cuts.
Black 1 is in atari, so Black 5 escapes.
White 6 captures Black 3 instead.
The top side becomes White territory.
If Black 1 leaves one space...
Even if White enters at 2 again...
Black 3 blocks and secures the top.
Black 1 supports Black 3, so contact is safe.
Touching enemy stones with an isolated stone is poor.
It is safer when connected to your own stones.
What if White attaches at 2?
What if White attaches at 2?
Black 3 drives White back.
White must defend at 4 or White 2 will be captured.
Black 5 firmly connects Black 1 and 3.
Black has protected the top territory.
With experience, Black 3 can fight more strongly.
White 4 cuts Black, but...
Black 5 puts White 2 in atari.
Black can chase White 2 to the edge and capture it.
Let us look at another example.
Black wants to trap White △ at the top.
How should Black play?
Black would like to form a barrier like this.
But if Black plays 1...
White 2 tries to get out.
Black 3 blocks that route.
White 4 tries the other side.
Black 1 is in atari, but captures White 2.
White sacrifices 2 and escapes toward the centre at 6.
Black has failed.
Here too, leave one space from the enemy...
And play Black 1 here.
Even if White plays 2...
Black 3 blocks.
If White tries to escape at 4...
Black 5 cuts White apart.
When you want to stop the enemy advancing...
Or want to play near an enemy group...
Avoid isolated contact moves.
Leaving one space can achieve your aim better.
Let us practise.
Make as much Black territory as possible at the top.
You cannot play there.
Hmm, you can make a little more territory.
You failed to make Black territory.
This lets Black be captured.
A little risky, but acceptable.
A clever move makes Black territory. Correct!
Well done. You followed the basic principle.
Now Black has a large territory at the top.
Would you like to try again?
''')
add('tuto2_02','''
2-2: Shicho
2-2: Shicho ⑪ Play
Let us learn shicho.
This famous capture is essential Go knowledge.
Let us see how to capture White △.
First, Black 1 gives atari.
White △ must escape at 2.
Black 3 gives atari from this side.
White △ and 2 must escape again.
Black 5 gives atari from the other side.
White keeps running.
Black 7, 9 and 11 keep giving atari.
At the edge, Black 17 captures White.
Chase with a series of ataris...
Then trap and capture at the edge.
This is shicho, or a ladder.
Shicho can begin from many different shapes.
Once the ladder starts...
The chase follows a zigzag path.
Shicho is useful, but take care when using it.
For example, Black 1 here...
Puts White in atari to start a ladder.
White escapes at 2 again.
As before...
Black 3 continues the ladder.
White keeps escaping.
But if Black 11 gives atari from the wrong side...
White escapes at 12.
Now Black cannot give atari again.
And that is not the only problem...
When a ladder fails...
It leaves many weaknesses in Black's wall.
White 14 puts both Black △ groups in atari.
Black cannot save both △ groups with one move.
One of them will be captured.
This is called double atari.
If a ladder fails...
Double ataris can cost you stones. Be careful!
There is one more point to watch.
If an enemy stone, like White □, lies ahead...
Do not use the ladder.
If Black 1 starts a ladder against White △...
White escapes at 2.
Black 3 chases as before.
The ladder reaches White □.
Now Black cannot give atari.
Black also has weaknesses at A and B.
A ladder will fail...
If enemy stones lie in its path.
White □ is called a ladder breaker.
Try giving atari and capturing White △.
You fail if you can no longer give atari.
You cannot play there.
Hmm, that did not work.
White cannot escape. Correct!
Well done.
Let us practise.
Use shicho to take White △ before Black □ is taken.
You cannot play there.
Too bad. Would you like to try again?
Well done! That is shicho.
Practise until you can use shicho...
To capture stones in your games.
''')
add('tuto2_03','''
2-3: Snapback / Oiotoshi
2-3: Snapback / Oiotoshi ⑪ Play
Let us study snapback and oiotoshi.
First, snapback.
You can take these five White △ stones by snapback.
Black 1 gives △ atari, but...
White 2 connects and defends.
Now Black cannot capture White △.
Instead, Black 1 attacks △ here.
White 2 captures Black 1.
It feels odd to play a stone that is taken at once...
But now all six White △ stones are in atari.
It is Black's turn. Black 3 captures them!
Sacrifice one stone to capture a larger group.
That is snapback.
Next, oiotoshi.
This also gives atari so the enemy cannot escape.
Look at White △.
Black 1 puts △ in atari.
White 2 defends △ from atari.
But now all five White △ stones are in atari.
Black 3 captures them together.
Escaping one atari leads to a larger atari.
This is oiotoshi.
Sometimes a simple atari is enough...
But this shape needs some preparation.
If Black 1 simply gives atari...
White 2 defends.
Black 3 gives atari again, but...
White 4 escapes. Black cannot keep chasing.
Back to the original shape.
Black 1 here is the key move.
White 2 captures Black 1.
Then Black 3 puts △ in atari.
White 4 connects to defend △.
Now Black 5 captures the whole group.
Practise snapback and oiotoshi...
So you can use them in your games.
Let us start with snapback.
You can capture White △ by snapback.
Give it a try.
You cannot play there.
Too bad. Now White △ cannot be captured.
Excellent! You have grasped snapback.
Let us practise.
Save Black △.
Use snapback to take White □ or ×. It is the only way.
You cannot play there.
Now White cannot be captured.
Correct! You used snapback well.
To save Black △, you must take White □.
Make good use of oiotoshi.
Excellent!
Playing this well in a real game would be impressive.
Would you like to try again?
''')
add('tuto2_04','''
2-4: Geta
2-4: Geta ⑪ Play
Let us study geta.
It traps enemy stones without giving atari.
This is geta, or a net. It often appears in games.
It is a common technique.
Let me explain.
To take White △, you might give atari with Black 1.
White escapes from atari.
Even if Black 3 chases...
White 4...
Black 5...
White 6 connects to the outside group and is safe.
That is right.
Some stones cannot be caught by chasing with atari.
Geta can capture them.
Black 1 surrounds △ from a distance.
White △ is not in atari, but can try to flee at 2.
Black 3 blocks.
That route is closed, so White tries 4.
Black 5 blocks again.
Now all three White stones are trapped.
Geta can catch stones...
That direct ataris cannot capture.
Give it a try.
Can you capture White △?
You cannot play there.
It is natural to want to give atari first.
But now White has joined the large outside group.
You cannot capture it now.
Excellent! You can already use geta.
Practice helps more than words. Shall we try?
Would you like more practice?
Black to play. Capture White △.
Too bad. You did not catch White.
Would you like to try again?
Excellent.
You understand geta well.
Practise using it in real games too.
''')
add('tuto2_05','''
2-5: How to Live
2-5: How to Live ⑪ Play
We have studied life and death a little.
When your stones are cut off among enemy stones...
How can you make two eyes and live?
Let me explain some useful ideas.
An eye is one point of territory.
Making two eyes means...
Enclosing two separate one-point spaces.
For example, even with many stones...
This shape cannot enclose territory.
Such stones find it hard to live.
These Black stones are fewer, but...
They have territory, so living is easier.
When surrounded by enemy stones...
Making one eye, then another, can be difficult.
First enclose a small area...
Then divide it into two eyes.
How much space do you need for two eyes?
Black encloses two points here.
Whatever Black plays, only one eye is possible.
Here Black encloses three points.
Black 1 makes eyes at A and B.
First tip: enclose three points and play the middle.
That is right.
We saw how to live with three points...
But that is not the only way.
Sometimes you can enclose four or five points.
Even four-point spaces differ with their shape.
With four points in a straight line...
Even if White invades at 1...
Black 2 makes one eye on each side.
This group is alive.
In this four-point shape...
Black must play 1 to be fully alive.
A square four-point space can only make one eye.
Four points in a line are better than a square.
There are other shapes with four to six points.
One more thing to remember.
Black stones with a large territory like this...
Need not worry about life and death.
Black has eleven points of territory.
If White invades at 1 to try to kill Black...
Black 2 attacks the invading stone.
By capturing invaders like this...
Black cannot be captured.
With such a large territory, Black...
Is alive even without two separate eyes yet.
Let us practise.
Can you make the five Black stones at the top live?
You cannot play there.
Now Black cannot make two eyes.
Correct! You made Black live.
The Black stones at the top are now safe.
You caught on quickly!
Would you like to try again?
''')
add('tuto2_06','''
2-6: How to Kill
2-6: How to Kill ⑪ Play
2-6: How to Kill ⑪ Play ⑫ End
Last time, we studied how to make stones live.
This time, to capture enemy stones...
We must stop them from making two eyes.
Let me show you how.
Once a group has two eyes, surrounding it...
Will not let you capture it.
With only one eye, even in an open area...
Black △ can eventually surround White.
Then Black 1 captures it.
Once you have cut off and surrounded a group...
Rather than surrounding it tightly...
Prevent it from making two eyes.
If White suddenly invades this solid Black area at 1...
White can hardly make two eyes.
That is right.
With White stones like these...
Black can chase them down and capture them easily.
But if the group you attack...
Has three or more points of space...
You need technique to stop it living.
White 1 makes this shape live, remember?
After that, Black cannot capture White.
Before White lives, Black must reduce it to one eye.
Black 1 here is the key move.
It is three-point nakade: play inside the middle.
After nakade, White can make only one eye here.
With no other eye, White cannot live.
Whatever White plays, two eyes are impossible.
Correct nakade leaves only one eye.
Nakade is not limited to three points.
Some four- to six-point shapes also have nakade.
In this four-point shape...
Black 1 is nakade.
This is four-point nakade.
Again, White can make only one eye here.
For reference...
Here are other four-point shapes.
White A can make only one eye as it stands.
Even if White plays 1...
Black 2 makes three-point nakade.
White groups B, C and D...
Are already alive with their four-point spaces.
Even if Black plays 3 against B...
Or Black 5 against C...
Or Black 7 against D...
White 4 answers. Black can do no more.
White 6 answers. Black can do no more.
White 8 answers. Black can do no more.
Experience will make these shapes familiar.
You need not memorise them all now.
These two five-point shapes also have nakade.
Even with this much space...
Nakade leaves only one eye.
Finally, a six-point shape.
It is rare, but let me show you.
Let me introduce it.
Even with this much space...
Black 1 leaves this shape with only one eye.
You need not memorise it right now.
False eyes also matter in life and death.
We have seen false eyes before.
Let us review them here.
Are these White stones alive or dead?
Good. Would you like an explanation of false eyes?
At first glance, White seems alive.
A and B appear to be eyes.
But Black 1 here...
Puts White △ in atari.
Then Black can play inside at 2.
Since Black can play inside...
That space was not a true eye.
Back to the original shape.
A looks like an eye, but only looks like one.
It does not help White live.
This is a false eye.
Suppose this White group appears in a game.
How should Black attack it?
First, Black 1 reduces White's space.
White 2 blocks, putting Black 1 in atari.
White has three points of space.
White could play A to make two eyes and live.
Black 3 makes three-point nakade in the corner.
Yes. Well spotted, Hikaru.
Even if White 4 captures...
Black 5 blocks and puts White 4 in atari.
So A is a false eye.
Nakade leaves one eye in the corner.
White has only one eye and cannot live.
Try to attack White like this in your games.
Would you like to test it as White?
Black 1 makes three-point nakade.
Black 1 makes four-point nakade.
Check that White cannot make two eyes.
You cannot play there.
That point is unrelated.
Yes. Playing both there and here would make life...
But turns alternate, so White cannot play both.
Have you seen enough?
Would you like some practice?
Play Black and prevent White from living.
Taking small stones fails if the main group lives.
White has two eyes. Black cannot capture it now.
Well done.
White has only one eye now.
Would you like more practice?
Please check it.
Would you like to try again?
That is not a very good move.
White is alive even without another move...
But White 1 makes it impossible for Black to capture.
Letting Black be captured to make a false eye...
Is called uchikaki, or a throw-in.
White has only the eye on the right now.
Well done. That is five-point nakade.
Stay alert right to the end.
Close! Just a little more.
White is alive now.
Now White cannot make two eyes.
Well done.
Practise life and death in real games too!
''')
