"""Screenshot-driven map, battle and pause navigation translations."""
LABELS={'2D/sco':{},'2D/map':{'roo04_6.D4':'Yes','roo04_7.D4':'No','roo05_16.D4':'Waya','roo05_17.D4':'Isumi','roo05_18.D4':"Don't Play"},'2D/mba_battle':{'mba02_0.D4':'Options','mba02_00.D4':'Options','mba02_01.D4':'Rules','mba02_02.D4':'Support','mba02_03.D4':'Pause\nMenu'},'2D/bbg':{'roo04_6.D4':'Yes','roo04_7.D4':'No'}}
s=LABELS['2D/sco']
for i,t in enumerate(['Offer End','Resign','Pass','Suspend','Settings','Undo','Review','Estimate','Hint']):s[f'sco02_{i:02d}.D4']=t
for i in range(11):s[f'sco02_{i+9:02d}.D4']=f'Hint x{i}'
s.update({'sco02_21.D4':'Zoom In','sco02_22.D4':'Zoom Out','sco07_01.D4':'Options','sco07_02.D4':'Rules','sco07_03.D4':'Support','sco08_04.D4':'2 hours','sco08_60.D4':'Overhead','sco08_61.D4':'Angled'})
for i,n in enumerate([5,9,13,19]):s[f'sco08_{i:02d}.D4']=f'{n} x {n}'
for i in range(21):
 s[f'sco08_{i+10:02d}.D4']=f'{(i+1)/2:g}'
 s[f'sco08_{i+31:02d}.D4']=f'-{(i+1)/2:g}'
NAMES=['Shindo Hikaru','Toya Akira','Isumi Shinichiro','Waya Yoshitaka','Nase Asumi','Fujisaki Akari','Mitani Yuki','Kaga Tetsuo','Tsutsui Kimihiro','Kurata Atsushi','Ogata Seiji','Kuwabara Honinbo','Toya Koyo','Ochi Kosuke','Fujiwara Sai']
for i,n in enumerate(NAMES):s[f'sco08_{i+70:02d}.D4']=n
for i,t in enumerate(['10 min','20 min','30 min','1 hour','2 hours']):s[f'sco09_{i:02d}.D4']=t
for i in range(8):
 s[f'sco09_{10+i:02d}.D4']=f'{i+2} stones'
 s[f'sco09_{18+i:02d}.D4']=f'Free {i+2} stones'
for i,t in {26:'Chinese',27:'Korean',28:'Even',32:'Buzzer',33:'Left On / Right Off',34:'Left Off / Right On',40:'Nigiri',41:'Left Black / Right White',42:'Left White / Right Black',43:'Black',44:'White',50:'10 sec',51:'30 sec',52:'1 min',53:'3 min',54:'5 min',60:'On',61:'Off',62:'Normal',63:'Real Time',92:'Resign',93:'Pass'}.items():s[f'sco09_{i:02d}.D4']=t
for i in range(11):
 s[f'sco09_{70+i:02d}.D4']='Best: Unlimited' if i==0 else f'Best: {i}'
 s[f'sco09_{81+i:02d}.D4']='3-Choice: Unlimited' if i==0 else f'3-Choice: {i}'

TEXT={
0x24ab88:'Ask to end the game.',0x24abac:'Resign.',0x24abb8:'Pass once.',0x24abc8:'Suspend play.',0x24abdc:'View / change settings.',0x24abf8:'Take back your last move.',0x24ac18:'Review the game.',0x24ac30:'Estimate score.',0x24ac44:'Show a suggested move.',
0x251954:'MainHall',0x251960:'Senshin',0x25196c:'Yugen',0x251978:'Go Rank',0x251984:'Insei',
0x251b10:'Nihon Ki-in',0x251b20:'Internet Cafe',0x251b38:'Go Class',0x251b44:'Haze Jr.',0x251b50:"Hikaru's",0x251b5c:'Go Study Centre',0x251b70:'Go Salon',0x251b7c:"Waya's",0x251b88:'Shinjuku Salon',0x251b98:'Go Festival',
0x2d9fb0:'Lobby',0x2d9fb8:'Press',0x2d9fc0:'Home',0x2d9fc8:"Toya's",
0x2da5d0:'',0x2da5d8:'',
0x24ae58:'Set board size.',0x24ae6c:'Set komi.',0x24ae80:'Set time limit.',0x24ae98:'Set turn order.',0x24aeac:'Set handicap.',0x24aec0:'Set byoyomi.',0x24aed4:'Set atari warnings.',0x24aef4:'Set undo.',0x24af08:'Set review mode.',0x24af20:'Set match comments.',0x24af3c:'Set score display.',0x24af54:'Set hints.',0x24af68:'Set Support menu access.',0x24af8c:'Set music.',0x24afa0:'Set sound effects.',0x24afb4:'Set byoyomi voice.',0x24afd0:'Set kifu reading voice.',0x24aff0:'Set visual effects.',0x24b00c:'Set hand display.',0x24b02c:'Set board view.',0x24b048:'Go to Rules settings.',
0x24c668:'Hikaru',0x24c674:'Akira',0x24c680:'Shinichiro',0x24c68c:'Waya',0x24c698:'Asumi',0x24c6a4:'Akari',0x24c6b0:'Mitani',0x24c6bc:'Kaga',0x24c6c8:'Tsutsui',0x24c6d4:'Ogata',0x24c6e0:'Kuwabara',0x24c6ec:'Koyo',0x24c6f8:'Ochi',0x24c704:'Sai',0x24c710:'Akari',
}
# Whole-string matches only; these are standard spoken match cues.
MATCH_CUES={
'お願いします。':"Let's play.",'よろしくお願いします。':'Have a good game.','ありがとうございました。':'Thank you.','ありがとう↓ございました。':'Thank you↓for the game.',
'負けました。':'I resign.','負けました・・・':'I resign...', '終局ですね。':'Game over?', '終局か・・・':'Game over...', 'うん、終局だな。':'Yes, game over.', 'まだ終わってねーぜ。':"Not over yet.",
'ボクの先番ですね。':"I'll take Black.",'あなたの先番です。':'You take Black.','よしっ、↓オレが黒だな。':"Okay,↓I'll take Black.",'おまえが黒だな。':'You take Black.', 'よーしっ、ニギるぞ。':"Let's do nigiri.",'ボクが↓ニギりましょう。':"I'll do↓nigiri.",
}
