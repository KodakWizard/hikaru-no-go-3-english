"""Missing shared names, problem selectors, item unlocks and match results."""
import re
from pathlib import Path
TEXT={0x2d9540:'Atari',0x2d9548:'Geta',0x2501ec:'Choose a problem.'}
ITEMS={'ブリスターパック':'a blister pack','秀策像':'a Shusaku statue','赤い冷蔵庫':'a red fridge','キックボード':'a kick scooter','かぼちゃ':'a pumpkin','扇子':'a fan','スニーカー':'sneakers','Ｔシャツ':'a T-shirt','缶ジュース':'canned juice','王将の駒':'a shogi king','ポスター':'a poster','カバン':'a bag','賞状':'an award','トロフィー':'a trophy','クリスタル盤':'a crystal goban','畳マット盤':'a tatami goban','折りたたみ盤':'a folding goban','朱塗り盤':'a red goban','漆盤':'a lacquer goban','湯のみ茶碗':'a tea cup','ＧＢのソフト':'a GB game','ＧＢＡのソフト':'a GBA game','ゲームキューブのソフト':'a GameCube game'}
CHARACTERS={'藤原佐為':'Sai','奈瀬明日美':'Nase','三谷祐輝':'Mitani','筒井公宏':'Tsutsui','倉田厚':'Kurata','緒方精次':'Ogata','桑原本因坊':'Kuwabara','塔矢行洋':'Toya Koyo','越智康介':'Ochi','藤崎あかり':'Akari'}
TERMS={'クリスタル盤':'Crystal goban','クリスタル碁石':'Crystal stones','水面背景':'Water backdrop','畳マット盤':'Tatami goban','大理石碁石':'Marble stones','藍染め背景':'Indigo backdrop','折りたたみ盤':'Folding goban','キャラ碁石':'Character stones','宇宙空間背景':'Space backdrop','朱塗り盤':'Red goban','彫り碁石':'Carved stones','白銀紫陽花背景':'Silver hydrangeas','漆盤':'Lacquer goban','葉模様碁石':'Leaf-pattern stones','和風金鶴背景':'Golden cranes','五路盤':'5x5 goban','一色碁':'One-colour Go'}
EFFECTS={'青竜':'Azure Dragon','白虎':'White Tiger','魔人':'Demon','華':'Flower','朱雀':'Vermilion Bird','電脳':'Cyber','玄武':'Black Tortoise'}
def build_text(original):
 out=dict(TEXT)
 # These 50 short shared fields are the actual problem number labels.
 for i in range(50):
  a=0x2d9550+i*8;raw=original[a:original.index(0,a)].decode('cp932');assert raw.startswith('第') and raw.endswith('問');out[a]=f'No.{i+1}'
 names={'ブリスターパック':'Blister Pack','秀策像':'Statue','赤い冷蔵庫':'Red Fridge','キックボード':'Scooter','かぼちゃ':'Pumpkin','扇子':'Fan','スニーカー':'Sneakers','Ｔシャツ':'T-Shirt','缶ジュース':'Juice','王将の駒':'Shogi King','ポスター':'Poster','カバン':'Bag','賞状':'Cert','トロフィー':'Trophy','クリスタル盤':'Crystal','畳マット盤':'Tatami','折りたたみ盤':'Folding','朱塗り盤':'Red','漆盤':'Lacq','湯のみ茶碗':'Tea Cup','ＧＢのソフト':'GB Game','ＧＢＡのソフト':'GBA Game','ゲームキューブのソフト':'GC Game'}
 for jp,en in names.items():
  needle=jp.encode('cp932')+b'\0';p=0x22d420
  while True:
   at=original.find(needle,p)
   if at<0:break
   p=at+len(needle)
   if original[at-1] in (0,0xcd):out[at]=en
 a=0x2792a0
 while a<0x279de0:
  end=original.index(0,a);jp=original[a:end].decode('cp932');en=None
  if jp.endswith('を手に入れた。'):
   item=jp[:-len('を手に入れた。')]
   if item.startswith('囲碁問題集'):
    n={'二':2,'三':3,'四':4,'五':5}[item[-2]];en=f'Got problem set {n}.'
   else:en='Got '+ITEMS[item]+'.'
   en={'Got a Shusaku statue.':'Got Shusaku statue.','Got a lacquer goban.':'Got lacquer goban.'}.get(en,en)
  elif jp.startswith('囲碁問題集') and jp.endswith('ができます。'):
   n={'二':2,'三':3,'四':4,'五':5}[jp[5]];en=f'Problem set {n} unlocked.'
  else:
   for name,eng in CHARACTERS.items():
    if jp.startswith(name):
     rest=jp[len(name):]
     mode={'をフリー対局で使用できます。':'Free Match','を秒読みで使用できます。':'Byoyomi','を棋譜読み上げで使用できます。':'Kifu narration'}[rest];en=f'{eng}: {mode} unlocked.';break
   if en is None:
    for term,eng in TERMS.items():
     if jp.startswith(term):en=eng+' unlocked.';break
   if en is None and '系のエフェクトを使用できます。' in jp:en=EFFECTS[jp.split('系')[0]]+' effects unlocked.'
   if en is None and jp=='対局で朝鮮式の置石ができます。':en='Korean handicap unlocked.'
   if en is None and jp=='対局で中国式の置石ができます。':en='Chinese handicap unlocked.'
  if en:out[a]=en
  elif jp not in ['home','']:raise ValueError((hex(a),jp))
  a=(end+4)&~3
  if jp=='対局で中国式の置石ができます。':break
 # Exact full constants only, keeping printf argument order.
 results={'黒時間切れ勝ち':'Black +Time','白時間切れ勝ち':'White +Time','引き分け':'Jigo',
 '黒中押し勝ち':'Black +R','白中押し勝ち':'White +R','黒半目勝ち':'Black +0.5','白半目勝ち':'White +0.5',
 '黒%d目%s勝ち':'B+%d%s','白%d目%s勝ち':'W+%d%s',
 '白 時間切れ勝ち':'White +Time','黒 時間切れ勝ち':'Black +Time','白 中押し勝ち':'White +R','黒 中押し勝ち':'Black +R',
 '黒 %d目半勝ち':'B+%d.5','黒 %d目勝ち':'B+%d','黒 半目勝ち':'B+0.5','白 %d目半勝ち':'W+%d.5','白 %d目勝ち':'W+%d','白 半目勝ち':'W+0.5'}
 for jp,en in results.items():
  needle=jp.encode('cp932')+b'\0';start=0x250a00
  while True:
   at=original.find(needle,start)
   if at<0:break
   start=at+len(needle)
   if original[at-1] in (0,0xcd):out[at]=en
 # The compact results move count has a seven-byte format slot.
 # Keep its string argument; render the completion suffix as an abbreviation.
 out.update({0x2d9934:'.5',0x2d9938:'vs',0x2d993c:'%3dm%s'})
 return out
