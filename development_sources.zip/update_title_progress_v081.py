﻿from pathlib import Path
import json
p=Path('translation_work/COVERAGE.json');r=json.loads(p.read_text(encoding='utf8'));r['latest_build']='English_Title_v081';r['runtime']['v081']='Pending Dolphin visual confirmation; title-only revision, all v0.8 executable/content retained.';r['title_v081']={'user_direction':'English lettering must closely match original Japanese logo, including shadow. Rectangular plate rejected.','graphics':2,'full_game_complete':False};p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
