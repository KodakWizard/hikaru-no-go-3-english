"""Check finished quantized font support for extra edge pixels and color halos."""
from pathlib import Path
import json
from collections import Counter
from qa_research_v10 import current_files
from qa_art_v52 import edits
from decode_bpe import decode
from textures import texture,resources

R=Path(__file__).resolve().parent;OUT=R/'English_QA_v52';W=R/'translation_work/qa_v52'
def font(iso):
    f,_,files=current_files(iso);o,n,_=files['font24/hggc24.bpe'];f.seek(o);b=decode(f.read(n));f.close()
    return b,texture(b,dict(resources(b))['hggc24_a.D4'])[0]
old,_=font(R/'English_QA_v51/Hikaru no Go 3 - English QA v51.iso')
new,actual=font(OUT/'Hikaru no Go 3 - English QA v52.iso')
expected=edits(old)['hggc24_a.D4'];support_added=0;colored=0;perimeter=0;cells=0
for code in range(32,127):
    if code==92:continue
    cells+=1;x,y=code%16*12,code//16*24
    for yy in range(24):
        for xx in range(12):
            p=actual.getpixel((x+xx,y+yy));q=expected.getpixel((x+xx,y+yy))
            support_added+=int(q[3]==0 and p[3]!=0)
            colored+=int(p[3]>0 and len(set(p[:3]))!=1)
            if xx in (0,11) or yy in (0,23):perimeter+=int(p[3]!=0)
assert support_added==colored==perimeter==0
o=dict(resources(old))['hggc24_a.D4'];n=dict(resources(new))['hggc24_a.D4']
assert old[o:o+64+30]==new[n:n+64+30] # Header, descriptor and 15-entry palette.
audit=dict(cells_checked=cells,unexpected_alpha_outside_area_resampled_source=support_added,
           colored_visible_pixels=colored,nontransparent_gutter_pixels=perimeter,
           original_palette_exact=True,filter='premultiplied BOX area resampling',
           additional_outline_stroke_or_blur=False,
           limits='Static texture support/palette checks; actual Dolphin filtering still requires user comparison.')
(OUT/'edge_checks.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
report=json.loads((OUT/'build_report.json').read_text(encoding='utf8'));report['edge_checks']=audit
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
corpus=json.loads((W/'current_corpus.json').read_text(encoding='utf8'));counts=Counter(r['area'] for r in corpus)
print('Finished font:',audit)
print('Punctuation corpus:',dict(counts))
